#!/bin/bash
# Set proxy
cat > /etc/profile.d/aws_proxy.sh <<EndOfProxy
export HTTPS_PROXY=http://entproxy.kdc.capitalone.com:8099/
export HTTP_PROXY=http://entproxy.kdc.capitalone.com:8099/
export http_proxy=http://entproxy.kdc.capitalone.com:8099/
export https_proxy=http://entproxy.kdc.capitalone.com:8099/
export NO_PROXY=169.254.169.254,localhost,.kdc.capitalone.com,http://s3.amazonaws.com/
export no_proxy=169.254.169.254,localhost,.kdc.capitalone.com,http://s3.amazonaws.com/
EndOfProxy
source /etc/profile.d/aws_proxy.sh
echo "Exported ENV variables"

# join ec2 instance to centrify group
cd /opt/centrify
/opt/centrify/domain-join.sh dqa.capitalone.com QAWS_ENVNP_WPSESM_CG  aws >>
/var/log/centrify_stacktrace.log 2>&1
echo "Joined Centrify Group"


yum -y update
echo "Yum install done"
# Installing node server
sudo -E curl --silent --location https://rpm.nodesource.com/setup_8.x | bash -
yum install -y nodejs
chmod -R 777 /usr/lib/node_modules
echo "Node Installation Done"

# Installing Angular CLI
# sudo -E npm i -g @angular/cli


# Installing Ngnix
rpm -Uvh http://nginx.org/packages/rhel/7/x86_64/RPMS/nginx-1.12.1-1.el7.ngx.x86_64.rpm
echo "NGINX installation done"


# Adding the configuration to /etc/nginx/conf.d/default.conf

cat > /etc/nginx/conf.d/default.conf <<EndofDefault
server {
    listen       80;
    server_name  localhost;
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
    # redirect server error pages to the static page /50x.html
    #
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   /usr/share/nginx/html;
     }
}
EndofDefault
echo "NGINX Configuration done"

#Deploying and extracting the artifact
cd /opt/
echo "The build type is ${BUILD_TYPE}"
if [ "${BUILD_TYPE}" == "dev" ]
then
aws s3 cp s3://${S3Bucket}/${artifactFolder}/hrdashboard.tar.gz .
elif [ "${BUILD_TYPE}" == "release" ]
then
  wget --content-disposition "https://artifactory.cloud.capitalone.com/artifactory/x-generic-int-east-local/com.capitalone.hrdashboard/hrdashboard-${version}.tar.gz"
else
  echo "BUILD_TYPE is nor dev nor release, So unable to download artifact either from S3 or artifactory"
fi

tar -zxvf hr*
cd /opt/hrartifact
node server &

sudo nginx

# Run serverspec scripts
cd /opt/chef/
mkdir -p serverspec
cd serverspec
aws s3 cp s3://${S3Bucket}/${serverSpecFolderName} . --recursive
/opt/chef/embedded/bin/rake spec:localhost
#instance_id=$(curl http://169.254.169.254/latest/meta-data/instance-id)
aws s3 cp /opt/chef/cache/serverspec_results.html s3://${S3Bucket}/${appLogsFolderName}/${instance_id}/${instance_id}-serverspec.html --sse AES256
echo "serverspec logs uploaded to s3 location: ${S3Bucket}/${appLogsFolderName}/${instance_id}"
echo "serverspec performed for CICD" >> /var/log/cloud-init-output.log
aws s3 cp /var/log/cloud-init-output.log   s3://${S3Bucket}/${appLogsFolderName}/${instance_id}/${instance_id}-cloud-init-output.log --sse AES256
