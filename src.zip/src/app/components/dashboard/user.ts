export class User {
  id: number;
  eid: string;
  first_name: string;
  last_name: string;
  email: string;
  admin: boolean;
  superuser: boolean;
  created_at: Date;
  created_by: string;
  updated_at?: Date;
  updated_by?: string;
}
