import { Injectable }    from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

import { User } from './user';

@Injectable()
export class UserInfoService {
  private headers = new Headers({'Content-Type': 'application/json'});
  private url = 'api/user';

  constructor(private http: Http) {}

  getUserByEid(eid: string): Promise<User> {
    const url = `${this.url}/?eid=${eid}&admin=check`;
    return this.http.get(url)
      .toPromise()
      .then(res => res.json() as User)
      .catch(this.handleError);
  }

  haveDatasourceAccess(eid: string, ds: number): Promise<boolean> {
    const url = `${this.url}/?eid=${eid}&ds=${ds}`;
    return this.http.get(url)
      .toPromise()
      .then(res => (res.json().count > 0) as boolean)
      .catch(this.handleError);
  }

  havePageAccess(eid: string, page_id: number): Promise<boolean> {
    const url = `${this.url}/?eid=${eid}&page_id=${page_id}`;
    return this.http.get(url)
      .toPromise()
      .then(res => (res.json().count > 0) as boolean)
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
