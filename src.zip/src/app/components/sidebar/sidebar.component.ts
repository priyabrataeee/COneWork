import { Component, OnInit, Input } from '@angular/core';

import { User } from '../dashboard/user';
import { UserInfoService } from '../dashboard/user-info.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  @Input() user: User;
  hrdwAccess: boolean;
  greetings: string[] = [
    'Hi',
    'Howdy',
    'Hello',
    'Hola'
  ];
  greeting: string;

  constructor(
    private userService: UserInfoService
  ) {
    this.greeting = this.greetings[
      Math.floor(Math.random() * this.greetings.length)
    ];
  }

  ngOnInit() {
    this.userService
    .haveDatasourceAccess(localStorage.getItem('userid'), 1)
    .then(res => this.hrdwAccess = res);
  }

}
