import { Component, OnInit } from '@angular/core';
import {
  IMultiSelectOption,
  IMultiSelectSettings,
  IMultiSelectTexts
} from 'angular-2-dropdown-multiselect';
import { IMyDrpOptions } from 'mydaterangepicker';


import { EomData } from '../../eom/eom/eom-data';
import { FiltersService } from '../../filters.service';

import { Angular2Csv } from 'angular2-csv/Angular2-csv';

declare var jsPDF: any;

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {

  perfView: boolean;
  personalView: boolean;
  compView: boolean;
  diversityView: boolean;
  allView: boolean;

  results = [];
  model = new EomData();

  dates: string[];
  daterange: any;
  jobLevels: any[];
  states: string[];
  cities: string[];
  countries: string[];
  departments: any[];
  buildings: any[];

  repTo1: string[];
  repTo2: string[];
  repTo3: string[];
  repTo4: string[];

  orgLvl1: string[];
  orgLvl2: string[];
  orgLvl3: string[];
  orgLvl4: string[];
  orgLvl5: string[];
  orgLvl6: string[];
  orgLvl7: string[];
  orgLvl8: string[];
  orgLvl9: string[];
  orgLvl10: string[];
  orgLvl11: string[];
  orgLvl12: string[];

  // private myDatePickerOptions: IMyDpOptions = {
  //   dateFormat: 'mm/dd/yyyy',
  //   indicateInvalidDate: true,
  //   height: '30px',
  //   selectionTxtFontSize: '12px'
  // };

  myDateRangePickerOptions: IMyDrpOptions = {
    // other options...
    dateFormat: 'mm/dd/yyyy',
    inline: false,
    width: '100%',
    height: '26px',
    selectionTxtFontSize: '12px',
    selectorWidth: '99%'
  };
  msSettings: IMultiSelectSettings = {
    enableSearch: true,
    buttonClasses: 'btn btn-outline-secondary btn-block muti-select',
    // showCheckAll: true,
    showUncheckAll: true,
    // isLazyLoad: true
  };

  jobLvlTexts: IMultiSelectTexts = {
    defaultTitle: 'Select Job Level'
  };

  jobLvlOptionsModel: number[];
  jobLvlOptions: IMultiSelectOption[];

  buildingTexts: IMultiSelectTexts = {
    defaultTitle: 'Select Building'
  };

  buildingOptionsModel: number[];
  buildingOptions: IMultiSelectOption[];

  countryTexts: IMultiSelectTexts = {
    defaultTitle: 'Select Country'
  };

  countryOptionsModel: number[];
  countryOptions: IMultiSelectOption[];

  deptTexts: IMultiSelectTexts = {
    defaultTitle: 'Select Department'
  };

  deptOptionsModel: number[];
  deptOptions: IMultiSelectOption[];

  stateTexts: IMultiSelectTexts = {
    defaultTitle: 'Select State'
  };

  stateOptionsModel: number[];
  stateOptions: IMultiSelectOption[];

  cityTexts: IMultiSelectTexts = {
    defaultTitle: 'Select City'
  };

  cityOptionsModel: number[];
  cityOptions: IMultiSelectOption[];

  repTo1Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Reports To 1'
  };

  repTo1OptionsModel: number[];
  repTo1Options: IMultiSelectOption[];

  repTo2Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Reports To 2'
  };

  repTo2OptionsModel: number[];
  repTo2Options: IMultiSelectOption[];

  repTo3Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Reports To 3'
  };

  repTo3OptionsModel: number[];
  repTo3Options: IMultiSelectOption[];

  repTo4Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Reports To 4'
  };

  repTo4OptionsModel: number[];
  repTo4Options: IMultiSelectOption[];


  orgLvl1Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 1'
  };

  orgLvl1OptionsModel: number[];
  orgLvl1Options: IMultiSelectOption[];

  orgLvl2Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 2'
  };

  orgLvl2OptionsModel: number[];
  orgLvl2Options: IMultiSelectOption[];

  orgLvl3Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 3'
  };

  orgLvl3OptionsModel: number[];
  orgLvl3Options: IMultiSelectOption[];


  orgLvl4Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 4'
  };

  orgLvl4OptionsModel: number[];
  orgLvl4Options: IMultiSelectOption[];

  orgLvl5Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 5'
  };

  orgLvl5OptionsModel: number[];
  orgLvl5Options: IMultiSelectOption[];

  orgLvl6Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 6'
  };

  orgLvl6OptionsModel: number[];
  orgLvl6Options: IMultiSelectOption[];

  orgLvl7Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 7'
  };

  orgLvl7OptionsModel: number[];
  orgLvl7Options: IMultiSelectOption[];

  orgLvl8Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 8'
  };

  orgLvl8OptionsModel: number[];
  orgLvl8Options: IMultiSelectOption[];

  orgLvl9Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 9'
  };

  orgLvl9OptionsModel: number[];
  orgLvl9Options: IMultiSelectOption[];

  orgLvl10Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 10'
  };

  orgLvl10OptionsModel: number[];
  orgLvl10Options: IMultiSelectOption[];

  orgLvl11Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 11'
  };

  orgLvl11OptionsModel: number[];
  orgLvl11Options: IMultiSelectOption[];

  orgLvl12Texts: IMultiSelectTexts = {
    defaultTitle: 'Select Org Level 12'
  };

  orgLvl12OptionsModel: number[];
  orgLvl12Options: IMultiSelectOption[];

  constructor(
    private fService: FiltersService
  ) { }

  ngOnInit() {
    this.getCols();
    this.getRows();
    this.getDates();
    this.model.asctype = 'Associate';
    this.model.view = 'default';
    this.getJobLevels();
    this.getCountries();
    this.getStates();
    this.getCities();
    this.getBuildings();
    this.getReportsTo1();
    this.getReportsTo2();
    this.getReportsTo3();
    this.getOrgLvl1();
    this.getOrgLvl2();
    this.getOrgLvl3();
    this.getOrgLvl4();
    this.getOrgLvl5();
    this.getOrgLvl6();
    this.getOrgLvl7();
    this.getOrgLvl8();
    this.getOrgLvl9();
    this.getOrgLvl10();
    this.getOrgLvl11();
    this.getOrgLvl12();
  }

  onSubmit(form: any): void {
    if (this.model.rows.length > 0) {
      this.buildParams(form);
        this.getEvtReport(this.model);
      document.getElementById('loader').style.display = 'block';
    }
  }

  exportCsv(): void {
    let service, csvName = '';
    if(this.model.view === 'Compensation') {
      csvName = 'Month-End Snapshot - Compensation';
    } else if(this.model.view === 'Personal') {
      csvName = 'Month-End Snapshot - Personal';
    } else if(this.model.view === 'Diversity'){
      csvName = 'Month-End Snapshot - Diversity';
    }else if(this.model.view === 'Performance') {
      csvName = 'Month-End Snapshot - Performance Management';
    } else if(this.model.view === 'All') {
      csvName = 'Month-End Snapshot - All Data';
    } else {
      csvName = 'Month-End Snapshot - General';
    }
    service = this.fService.getEvtReportCsv(this.model);
    service.then(results => {
        new Angular2Csv(results, csvName, {
          showLabels: true,
          headers: [
            "Employee ID", "EUID", "Alternate Employee ID", "Prefix Name", "First Name", "Middle Name", "Last Name", "Full Name", "Work Email Address", "Associate/Non-Associate", "FLSA Status", "Employee Type ", "Employee Class", "Employee Status Code", "Employee Status", "Last Day of Work", "Expected Return Date", "Actual Last Day of Leave", "Service Date", "Original Hire Date", "Last Hire Date", "Termination Date", "Action Date", "Effective Date", "Sequence Number", "Event Type", "Action Code", "Action", "Reason Code", "Reason", "Full/Part Time Code", "FTE Number", "Company Code", "Company", "Business Unit Code", "Business Unit", "Acquisition Indicator", "Acquisition Company", "Acquisition Legal Day 1", "Job Level Code", "Job Level", "Job Code", "Job", "Job Family", "Job Entry Date", "Position Entry Date", "Supervisor Employee ID", "Supervisor Name", "Supervisor Email", "Reports-To 1", "Reports-To 2", "Reports-To 3", "Reports-To 4", "Reports-To 5", "Reports-To 6", "Reports-To 7", "Reports-To 8", "Reports-To 9", "Reports-To 10", "Org Level 1", "Org Level 2", "Org Level 3", "Org Level 4", "Org Level 5", "Org Level 6", "Org Level 7", "Org Level 8", "Org Level 9", "Org Level 10", "Org Level 11", "Org Level 12", "Org Level 13", "Org Level 14", "Org Level 15", "DID", "Department Name", "Department Entry Date", "Location Code", "Location", "Internal Zip", "Work City", "Work State", "Work Zip Code", "Work Country", "Remote Worker Indicator", "External Hire Indicator", "Transfer Indicator", "Voluntary Attrition Indicator", "InVoluntary Attrition Indicator", "Promotion Indicator", "Birthday"
          ]
        });
      });
  }

  exportPdf(): void {
    let service, pdfName = '';
    if(this.model.view === 'Compensation') {
      pdfName = 'Month-End Snapshot - Compensation';
    } else if(this.model.view === 'Personal') {
      pdfName = 'Month-End Snapshot - Personal';
    } else if(this.model.view === 'Diversity'){
      pdfName = 'Month-End Snapshot - Diversity';
    }else if(this.model.view === 'Performance') {
      pdfName = 'Month-End Snapshot - Performance Management';
    } else if(this.model.view === 'All') {
      pdfName = 'Month-End Snapshot - All Data';
    } else {
      pdfName = 'Month-End Snapshot - General';
    }
    service = this.fService.getEvtReportCsv(this.model);
    const headers = [
      {title: "Employee ID", dataKey: "c50"},
      {title: "EUID", dataKey: "c51"}, 
      {title: "Alternate Employee ID", dataKey: "c48"},
      {title: "Prefix Name", dataKey: "c56"},
      {title: "First Name", dataKey: "c52"}, 
      {title: "Middle Name", dataKey: "c55"},
      {title: "Last Name", dataKey: "c54"},
      {title: "Full Name", dataKey: "c53"}, 
      {title: "Work Email Address", dataKey: "c57"},
      {title: "Associate/Non-Associate", dataKey: "c29"},
      {title: "FLSA Status", dataKey: "c60"},
      {title: "Employee Type", dataKey: "c37"},
      {title: "Employee Class", dataKey: "c34"},
      {title: "Employee Status Code", dataKey: "c35"},
      {title: "Employee Status", dataKey: "c36"},
      {title: "Last Day of Work", dataKey: "c88"},
      {title: "Expected Return Date", dataKey: "c58"},
      {title: "Actula Last Day of Leave", dataKey: "c87"},
      {title: "Service Date", dataKey: "c85"},
      {title: "Original Hire Date", dataKey: "c73"},
      {title: "Last Hire Date", dataKey: "c66"},
      {title: "Termination Date", dataKey: "c86"},
      {title: "Action Date", dataKey: "c1"},
      {title: "Effective Date", dataKey: "c20"},
      {title: "Sequence Number", dataKey: "c45"},
      {title: "Event Type", dataKey: "c24"},
      {title: "Action Code", dataKey: "c25"},
      {title: "Action", dataKey: "c28"},
      {title: "Reason Code", dataKey: "c26"},
      {title: "Reason", dataKey: "c27"},
      {title: "Full/Part Time Code", dataKey: "c40"},
      {title: "FTE Number", dataKey: "c39"},
      {title: "Company Code", dataKey: "c32"},
      {title: "Company", dataKey: "c33"},
      {title: "Business Unit Code", dataKey: "c30"},
      {title: "Business Unit", dataKey: "c31"},
      {title:"Acqusition Indicator", dataKey: "c22"},
      {title:"Acquisition Company", dataKey: "c21"},
      {title:"Acquisition Legal Day 1", dataKey: "c23"},
      {title:"Job Level Code", dataKey: "c63"},
      {title:"Job Level", dataKey: "c64"},
      {title:"Job Code", dataKey: "c61"},
      {title:"Job", dataKey: "c65"},
      {title:"Job Family", dataKey: "c62"},
      {title:"Job Entry Date", dataKey: "c59"},
      {title:"Position Entry Date", dataKey: "c74"},
      {title:"Supervisor Employee ID", dataKey: "c89"},
      {title:"Supervisor Name", dataKey: "c90"},
      {title:"Supervisor Email", dataKey: "c91"},
      {title:"Reports-To 1", dataKey: "c75"},
      {title:"Reports-To 2", dataKey: "c76"},
      {title:"Reports-To 3", dataKey: "c77"},
      {title:"Reports-To 4", dataKey: "c78"},
      {title:"Reports-To 5", dataKey: "c79"},
      {title:"Reports-To 6", dataKey: "c80"},
      {title:"Reports-To 7", dataKey: "c81"},
      {title:"Reports-To 8", dataKey: "c82"},
      {title:"Reports-To 9", dataKey: "c83"},
      {title:"Reports-To 10", dataKey: "c84"},
      {title:"Org Level 1", dataKey: "c5"},
      {title:"Org Level 2", dataKey: "c12"},
      {title:"Org Level 3", dataKey: "c13"},
      {title:"Org Level 4", dataKey: "c14"},
      {title:"Org Level 5", dataKey: "c15"},
      {title:"Org Level 6", dataKey: "c16"},
      {title:"Org Level 7", dataKey: "c17"},
      {title:"Org Level 8", dataKey: "c18"},
      {title:"Org Level 9", dataKey: "c19"},
      {title:"Org Level 10", dataKey: "c6"},
      {title:"Org Level 11", dataKey: "c7"},
      {title:"Org Level 12", dataKey: "c8"},
      {title:"Org Level 13", dataKey: "c9"},
      {title:"Org Level 14", dataKey: "c10"},
      {title:"Org Level 15", dataKey: "c11"},
      {title:"DID", dataKey: "c3"},
      {title:"Department Name", dataKey: "c4"},
      {title:"Department Entry Date", dataKey: "c2"},
      {title:"Location Code", dataKey: "c67"},
      {title:"Location", dataKey: "c68"},
      {title:"Internal Zip", dataKey: "c41"},
      {title:"Work City", dataKey: "c69"},
      {title:"Work State", dataKey: "c71"},
      {title:"Work Zip Code", dataKey: "c72"},
      {title:"Work Country", dataKey: "c70"},
      {title:"External Hire Indicator", dataKey: "c38"},
      {title:"Transfer Indicator", dataKey: "c46"},
      {title:"Voluntary Attrition Indicator", dataKey: "c47"},
      {title:"InVoluntary Attrition Indicator", dataKey: "c42"},
      {title:"Promotion Indicator", dataKey: "c43"},
      {title:"Birthday", dataKey: "c49"}
    ];
    const doc = new jsPDF('l', 'pt', [800, 10700]);
    service.then(res => {
        doc.autoTable(headers, res, {tableWidth: 10660, theme: 'plain'});
        doc.save(pdfName);
      });
  }

  getEvtReport(data: EomData): void {
    this.fService.getEvtReport(data)
      .then(results => {
        this.results = results;
        if(results !== undefined && results.length > 0) {
          document.getElementById('loader').style.display = 'none';
        } else if(results!== undefined && results.length <= 0) {
          document.getElementById('loader').style.display = 'none';
          alert('Your search did not returned any results!');
        }
      });
  }
  // getEvtReportComp(data: EomData): void {
  //   this.fService.getEvtReportCompensation(data)
  //     .then(results => {
  //       this.results = results;
  //       if(results !== undefined) {
  //         document.getElementById('loader').style.display = 'none';
  //       }
  //     });
  // }
  // getEvtReportPer(data: EomData): void {
  //   this.fService.getEvtReportPersonal(data)
  //     .then(results => {
  //       this.results = results;
  //       if(results !== undefined) {
  //         document.getElementById('loader').style.display = 'none';
  //       }
  //     });
  // }
  // getEvtReportDive(data: EomData): void {
  //   this.fService.getEvtReportDiversity(data)
  //     .then(results => {
  //       this.results = results;
  //       if(results !== undefined) {
  //         document.getElementById('loader').style.display = 'none';
  //       }
  //     });
  // }
  // getEvtReportPerformance(data: EomData): void {
  //   this.fService.getEvtReportPerformance(data)
  //     .then(results => {
  //       this.results = results;
  //       if(results !== undefined) {
  //         document.getElementById('loader').style.display = 'none';
  //       }
  //     });
  // }
  // getEvtReportAll(data: EomData): void {
  //   this.fService.getEvtReportAll(data)
  //     .then(results => {
  //       this.results = results;
  //       if(results !== undefined) {
  //         document.getElementById('loader').style.display = 'none';
  //       }
  //     });
  // }

  buildEventType(form: any) {
    const arr: string[] = [];
    if (form.hire) {
      arr.push('Hire');
    }
    if (form.jobchange) {
      arr.push('Job/Grade Change');
    }
    if (form.leave) {
      arr.push('Leave of Absence');
    }
    if (form.payrate) {
      arr.push('Pay Rate Change');
    }
    if (form.profilechange) {
      arr.push('Profile Change');
    }
    if (form.transfer) {
      arr.push('Transfer');
    }
    if (form.termination) {
      arr.push('Termination');
    }

    this.model.events = arr; //.map(evt => `'${evt}'`).join(',');
  }

  buildParams(form: any): void {
    this.model.date = this.daterange.formatted.substring(0, 10);
    this.model.date2 = this.daterange.formatted.substring(this.daterange.formatted.length - 10);


    this.buildEventType(form);

    if (this.jobLvlOptionsModel.length > 0) {
      const joblvl_arr = [];
      this.jobLvlOptionsModel.forEach((elem) => {
        joblvl_arr.push(this.jobLevels[elem - 1].job_lvl_cd);
        this.model.job_level = joblvl_arr;
      });
    } else {
      this.model.job_level = [];
    }

    if (this.buildingOptionsModel.length > 0) {
      const arr = [];
      this.buildingOptionsModel.forEach((elem) => {
        arr.push(this.buildings[elem - 1].loc_cd);
        this.model.building = arr;
      });
    } else {
      this.model.building = [];
    }

    if (this.deptOptionsModel.length > 0) {
      const arr = [];
      this.deptOptionsModel.forEach((elem) => {
        arr.push(this.departments[elem - 1].dept_id);
        this.model.dept = arr;
      });
    } else {
      this.model.dept = [];
    }

    if (this.countryOptionsModel.length > 0) {
      const country_arr = [];
      this.countryOptionsModel.forEach((elem) => {
        country_arr.push(this.countries[elem - 1]);
        this.model.country = country_arr;
      });
    } else {
      this.model.country = [];
    }

    if (this.stateOptionsModel.length > 0) {
      const state_arr = [];
      this.stateOptionsModel.forEach((elem) => {
        state_arr.push(this.states[elem - 1]);
        this.model.state = state_arr;
      });
    } else {
      this.model.state = [];
    }

    if (this.cityOptionsModel.length > 0) {
      const city_arr = [];
      this.cityOptionsModel.forEach((elem) => {
        city_arr.push(this.cities[elem - 1]);
        this.model.city = city_arr;
      });
    } else {
      this.model.city = [];
    }

    if (this.repTo1OptionsModel.length > 0) {
      const rep_arr = [];
      this.repTo1OptionsModel.forEach((elem) => {
        rep_arr.push(this.repTo1[elem - 1]);
        this.model.reports_to1 = rep_arr;
      });
    } else {
      this.model.reports_to1 = [];
    }

    if (this.repTo2OptionsModel.length > 0) {
      const rep_arr = [];
      this.repTo2OptionsModel.forEach((elem) => {
        rep_arr.push(this.repTo2[elem - 1]);
        this.model.reports_to2 = rep_arr;
      });
    } else {
      this.model.reports_to2 = [];
    }

    if (this.repTo3OptionsModel.length > 0) {
      const rep_arr = [];
      this.repTo3OptionsModel.forEach((elem) => {
        rep_arr.push(this.repTo3[elem - 1]);
        this.model.reports_to3 = rep_arr;
      });
    } else {
      this.model.reports_to3 = [];
    }

    if (this.repTo4OptionsModel.length > 0) {
      const rep_arr = [];
      this.repTo4OptionsModel.forEach((elem) => {
        rep_arr.push(this.repTo4[elem - 1]);
        this.model.reports_to4 = rep_arr;
      });
    } else {
      this.model.reports_to4 = [];
    }

    if (this.orgLvl1OptionsModel.length > 0) {
      const org1_arr = [];
      this.orgLvl1OptionsModel.forEach((elem) => {
        org1_arr.push(this.orgLvl1[elem - 1]);
        this.model.org_level1 = org1_arr;
      });
    } else {
      this.model.org_level1 = [];
    }

    if (this.orgLvl2OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl1OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl2[elem - 1]);
        this.model.org_level2 = org_arr;
      });
    } else {
      this.model.org_level2 = [];
    }

    if (this.orgLvl3OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl3OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl3[elem - 1]);
        this.model.org_level3 = org_arr;
      });
    } else {
      this.model.org_level3 = [];
    }

    if (this.orgLvl4OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl4OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl4[elem - 1]);
        this.model.org_level4 = org_arr;
      });
    } else {
      this.model.org_level4 = [];
    }

    if (this.orgLvl5OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl5OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl5[elem - 1]);
        this.model.org_level5 = org_arr;
      });
    } else {
      this.model.org_level5 = [];
    }

    if (this.orgLvl6OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl6OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl6[elem - 1]);
        this.model.org_level6 = org_arr;
      });
    } else {
      this.model.org_level6 = [];
    }

    if (this.orgLvl7OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl7OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl7[elem - 1]);
        this.model.org_level7 = org_arr;
      });
    } else {
      this.model.org_level7 = [];
    }

    if (this.orgLvl8OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl8OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl8[elem - 1]);
        this.model.org_level8 = org_arr;
      });
    } else {
      this.model.org_level8 = [];
    }

    if (this.orgLvl9OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl9OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl9[elem - 1]);
        this.model.org_level9 = org_arr;
      });
    } else {
      this.model.org_level9 = [];
    }

    if (this.orgLvl10OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl10OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl10[elem - 1]);
        this.model.org_level10 = org_arr;
      });
    } else {
      this.model.org_level10 = [];
    }

    if (this.orgLvl11OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl11OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl11[elem - 1]);
        this.model.org_level11 = org_arr;
      });
    } else {
      this.model.org_level11 = [];
    }

    if (this.orgLvl12OptionsModel.length > 0) {
      const org_arr = [];
      this.orgLvl12OptionsModel.forEach((elem) => {
        org_arr.push(this.orgLvl12[elem - 1]);
        this.model.org_level12 = org_arr;
      });
    } else {
      this.model.org_level12 = [];
    }
  }

  getCols(): void {
    this.perfView = localStorage.getItem('performance') === 'y' ? true : false;
    this.personalView = localStorage.getItem('personal') === 'y' ? true : false;
    this.compView = localStorage.getItem('compensation') === 'y' ? true : false;
    this.diversityView = localStorage.getItem('diversity') === 'y' ? true : false;
    this.allView = localStorage.getItem('all') === 'y' ? true : false;

    // this.perfView = true;
    // this.personalView = true;
    // this.compView = true;
    // this.diversityView = true;
    // this.allView = true;
  }

  getRows(): void {

    this.fService.getRows(localStorage.getItem('userid'))
      .then(rows => {
        this.model.rows = rows;
        this.getDepartments(rows);
        this.getReportsTo4(rows);
      });
  }


  getDates(): void {
    this.fService.getDates()
      .then(dates => {
        const arr = [];
        dates.forEach((elem) => {
          arr.push(elem.yymm_num);
        });
        this.dates = arr;
        this.model.date = this.dates[0];
      });
  }

  getJobLevels(): void {
    this.fService.getJobLevels()
      .then(jls => {
        this.jobLevels = jls;
        const jobArr = [];
        jls.forEach((elem, index) => {
          jobArr.push({
            id: index + 1,
            name: elem.job_lvl_cd + ' - ' + elem.job_lvl_desc
          });
        });
        this.jobLvlOptions = jobArr.sort();
      });
  }

  getBuildings(): void {
    this.fService.getBuildings()
      .then(buildings => {
        this.buildings = buildings;
        const arr = [];
        buildings.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem.loc_cd + ' - ' + elem.loc_nm
          });
        });
        this.buildingOptions = arr;
      });
  }

  getDepartments(rows): void {
    this.fService.getDepartments(rows)
      .then(depts => {
        this.departments = depts;
        const arr = [];
        depts.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem.dept_id + ' - ' + elem.dept_nm
          });
        });
        this.deptOptions = arr.sort();
      });
  }

  getCountries(): void {
    this.fService.getCountries()
      .then(countries => {
        this.countries = countries;
        const arr = [];
        countries.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.countryOptions = arr;
      });
  }

  getStates(): void {
    this.fService.getStates()
      .then(states => {
        this.states = states;
        const arr = [];
        states.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.stateOptions = arr;
      });
  }

  getCities(): void {
    this.fService.getCities()
      .then(cities => {
        this.cities = cities;
        const arr = [];
        cities.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.cityOptions = arr;
      });
  }

  getReportsTo1(): void {
    this.fService.getReportsTo1()
      .then(repTo => {
        this.repTo1 = repTo;
        const arr = [];
        repTo.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.repTo1Options = arr;
      });
  }

  getReportsTo2(): void {
    this.fService.getReportsTo2()
      .then(repTo => {
        this.repTo2 = repTo;
        const arr = [];
        repTo.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.repTo2Options = arr;
      });
  }

  getReportsTo3(): void {
    this.fService.getReportsTo3()
      .then(repTo => {
        this.repTo3 = repTo;
        const arr = [];
        repTo.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.repTo3Options = arr;
      });
  }

  getReportsTo4(rows): void {
    this.fService.getReportsTo4(rows)
      .then(repTo => {
        this.repTo4 = repTo;
        const arr = [];
        repTo.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.repTo4Options = arr;
      });
  }

  getOrgLvl1(): void {
    this.fService.getOrgLvl1()
      .then(orgLvl => {
        this.orgLvl1 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl1Options = arr;
      });
  }

  getOrgLvl2(): void {
    this.fService.getOrgLvl2()
      .then(orgLvl => {
        this.orgLvl2 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl2Options = arr;
      });
  }

  getOrgLvl3(): void {
    this.fService.getOrgLvl3()
      .then(orgLvl => {
        this.orgLvl3 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl3Options = arr;
      });
  }

  getOrgLvl4(): void {
    this.fService.getOrgLvl4()
      .then(orgLvl => {
        this.orgLvl4 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl4Options = arr;
      });
  }

  getOrgLvl5(): void {
    this.fService.getOrgLvl5()
      .then(orgLvl => {
        this.orgLvl5 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl5Options = arr;
      });
  }

  getOrgLvl6(): void {
    this.fService.getOrgLvl6()
      .then(orgLvl => {
        this.orgLvl6 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl6Options = arr;
      });
  }

  getOrgLvl7(): void {
    this.fService.getOrgLvl7()
      .then(orgLvl => {
        this.orgLvl7 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl7Options = arr;
      });
  }

  getOrgLvl8(): void {
    this.fService.getOrgLvl8()
      .then(orgLvl => {
        this.orgLvl8 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl8Options = arr;
      });
  }

  getOrgLvl9(): void {
    this.fService.getOrgLvl9()
      .then(orgLvl => {
        this.orgLvl9 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl9Options = arr;
      });
  }

  getOrgLvl10(): void {
    this.fService.getOrgLvl10()
      .then(orgLvl => {
        this.orgLvl10 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl10Options = arr;
      });
  }

  getOrgLvl11(): void {
    this.fService.getOrgLvl11()
      .then(orgLvl => {
        this.orgLvl11 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl11Options = arr;
      });
  }

  getOrgLvl12(): void {
    this.fService.getOrgLvl12()
      .then(orgLvl => {
        this.orgLvl12 = orgLvl;
        const arr = [];
        orgLvl.forEach((elem, index) => {
          arr.push({
            id: index + 1,
            name: elem
          });
        });
        this.orgLvl12Options = arr;
      });
  }
}
