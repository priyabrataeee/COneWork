import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SSOAuthGuard } from '../sso-authentication/sso-authentication-authguard';
import { ReportsAuthGuard } from './reports-authguard.service';
import { ReportAuthGuard } from './report-authguard.service';

import { ReportsComponent } from './reports/reports.component';
import { EventsComponent } from './events/events/events.component';
import { EomComponent }    from './eom/eom/eom.component';

const reportsRoutes: Routes = [
  {
    path: 'reports',
    canActivate: [
      SSOAuthGuard,
      ReportsAuthGuard
    ],
    component: ReportsComponent
  },

  // Employee Events
  {
    path: 'reports/events',
    data: {
      page_id: 6
    },
    canActivate: [
      SSOAuthGuard,
      ReportAuthGuard
    ],
    component: EventsComponent
  },
  // End of Month
  {
    path: 'reports/eom',
    data: {
      page_id: 7
    },
    canActivate: [
      SSOAuthGuard,
      ReportAuthGuard
    ],
    component: EomComponent
  }

];

@NgModule({
  imports: [
    RouterModule.forChild(reportsRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    ReportAuthGuard
  ]
})
export class ReportsRoutingModule {}
