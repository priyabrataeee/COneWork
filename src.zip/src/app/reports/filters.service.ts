import { Injectable }    from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class FiltersService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  private url = 'api/filter';
  private eomUrl = 'api/eom';
  private evtUrl = 'api/evt';
  private evtCompUrl = 'api/compensationEvt';
  private evtPersUrl = 'api/personalEvt';
  private evtDiveUrl = 'api/diversityEvt';
  private evtPerfUrl = 'api/performanceEvt';
  private evtAllUrl = 'api/alldataEvt';

  constructor(private http: Http) {}

  getRows(eid: string): Promise<string[]> {
    const url = `${this.url}/rows?eid=${eid}`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getEomReport(data: any): Promise<any[]> {
    const url = `${this.eomUrl}/results`;
    return this.http
      .post(url, JSON.stringify(data), {headers: this.headers})
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEomReportCsv(data: any): Promise<any[]> {
    const url = `${this.eomUrl}/results?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReport(data: any): Promise<any[]> {
    const url = `${this.evtUrl}/results`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportCsv(data: any): Promise<any[]> {
    const url = `${this.evtUrl}/results?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportCompensationCsv(data: any): Promise<any[]> {
    const url = `${this.evtCompUrl}/results_compensation?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportPersonalCsv(data: any): Promise<any[]> {
    const url = `${this.evtPersUrl}/results_personal?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportDiversityCsv(data: any): Promise<any[]> {
    const url = `${this.evtDiveUrl}/results_diversity?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportPerformanceCsv(data: any): Promise<any[]> {
    const url = `${this.evtPerfUrl}/results_performance?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportAllCsv(data: any): Promise<any[]> {
    const url = `${this.evtAllUrl}/results_all?format=csv`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }
  
  getEvtReportCompensation(data: any): Promise<any[]> {
    const url = `${this.evtCompUrl}/results_compensation`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportPersonal(data: any): Promise<any[]> {
    const url = `${this.evtPersUrl}/results_personal`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportDiversity(data: any): Promise<any[]> {
    const url = `${this.evtDiveUrl}/results_diversity`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportPerformance(data: any): Promise<any[]> {
    const url = `${this.evtPerfUrl}/results_performance`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getEvtReportAll(data: any): Promise<any[]> {
    const url = `${this.evtAllUrl}/results_all`;
    return this.http
      .post(url, JSON.stringify(data), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getDates(): Promise<any[]> {
    const url = `${this.url}/dates`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getJobLevels(): Promise<any[]> {
    const url = `${this.url}/joblevels`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getBuildings(): Promise<any[]> {
    const url = `${this.url}/building`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getDepartments(rows): Promise<any[]> {
    const url = `${this.url}/dept`;
    return this.http
      .post(url, JSON.stringify(rows), {headers: this.headers })
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  getCountries(): Promise<string[]> {
    const url = `${this.url}/countries`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getStates(): Promise<string[]> {
    const url = `${this.url}/states`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getCities(): Promise<string[]> {
    const url = `${this.url}/cities`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getReportsTo1(): Promise<string[]> {
    const url = `${this.url}/rep1`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getReportsTo2(): Promise<string[]> {
    const url = `${this.url}/rep2`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getReportsTo3(): Promise<string[]> {
    const url = `${this.url}/rep3`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getReportsTo4(rows): Promise<string[]> {
    const url = `${this.url}/rep4`;
    return this.http
      .post(url, JSON.stringify(rows), { headers: this.headers })
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl1(): Promise<string[]> {
    const url = `${this.url}/org1`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl2(): Promise<string[]> {
    const url = `${this.url}/org2`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl3(): Promise<string[]> {
    const url = `${this.url}/org3`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl4(): Promise<string[]> {
    const url = `${this.url}/org4`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl5(): Promise<string[]> {
    const url = `${this.url}/org5`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl6(): Promise<string[]> {
    const url = `${this.url}/org6`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl7(): Promise<string[]> {
    const url = `${this.url}/org7`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl8(): Promise<string[]> {
    const url = `${this.url}/org8`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl9(): Promise<string[]> {
    const url = `${this.url}/org9`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl10(): Promise<string[]> {
    const url = `${this.url}/org10`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl11(): Promise<string[]> {
    const url = `${this.url}/org11`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }

  getOrgLvl12(): Promise<string[]> {
    const url = `${this.url}/org12`;
    return this.http
      .get(url)
      .toPromise()
      .then(res => res.json() as string[])
      .catch();
  }
}
