import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
}                     from '@angular/router';
import { ReportsAuthService }  from './reports-auth.service';


@Injectable()
export class ReportsAuthGuard implements CanActivate {

  constructor (
    private authService: ReportsAuthService
  ) {}
  canActivate (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return this.authService
      .haveDatasourceAccess(
        localStorage.getItem('userid'),
        1
      );
  }
}
