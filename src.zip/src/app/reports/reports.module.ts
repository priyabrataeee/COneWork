import { NgModule }     from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';

import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { MyDateRangePickerModule } from 'mydaterangepicker';

import { ReportsRoutingModule }  from './reports-routing.module';
import { ReportsAuthService }    from './reports-auth.service';
import { ReportsAuthGuard }      from './reports-authguard.service';
import { ReportAuthGuard }       from './report-authguard.service';

import { EventsComponent }  from './events/events/events.component';
import { EomComponent }     from './eom/eom/eom.component';
import { ReportsComponent } from './reports/reports.component';

import { FiltersService }   from './filters.service';
import { DeptService }      from './eom/dept-select/dept.service';
import { DeptSelectComponent } from './eom/dept-select/dept-select.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MultiselectDropdownModule,
    MyDateRangePickerModule,
    ReportsRoutingModule
  ],
  declarations: [
    EventsComponent,
    EomComponent,
    ReportsComponent,
    DeptSelectComponent
  ],
  providers: [
    ReportsAuthService,
    ReportsAuthGuard,
    ReportAuthGuard,
    FiltersService,
    DeptService
  ]
})
export class ReportsModule { }
