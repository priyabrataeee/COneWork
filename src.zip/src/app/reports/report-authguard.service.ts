import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
}                     from '@angular/router';
import { ReportsAuthService }  from './reports-auth.service';


@Injectable()
export class ReportAuthGuard implements CanActivate {

  constructor (
    private authService: ReportsAuthService
  ) {}
  canActivate (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return this.authService
      .havePageAccess(
        localStorage.getItem('userid'),
        route.data.page_id
      );
  }
}
