import { Injectable } from '@angular/core';
import { Http }       from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';

import { IMultiSelectOption } from 'angular-2-dropdown-multiselect';

@Injectable()
export class DeptService {

  private url = 'api/filter/dept';

  constructor(private http: Http) { }

  getDepartments(): Promise<any[]> {
    return this.http
      .get(this.url)
      .toPromise()
      .then(res => res.json() as any[])
      .catch();
  }

  search(term: string): Observable<IMultiSelectOption[]> {
    const url = `${this.url}?dept=%${term}%`;
    return this.http
      .get(url)
      .map(res => {
        const arr = [];
        res.json().forEach((elem, idx) => {
          arr.push({
            id: idx + 1,
            name: elem.dept_id + ' - ' + elem.dept_nm
          });
        });
        return arr as IMultiSelectOption[];
      });
  }
}
