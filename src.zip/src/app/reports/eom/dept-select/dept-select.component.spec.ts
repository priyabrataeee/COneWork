import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeptSelectComponent } from './dept-select.component';

describe('DeptSelectComponent', () => {
  let component: DeptSelectComponent;
  let fixture: ComponentFixture<DeptSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeptSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeptSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
