import { Component, OnInit } from '@angular/core';

import { Observable }        from 'rxjs/Observable';
import { Subject }           from 'rxjs/Subject';

import 'rxjs/add/observable/of';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

import {
  IMultiSelectOption,
  IMultiSelectSettings,
  IMultiSelectTexts
} from 'angular-2-dropdown-multiselect';

import { DeptService } from './dept.service';

@Component({
  selector: 'app-dept-select',
  templateUrl: './dept-select.component.html',
  styleUrls: ['./dept-select.component.css']
})
export class DeptSelectComponent implements OnInit {

  private searchTerms = new Subject<string>();

  msSettings: IMultiSelectSettings = {
    enableSearch: true,
    buttonClasses: 'btn btn-secondary'
  };

  msTexts: IMultiSelectTexts = {
    defaultTitle: 'Select Department'
  };

  msOptionsModel: string[];
  msOptions: Observable<IMultiSelectOption[]>;
  msOption: IMultiSelectOption[];

  constructor(
    private deptService: DeptService
  ) { }

  search(term: string): void {
    this.searchTerms.next(term);
  }

  ngOnInit() {
    this.getDepts();
    this.msOptions = this.searchTerms
      .debounceTime(300)
      .distinctUntilChanged()
      .switchMap(term => term
        ? this.deptService.search(term)
        : Observable.of<IMultiSelectOption[]>([]))
      .catch(error => {
        console.log(error);
        return Observable.of<IMultiSelectOption[]>([]);
      });
  }

  getDepts(): void {
    this.deptService.getDepartments()
      .then(depts => {
        const arr = [];
        depts.forEach((elem, idx) => {
          arr.push({
            id: idx + 1,
            name: elem.dept_id + ' - ' + elem.dept_nm
          })
        });
        this.msOption = arr;
      });
  }

}
