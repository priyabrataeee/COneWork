
import { Injectable }    from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class ReportsAuthService {
  private headers = new Headers({'Content-Type': 'application/json'});
  private url = 'api/user';   // API URL

  constructor(private http: Http) {}

  haveDatasourceAccess(eid: string, ds: number): Promise<boolean> {
    const url = `${this.url}/?eid=${eid}&ds=${ds}`;
    return this.http.get(url)
      .toPromise()
      .then(res => (res.json().count > 0) as boolean)
      .catch(this.handleError);
  }

  havePageAccess(eid: string, page_id: number): Promise<boolean> {
    const url = `${this.url}/?eid=${eid}&page_id=${page_id}`;
    return this.http.get(url)
      .toPromise()
      .then(res => (res.json().count > 0) as boolean)
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
