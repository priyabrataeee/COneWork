import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SSOAuthGuard } from './sso-authentication/sso-authentication-authguard';
import { SSOAuthComponent } from './sso-authentication/sso-authentication-component';

const routes: Routes = [
  { path: 'app-sso-auth-component', component: SSOAuthComponent },
  // { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', canActivate: [SSOAuthGuard], component: DashboardComponent },
  { path: '**', redirectTo: 'app-sso-auth-component' }
];

@NgModule({

  imports: [
    RouterModule.forRoot(
      routes,
      { enableTracing: false }
    )
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
