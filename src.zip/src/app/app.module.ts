import { BrowserModule } from '@angular/platform-browser';
import { NgModule }      from '@angular/core';
import { HttpModule }    from '@angular/http';
import { FormsModule }   from '@angular/forms';

import { AppComponent }       from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';

import { SSOAuthService}    from './sso-authentication/sso-authentication-service';
import { SSOAuthComponent } from './sso-authentication/sso-authentication-component';
import { SSOAuthGuard }     from './sso-authentication/sso-authentication-authguard';

import { UserInfoService }  from './components/dashboard/user-info.service';


import { AdminModule }              from './admin/admin.module';
import { ReportsModule }            from './reports/reports.module';
import { AppRoutingModule }         from './app-routing.module';


@NgModule({
  declarations: [
    AppComponent,
    SSOAuthComponent,
    DashboardComponent,
    SidebarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AdminModule,
    ReportsModule,
    AppRoutingModule
  ],
  providers: [
    SSOAuthService,
    SSOAuthGuard,
    UserInfoService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
