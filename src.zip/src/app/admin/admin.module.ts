import { NgModule }     from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';
import { HttpModule }    from '@angular/http';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent }     from './admin/admin.component';

import { UsersListComponent }  from './users/users-list/users-list.component';
import { UserDetailComponent } from './users/user-detail/user-detail.component';
import { UserService }         from './users/user.service';

import { DatabasesListComponent }   from './databases/databases-list/databases-list.component';
import { DatabaseDetailComponent } from './databases/database-detail/database-detail.component';
import { DatabaseSearchComponent } from './databases/database-search/database-search.component';
import { DatabaseService }         from './databases/database.service';
import { DatabaseSearchService }         from './databases/database-search.service';

import { PagesListComponent  } from './pages/pages-list/pages-list.component';
import { PageDetailComponent } from './pages/page-detail/page-detail.component';
import { PageSearchComponent } from './pages/page-search/page-search.component';
import { PageService }         from './pages/page.service';
import { PageSearchService }   from './pages/page-search.service';

import { CompaniesListComponent } from './companies/companies-list/companies-list.component';
import { CompanyDetailComponent } from './companies/company-detail/company-detail.component';
import { CompanyService }         from './companies/company.service';
import { CompanySearchComponent } from './companies/company-search/company-search.component';
import { CompanySearchService }   from './companies/company-search.service';

import { UserSecurityComponent } from './users/user-security/user-security.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpModule,
    AdminRoutingModule
  ],
  declarations: [
    AdminComponent,
    UsersListComponent,
    UserDetailComponent,
    DatabasesListComponent,
    DatabaseDetailComponent,
    DatabaseSearchComponent,
    PagesListComponent,
    PageDetailComponent,
    PageSearchComponent,
    CompaniesListComponent,
    CompanyDetailComponent,
    CompanySearchComponent,
    UserSecurityComponent
  ],
  exports: [  ],
  providers: [
    UserService,
    DatabaseService,
    DatabaseSearchService,
    PageService,
    PageSearchService,
    CompanyService,
    CompanySearchService
  ]
})
export class AdminModule { }
