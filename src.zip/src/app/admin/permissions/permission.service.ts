import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

import { Permission }    from './permission';

@Injectable()
export class PermissionService {
  private headers = new Headers({
    'Content-Type': 'application/json'
  });
  private url = 'api/permission';   // API URL

  constructor(private http: Http) {}

  createPerm(perm: Permission): Promise<void> {
    return this.http
      .post(this.url, JSON.stringify(perm), { headers: this.headers})
      .toPromise()
      .then(() => null)
      .catch(this.handleError);
  }

  deleteDbPerm(db: number, user: string): Promise<void> {
    const url = `${this.url}/?user=${user}&database=${db}`;
    return this.http.get(url)
      .toPromise()
      .then(() => null)
      .catch(this.handleError);
  }

  deletePgPerm(pg: number, user: string): Promise<void> {
    const url = `${this.url}/?user=${user}&page=${pg}`;
    return this.http.get(url)
      .toPromise()
      .then(() => null)
      .catch(this.handleError);
  }

  deleteCpPerm(cp: string, user: string): Promise<void> {
    const url = `${this.url}/?user=${user}&company=${cp}`;
    return this.http.get(url)
      .toPromise()
      .then(() => null)
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
