export class Permission {
  id: number;
  eid: string;
  database_id: number;
  page_id: number;
  ec_id: string;
  ec_nm: string;
  created_at: Date;
  created_by: string;
  updated_at: Date;
  updated_by: string;
}
