import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SSOAuthGuard } from '../sso-authentication/sso-authentication-authguard';

import { AdminComponent }       from './admin/admin.component';
import { AdminAuthGuard }       from './admin-authguard.service';

import { UserAuthGuard }        from './users/user-authguard.service';
import { UsersListComponent }   from './users/users-list/users-list.component';
import { UserDetailComponent }  from './users/user-detail/user-detail.component';
import { UserSecurityComponent } from './users/user-security/user-security.component';

import { DatabasesListComponent } from './databases/databases-list/databases-list.component';
import { DatabaseDetailComponent } from './databases/database-detail/database-detail.component';

import { PagesListComponent }      from './pages/pages-list/pages-list.component';
import { PageDetailComponent }     from './pages/page-detail/page-detail.component';

import { CompaniesListComponent }  from './companies/companies-list/companies-list.component';
import { CompanyDetailComponent }  from './companies/company-detail/company-detail.component';

const adminRoutes: Routes = [
  {
    path: 'admin',
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard
    ],
    component: AdminComponent
  },

  // Users
  {
    path: 'admin/users',
    data: {
      page_id: 1
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: UsersListComponent
  },
  {
    path: 'admin/user/:id',
    data: {
      page_id: 1
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: UserDetailComponent
  },

  // Databases
  {
    path: 'admin/databases',
    data: {
      page_id: 2
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: DatabasesListComponent
  },
  {
    path: 'admin/database/:id',
    data: {
      page_id: 2
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: DatabaseDetailComponent
  },

  // Pages
  {
    path: 'admin/pages',
    data: {
      page_id: 3
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: PagesListComponent
  },
  {
    path: 'admin/page/:id',
    data: {
      page_id: 3
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: PageDetailComponent
  },

  // Companies
  {
    path: 'admin/companies',
    data: {
      page_id: 4
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: CompaniesListComponent
  },
  {
    path: 'admin/company/:id',
    data: {
      page_id: 4
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: CompanyDetailComponent
  },

  // Security
  {
    path: 'admin/security/:id',
    data: {
      page_id: 5
    },
    canActivate: [
      SSOAuthGuard,
      AdminAuthGuard,
      UserAuthGuard
    ],
    component: UserSecurityComponent
  }

];

@NgModule({
  imports: [
    RouterModule.forChild(adminRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    AdminAuthGuard,
    UserAuthGuard
  ]
})
export class AdminRoutingModule {}
