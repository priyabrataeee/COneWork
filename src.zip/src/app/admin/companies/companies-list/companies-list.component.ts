import { Component, OnInit } from '@angular/core';
import { Router }            from '@angular/router';
import { Location }          from '@angular/common';

import { Company }           from '../company';
import { CompanyService }    from '../company.service';

@Component({
  selector: 'app-companies-list',
  templateUrl: './companies-list.component.html',
  styleUrls: ['./companies-list.component.css']
})
export class CompaniesListComponent implements OnInit {
  companies: Company[];
  selectedCompany: Company;
  newCompany: Company;

  constructor(
    private companyService: CompanyService,
    private router: Router,
    private location: Location
  ) { }

  getCompanies(): void {
    this.companyService
        .getCompanies()
        .then(companies => this.companies = companies);
  }

  ngOnInit() {
    this.getCompanies();
    this.newCompany = new Company();
  }

  add(company: Company): void {
    company.created_by = localStorage.getItem('userid');
    this.companyService.create(company)
        .then(newCompany => {
          this.companies.push(newCompany);
          this.selectedCompany = null;
        });
  }

  onSelect(company: Company): void {
    this.router.navigate(['/admin/company', company.id]);
  }

  gotoDetail(): void {
    this.router.navigate(['/admin/company', this.selectedCompany.id]);
  }

  goBack(): void {
    this.location.back();
  }
}
