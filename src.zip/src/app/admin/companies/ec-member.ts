export class EcMember {
  ec_id: string;
  ec_nm: string;
}
