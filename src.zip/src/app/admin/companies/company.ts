export class Company {
  id: number;
  ec_id: string;
  ec_nm: string;
  created_at: Date;
  created_by: string;
  updated_at: Date;
  updated_by: string;
}
