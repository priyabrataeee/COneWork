import { Injectable } from '@angular/core';
import { Http }       from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { EcMember } from './ec-member';

@Injectable()
export class CompanySearchService {

  constructor(private http: Http) {}

  search(term: string): Observable<EcMember[]> {
    return this.http
               .get(`api/company/?name=%${term}%`)
      .map(res => res.json() as EcMember[]);
  }
}
