import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
}                     from '@angular/router';
import { Cookie }     from 'ng2-cookies/ng2-cookies';
import { User }         from './user';
import { UserService }  from './user.service';


@Injectable()
export class UserAuthGuard implements CanActivate {

  constructor (
    private userService: UserService
  ) {}
  canActivate (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return this.userService
      .havePageAccess(
        localStorage.getItem('userid'),
        route.data.page_id
      );
  }
}
