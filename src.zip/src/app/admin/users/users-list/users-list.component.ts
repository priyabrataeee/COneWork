import { Component, OnInit } from '@angular/core';
import { Router }            from '@angular/router';
import { Location }                 from '@angular/common';

import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  users: User[];
  selectedUser: User;
  newUser: User;
  totalPages: number[];

  constructor(
    private userService: UserService,
    private router: Router,
    private location: Location
  ) { }

  getUsers(): void {
    this.userService
        .getUsers()
        .then(users => {
          this.users = users;
          this.totalPages = [];
          if(users[0].count > 10) {
            if(users[0].count%10 !== 0) {
              const pages = users[0].count/10 + 1;
              for(let i=1; i< pages; i++) {
                this.totalPages.push(i);
              }
            } else {
              const pages = users[0].count/10;
              for(let i=1; i< pages; i++) {
                this.totalPages.push(i);
              }
            }
          }
        });
  }

  ngOnInit() {
    this.getUsers();
    this.newUser = new User();
  }

  getNextUsers(next_user: number): void {
    this.userService
    .getNextUsers(next_user)
    .then(users => this.users = users);
    console.log(next_user);
  }

  add(user: User): void {
    user.eid = user.eid.toLowerCase();
    user.created_by = localStorage.getItem('userid');
    this.userService.create(user)
        .then(newUser => {
          this.users.push(newUser);
          this.selectedUser = null;
        });
  }

  onSelect(user: User): void {
    this.router.navigate(['/admin/user', user.id]);
  }

  gotoDetail(): void {
    this.router.navigate(['/admin/user', this.selectedUser.id]);
  }

  goBack(): void {
    this.location.back();
  }

}
