import { Component, OnInit }        from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Location }                 from '@angular/common';

import 'rxjs/add/operator/switchMap';

import { User }              from '../user';
import { UserService }       from '../user.service';

import { Database }          from '../../databases/database';
import { DatabaseService }   from '../../databases/database.service';

import { Page }              from '../../pages/page';
import { PageService }       from '../../pages/page.service';

import { EcMember }          from '../../companies/ec-member';
import { Company }           from '../../companies/company';
import { CompanyService }    from '../../companies/company.service';

import { Permission }        from '../../permissions/permission';
import { PermissionService } from '../../permissions/permission.service';


@Component({
  selector: 'app-user-security',
  templateUrl: './user-security.component.html',
  styleUrls: ['./user-security.component.css'],
  providers: [PermissionService]
})
export class UserSecurityComponent implements OnInit {
  user: User;
  databases: Database[];
  selectedDb: Database;
  pages: Page[];
  selectedPg: Page;
  ecMembers: EcMember[];
  selectedCp: Company;
  selectedEc: EcMember;

  constructor(
    private userService: UserService,
    private dbService: DatabaseService,
    private permService: PermissionService,
    private pgService: PageService,
    private cpService: CompanyService,
    private route: ActivatedRoute,
    private location: Location
  ) { }

  ngOnInit() {
    this.route.paramMap
    .switchMap((params: ParamMap) => this.userService.getUser(+params.get('id')))
    .subscribe(user => {
      this.user = user;
      this.getDatabases(this.user.eid);
      this.getCompanies(this.user.eid);
      this.getPages(this.user.eid);
    });
  }

  onSelectDB(database: Database) {
    this.selectedDb = database;
  }

  onSelectCompany(ecMember: EcMember) {
    this.selectedEc = ecMember;
  }

  onSelectPage(page: Page) {
    this.selectedPg = page;
  }

  getDatabases(eid: string): void {
    this.dbService.getUserDatabases(eid)
      .then(databases => this.databases = databases);
  }

  addDb(): void {
    const dbPerm = new Permission();
    dbPerm.eid = this.user.eid;
    dbPerm.database_id = this.selectedDb.id;
    dbPerm.created_by = localStorage.getItem('userid');
    this.permService.createPerm(dbPerm)
      .then(() => {
        this.getDatabases(this.user.eid);
      });
  }

  deleteDatabase(id: number): void {
    this.permService.deleteDbPerm(id, this.user.eid)
      .then(() => {
        this.getDatabases(this.user.eid);
      });
  }

  getPages(eid: string): void {
    this.pgService.getUserPages(eid)
      .then(pages => this.pages = pages);
  }

  addPg(): void {
    const pgPerm = new Permission();
    pgPerm.eid = this.user.eid;
    pgPerm.page_id = this.selectedPg.id;
    pgPerm.created_by = localStorage.getItem('userid');
    this.permService.createPerm(pgPerm)
      .then(() => {
        this.getPages(this.user.eid);
      });
  }

  deletePage(id: number): void {
    this.permService.deletePgPerm(id, this.user.eid)
    .then(() => {
      this.getPages(this.user.eid);
    });
  }

  addCp(): void {
    const cpPerm = new Permission();
    cpPerm.eid = this.user.eid;
    cpPerm.ec_id = this.selectedEc.ec_id;
    cpPerm.ec_nm = this.selectedEc.ec_nm;
    cpPerm.created_by = localStorage.getItem('userid');
    this.permService.createPerm(cpPerm)
      .then(() => {
        this.getCompanies(this.user.eid);
      });
  }

  getCompanies(eid: string): void {
    this.cpService.getUserCompanies(eid)
      .then(ecMembers => {
        this.ecMembers = ecMembers;
      });
  }

  deleteCompany(id: string): void {
    this.permService.deleteCpPerm(id, this.user.eid)
    .then(() => {
      this.getCompanies(this.user.eid);
    });
  }

  goBack(): void {
    this.location.back();
  }

}
