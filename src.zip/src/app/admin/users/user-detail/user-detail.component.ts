import { Component, OnInit }        from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Location }                 from '@angular/common';

import 'rxjs/add/operator/switchMap';

import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  user: User;

  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private location: Location
  ) { }

  ngOnInit() {
    this.route.paramMap
        .switchMap((params: ParamMap) => this.userService.getUser(+params.get('id')))
        .subscribe(user => this.user = user);
  }

  save(): void {
    this.user.updated_by = localStorage.getItem('userid');
    this.userService.update(this.user)
        .then(() => this.goBack());
  }

  makeAdmin(): void {
    this.user.admin = true;
    this.save();
  }

  removeAdmin(): void {
    this.user.admin = false;
    this.save();
  }

  modifyAccess(): void {
    this.router.navigate(['/admin/security', this.user.id]);
  }

  delete(user: User): void {
    this.userService
        .delete(user.id)
        .then(() => {
          this.location.back();
        });
  }

  goBack(): void {
    this.location.back();
  }
}
