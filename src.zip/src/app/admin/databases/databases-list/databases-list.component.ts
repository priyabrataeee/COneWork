import { Component, OnInit } from '@angular/core';
import { Router }            from '@angular/router';
import { Location }          from '@angular/common';

import { Database } from '../database';
import { DatabaseService } from '../database.service';

@Component({
  selector: 'app-database',
  templateUrl: './databases-list.component.html',
  styleUrls: ['./databases-list.component.css']
})
export class DatabasesListComponent implements OnInit {
  databases: Database[];
  selectedDb: Database;
  newDb: Database;

  constructor(
    private databaseService: DatabaseService,
    private router: Router,
    private location: Location
  ) { }

  getDatabases(): void {
    this.databaseService
        .getDatabases()
        .then(databases => this.databases = databases);
  }

  ngOnInit() {
    this.getDatabases();
    this.newDb = new Database();
  }

  add(db: Database): void {
    // Validations Here
    db.created_by = localStorage.getItem('userid');
    this.databaseService.create(db)
      .then(newDb => {
        this.databases.push(newDb);
        this.selectedDb = null;
      });
  }

  onSelect(db: Database): void {
    this.router.navigate(['/admin/database', db.id]);
  }

  gotoDetail(): void {
    this.router.navigate(['/admin/database', this.selectedDb.id]);
  }

  goBack(): void {
    this.location.back();
  }
}
