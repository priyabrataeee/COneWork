import { Component, OnInit } from '@angular/core';
import { Router }            from '@angular/router';
import { Location }          from '@angular/common';

import { Page } from '../page';
import { PageService } from '../page.service';

@Component({
  selector: 'app-page',
  templateUrl: './pages-list.component.html',
  styleUrls: ['./pages-list.component.css']
})
export class PagesListComponent implements OnInit {

  pages: Page[];
  selectedPage: Page;
  newPage: Page;

  constructor(
    private pageService: PageService,
    private router: Router,
    private location: Location
  ) { }

  getPages(): void {
    this.pageService
        .getPages()
        .then(pages => this.pages = pages);
  }

  ngOnInit() {
    this.getPages();
    this.newPage = new Page();
  }

  add(page: Page): void {
    page.created_by = localStorage.getItem('userid');
    this.pageService.create(page)
        .then(newPage => {
          this.pages.push(newPage);
          this.selectedPage = null;
        });
  }

  onSelect(page: Page): void {
    this.router.navigate(['/admin/page', page.id]);
  }

  gotoDetail(): void {
    this.router.navigate(['/admin/page', this.selectedPage.id]);
  }

  goBack(): void {
    this.location.back();
  }

}
