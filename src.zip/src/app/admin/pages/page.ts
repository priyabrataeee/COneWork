export class Page {
    id: number;
    page_name: string;
    created_at: Date;
    created_by: string;
    updated_at: Date;
    updated_by: string;
  }
