import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
}                     from '@angular/router';
import { Cookie }     from 'ng2-cookies/ng2-cookies';
import { User }         from './users/user';
import { UserService }  from './users/user.service';


@Injectable()
export class AdminAuthGuard implements CanActivate {

  constructor (
    private userService: UserService
  ) {}
  canActivate (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return new Promise((resolve) => {
      this.userService
        .getUserByEid(localStorage.getItem('userid'))
        .then(user => {
          resolve(user.admin || user.superuser);
        })
        .catch(err => {
          console.error('An error occurred', err);
          resolve(false);
        });
    });
  }

  canActivateChild (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    return this.canActivate(route, state);
  }

}
