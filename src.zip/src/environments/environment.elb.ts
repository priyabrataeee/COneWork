export const environment = {
  production: false,
  app_url: 'internal-spartan-1647168667.us-east-1.elb.amazonaws.com/'
};
