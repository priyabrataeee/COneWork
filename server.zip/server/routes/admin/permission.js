const express = require('express');
const router = express.Router();
const db = require('../../db/pg');

router.post('/', (req, res) => {
  if (req.body.database_id !== undefined) {
    insertDbPerm(req, res);
  } else if (req.body.page_id !== undefined) {
    insertPgPerm(req, res);
  } else if (req.body.ec_id !== undefined) {
    insertCpPerm(req, res);
  } else {
    console.log(req.body);
    res.statusCode = 500;
    return res.json({
      errors: ['Invalid Parameters to Create Permission']
    });
  }
});

router.get('/', (req, res) => {
  if (req.query['database'] !== undefined) {
    deleteDbPerm(req, res);
  } else if (req.query['page'] !== undefined) {
    deletePgPerm(req, res);
  } else if (req.query['company'] !== undefined) {
    deleteCpPerm(req, res);
  } else {
    res.statusCode = 500;
    return res.json({
      errors: ['Invalid Parameters to Delete Permission']
    });
  }
});

function insertDbPerm(req, res) {
  const perm = {
    name: 'add-db-perm',
    text: 'INSERT INTO db_perms (eid, database_id, created_by) ' +
      'VALUES ($1, $2, $3)',
    values: [
      req.body.eid,
      req.body.database_id,
      req.body.created_by
    ]
  };
  db.query(perm, (err) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create Permission']
      });
    }
    res.statusCode = 201;
    res.send('success');
  });
}

function deleteDbPerm(req, res) {
  const perm = {
    name: 'del-db-perm',
    text: 'DELETE FROM db_perms WHERE eid = $1 and database_id = $2',
    values: [
      req.query.user,
      req.query.database
    ]
  };

  db.query(perm, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to delete Database Permission']
      });
    }
    res.statusCode = 201;
    res.send(data.rows[0]);
  });
}

function insertPgPerm(req, res) {
  const perm = {
    name: 'add-pg-perm',
    text: 'INSERT INTO pg_perms (eid, page_id, created_by) ' +
      'VALUES ($1, $2, $3)',
    values: [
      req.body.eid,
      req.body.page_id,
      req.body.created_by
    ]
  };
  db.query(perm, (err) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create Permission']
      });
    }
    res.statusCode = 201;
    res.send('success');
  });
}

function deletePgPerm(req, res) {
  const perm = {
    name: 'del-pg-perm',
    text: 'DELETE FROM pg_perms WHERE eid = $1 and page_id = $2',
    values: [
      req.query.user,
      req.query.page
    ]
  };

  db.query(perm, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to delete Page Permission']
      });
    }
    res.statusCode = 201;
    res.send(data.rows[0]);
  });
}

function insertCpPerm(req, res) {
  const perm = {
    name: 'add-cp-perm',
    text: 'INSERT INTO comp_perms (eid, ec_id, ec_nm, created_by) ' +
      'VALUES ($1, $2, $3, $4)',
    values: [
      req.body.eid,
      req.body.ec_id,
      req.body.ec_nm,
      req.body.created_by
    ]
  };
  db.query(perm, (err) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create Permission']
      });
    }
    res.statusCode = 201;
    res.send('success');
  });
}

function deleteCpPerm(req, res) {
  const perm = {
    name: 'del-cp-perm',
    text: 'DELETE FROM comp_perms WHERE eid = $1 and ec_id = $2',
    values: [
      req.query.user,
      req.query.company
    ]
  };
  db.query(perm, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to delete Company Permission']
      });
    }
    res.statusCode = 201;
    res.send(data.rows[0]);
  });
}

module.exports = router;
