const express = require('express');
const router = express.Router();
const db = require('../../db/pg');


router.get('/', function(req, res){
    if(req.query['next_user'] !== undefined) {
        getNextPage(req, res);
        console.log('here in the midst of oblivion');
    }
});

function getNextPage(req, res) {
    const nextUser = {
        name: 'fetch-next',
        text: 'SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER by eid) as  rowNum, * FROM users) temp WHERE rowNum >(($1-1)*10) AND rowNum <=($2*10)',
        values: [req.query.next_user, req.query.next_user]
    };
    db.query(nextUser, (err, data) => {
        if (err) {
        res.statusCode = 500;
        return res.json({
            errors: ['Failed to get Users']
        });
        }
        res.statuscode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.send(data.rows);
    });
}

module.exports = router;