const express = require('express');
const router = express.Router();
const db = require('../../db/pg');
const rdb = require('../../db/hrdw');

router.get('/', function(req, res){
  if (req.query['user'] !== undefined) {
    getByUser(req, res);
  } else if (req.query['name'] !== undefined) {
    getByName(req, res);
  } else {
    getAll(req, res);
  }
});

function getAll(req, res){
  const all = {
    name: 'fetch-companies',
    text: 'SELECT * FROM companies'
  };
  db.query(all, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch companies']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

function getByName(req, res){
  const query = {
    name: 'ecmember-search',
    text: 'SELECT distinct ec_id, ec_nm FROM phrdw_tb.rpts_to_dim WHERE ec_nm IS NOT NULL and ec_id IS NOT NULL and ec_nm ILIKE $1',
    values: [req.query.name]
  };
  rdb.query(query, (err, data) => {
    if (err) {
      res.statusCode = 500;
      console.log(err);
      return res.json({
        errors: ['Failed to fetch EC Members']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

function getByUser(req, res) {
  const user = {
    name: 'fetch-user-cps',
    text: 'SELECT ec_id, ec_nm FROM comp_perms WHERE eid = $1',
    values: [req.query.user]
  };
  db.query(user, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch company permissions']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

router.get('/:id', (req, res) => {
  const one = {
    name: 'fetch-company',
    text: 'SELECT * FROM companies WHERE id = $1',
    values: [req.params.id]
  };
  db.query(one, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch company']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows[0]);
  });
});

router.post('/', (req, res) => {
  const newCompany = {
    text: 'INSERT INTO companies (company_name, created_by) ' +
     'VALUES ($1, $2) RETURNING id',
    values: [
      req.body.company_name,
      req.body.created_by
    ]
  };
  db.query(newCompany, (err, result) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create company']
      });
    }
    // If success retrieve the inserted row and return it
    const one = {
      name: 'fetch-company',
      text: 'SELECT * FROM companies WHERE id = $1',
      values: [result.rows[0].id]
    };
    db.query(one, (err, data) => {
      if (err) {
        res.statusCode = 500;
        return res.json({
          errors: ['Failed to select company']
        });
      }
      res.statuscode = 201;
      res.send(data.rows[0]);
    });
  });
});

router.put('/:id', (req, res) => {
  const update = {
    name: 'update-company',
    text: 'UPDATE companies SET company_name = $1, updated_by = $2, ' +
    'updated_at=now() WHERE id = $3',
    values: [
      req.body.company_name,
      req.body.updated_by,
      req.params.id
    ]
  };

  db.query(update, (err) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to update company']
      });
    }
    res.statusCode = 201;
    res.send('Update successful');
  });
});

router.delete('/:id', (req, res) => {
  const del = {
    name: 'delete-company',
    text: 'DELETE FROM companies WHERE id = $1',
    values: [req.params.id]
  };

  db.query(del, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to delete company']
      });
    }
    res.statusCode = 201;
    res.send(data.rows[0]);
  });
});

module.exports = router;
