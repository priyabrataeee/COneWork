const express = require('express');
const router = express.Router();
const db = require('../../db/pg');

router.get('/', function(req, res){
  if (req.query['eid'] !== undefined) {
    if (req.query['admin'] !== undefined) {
      getByEid(req, res);
    } else if (req.query['page_id'] !== undefined) {
      havePageAccess(req, res);
    } else if (req.query['ds'] !== undefined) {
      haveDatasourceAccess(req, res);
    }  else {
      searchByEid(req, res);
    }
  } else {
    getAll(req, res);
  }
});

function getAll(req, res) {
  const all = {
    name: 'fetch-users',
    text: 'SELECT COUNT(*) OVER (), c.* FROM users c order by id limit 10'
  };
  db.query(all, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to get Users']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

function searchByEid(req, res) {
  const query = {
    name: 'user-search',
    text: 'SELECT * FROM users WHERE eid LIKE $1',
    values: [req.query.eid]
  };
  db.query(query, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to find users']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

function havePageAccess(req, res) {
  const page = {
    name: 'page-access',
    text: 'SELECT count(*) FROM pg_perms WHERE eid = $1 and page_id = $2',
    values: [
      req.query.eid,
      req.query.page_id
    ]
  };
  db.query(page, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create Permission']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows[0]);
  });
}

function haveDatasourceAccess(req, res) {
  const page = {
    name: 'datasource-access',
    text: 'SELECT count(*) FROM db_perms WHERE eid = $1 and database_id = $2',
    values: [
      req.query.eid,
      req.query.ds
    ]
  };
  db.query(page, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to get Database Permission']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows[0]);
  });
}


function getByEid(req, res) {
  const query = {
    name: 'user-get',
    text: 'SELECT * FROM users WHERE eid = $1 LIMIT 1',
    values: [req.query.eid]
  };
  db.query(query, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to find User']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows[0]);
  });
}

router.get('/:id', (req, res) => {
  const one = {
    name: 'fetch-user',
    text: 'SELECT * FROM users WHERE id = $1',
    values: [req.params.id]
  };
  db.query(one, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to get User']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows[0]);
  });
});

router.post('/', (req, res) => {
  const newUser = {
    text: 'INSERT INTO users (eid, first_name, last_name, email, created_by) ' +
     'VALUES ($1, $2, $3, $4, $5) RETURNING id',
    values: [
      req.body.eid.toLowerCase(),
      req.body.first_name,
      req.body.last_name,
      req.body.email,
      req.body.created_by
    ]
  };
  db.query(newUser, (err, result) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create user']
      });
    }
    // If success retrieve the inserted row and return it
    const one = {
      name: 'fetch-user',
      text: 'SELECT * FROM users WHERE id = $1',
      values: [result.rows[0].id]
    };
    db.query(one, (err, data) => {
      if (err) {
        res.statusCode = 500;
        return res.json({
          errors: ['Failed to get User']
        });
      }
      res.statuscode = 201;
      res.send(data.rows[0]);
    });
  });
});

router.put('/:id', (req, res) => {
  const update = {
    name: 'update-user',
    text: 'UPDATE users SET eid = $1, first_name = $2, ' +
          'last_name = $3, email = $4, updated_by = $5, updated_at=now(), ' +
          'admin = $6, superuser = $7 WHERE id = $8',
    values: [
      req.body.eid,
      req.body.first_name,
      req.body.last_name,
      req.body.email,
      req.body.updated_by,
      req.body.admin,
      req.body.superuser,
      req.params.id
    ]
  };

  db.query(update, (err) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: [ err.stack ]
      });
    }
    res.statusCode = 201;
    res.send('Update successful');
  });
});

router.delete('/:id', (req, res) => {
  const del = {
    name: 'delete-user',
    text: 'DELETE FROM users WHERE id = $1',
    values: [req.params.id]
  };

  db.query(del, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to delete user']
      });
    }
    res.statusCode = 201;
    res.send(data.rows[0]);
  });
});

module.exports = router;
