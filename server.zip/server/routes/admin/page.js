const express = require('express');
const router = express.Router();
const db = require('../../db/pg');

router.get('/', function (req, res) {
  if (req.query['user'] !== undefined) {
    getByUser(req, res);
  } else if (req.query['name'] !== undefined) {
    getByName(req, res);
  } else {
    getAll(req, res);
  }
});

function getAll(req, res) {
  const all = {
    name: 'fetch-pages',
    text: 'SELECT * FROM pages'
  };
  db.query(all, (err, data) => {
    if (err) {
      return res.json({
        errors: ['Failed to get pages']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

function getByName(req, res) {
  const query = {
    name: 'page-search',
    text: 'SELECT * FROM pages WHERE page_name ILIKE $1',
    values: [req.query.name]
  };
  db.query(query, (err, data) => {
    if (err) {
      return res.json({
        errors: ['Failed to find pages']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

function getByUser(req, res) {
  const user = {
    name: 'by-user',
    text: 'SELECT p.* FROM pages p, pg_perms pp WHERE pp.eid = $1 AND pp.page_id = p.id',
    values: [req.query.user]
  };
  db.query(user, (err, data) => {
    if (err) {
      return res.json({
        errors: ['Failed to get Page Permission']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows);
  });
}

router.get('/:id', (req, res) => {
  const one = {
    name: 'fetch-page',
    text: 'SELECT * FROM pages WHERE id = $1',
    values: [req.params.id]
  };
  db.query(one, (err, data) => {
    if (err) {
      return res.json({
        errors: ['Failed to get page']
      });
    }
    res.statuscode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.send(data.rows[0]);
  });
});

router.post('/', (req, res) => {
  const newPage = {
    name: 'new-page',
    text: 'INSERT INTO pages (page_name, created_by) ' +
     'VALUES ($1, $2) RETURNING id',
    values: [
      req.body.page_name,
      req.body.created_by
    ]
  };
  db.query(newPage, (err, result) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to create page']
      });
    }
    // If success retrieve the inserted row and return it
    const one = {
      name: 'fetch-page',
      text: 'SELECT * FROM pages WHERE id = $1',
      values: [result.rows[0].id]
    };
    db.query(one, (err, data) => {
      if (err) {
        res.statusCode = 500;
        return res.json({
          errors: ['Failed to select page']
        });
      }
      res.statuscode = 201;
      res.send(data.rows[0]);
    });
  });
});

router.put('/:id', (req, res) => {
  const update = {
    name: 'update-page',
    text: 'UPDATE pages SET page_name = $1, updated_by = $2, ' +
    'updated_at=now() WHERE id = $3',
    values: [
      req.body.page_name,
      req.body.updated_by,
      req.params.id
    ]
  };

  db.query(update, (err) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to update page']
      });
    }
    res.statusCode = 201;
    res.send('Update successful');
  });
});

router.delete('/:id', (req, res) => {
  const del = {
    name: 'delete-page',
    text: 'DELETE FROM pages WHERE id = $1',
    values: [req.params.id]
  };

  db.query(del, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to delete page']
      });
    }
    res.statusCode = 201;
    res.send(data.rows[0]);
  });
});

module.exports = router;
