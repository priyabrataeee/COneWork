const express = require('express');
const router = express.Router();
const db = require('../../db/hrdw');

router.post('/results', (req, res) => {
  head = `SELECT DISTINCT
  t1060728.emp_id AS c21,
  t1060728.ent_user_id as c22,
  t1060728.alt_emp_id AS c19,
  t1060728.prfx_nm AS c27,
  t1060728.frst_nm AS c23,
  t1060728.mid_nm AS c26,
  t1060728.last_nm AS c25,
  t1060728.full_nm AS c24,
  t1060728.work_email_adr_txt AS c28,
  t1060740.assoc_type_desc AS c32,
  t1060723.flsa_stat_desc AS c92,
  t1060740.emp_type_desc AS c40,
  t1060740.emp_class_desc AS c37,
  t1060740.emp_status_cd AS c38,
  t1060740.emp_status_desc AS c39,
  CASE
      WHEN t1060740.last_day_of_work IS NULL THEN NULL
      ELSE to_char(t1060740.last_day_of_work, 'MM-DD-YYYY')
  END
  AS c120,
  to_char(t1060769.full_dt, 'MM-DD-YYYY') AS c90,
  CASE
      WHEN t1060740.actual_last_day_of_leave IS NULL THEN NULL
      ELSE to_char(t1060740.actual_last_day_of_leave, 'MM-DD-YYYY')
  END
  AS c119,
  to_char(t1060745.full_dt, 'MM-DD-YYYY') AS c117,
  to_char(t1060744.full_dt, 'MM-DD-YYYY') AS c106,
  to_char(t1060727.full_dt, 'MM-DD-YYYY') AS c98,
  to_char(t1060738.full_dt, 'MM-DD-YYYY') AS c118,
  t1060740.full_part_tm_cd AS c43,
  t1060740.fte_num AS c42,
  t1060740.cmpy_cd AS c35,
  t1060740.cmpy_nm AS c36,
  t1060740.bus_unit_cd AS c33,
  t1060740.bus_unit_nm AS c34,
  t1060740.acqn_ind AS c30,
  t1060740.acqn_cmpy_nm AS c29,
  t1060740.acqn_legal_day_1_dt AS c31,
  t1060723.job_lvl_cd AS c95,
  t1060723.job_lvl_desc AS c96,
  t1060723.job_cd AS c93,
  t1060723.job_desc AS c97,
  t1060723.job_fmly_desc AS c94,
  to_char(t1060732.full_dt, 'MM-DD-YYYY') AS c91,
  CASE
    WHEN NOT t1060742.ec10_nm IS NULL
    THEN t1060742.ec10_id
  ELSE
    CASE
      WHEN NOT t1060742.ec9_nm IS NULL
      THEN t1060742.ec9_id
    ELSE
      CASE
        WHEN NOT t1060742.ec8_nm IS NULL
        THEN t1060742.ec8_id
      ELSE
        CASE
          WHEN NOT t1060742.ec7_nm IS NULL
          THEN t1060742.ec7_id
        ELSE
          CASE
            WHEN NOT t1060742.ec6_nm IS NULL
            THEN t1060742.ec6_id
          ELSE
            CASE
              WHEN NOT t1060742.ec5_nm IS NULL
              THEN t1060742.ec5_id
            ELSE
              CASE
                WHEN NOT t1060742.ec4_nm IS NULL
                THEN t1060742.ec4_id
              ELSE
                CASE
                  WHEN NOT t1060742.ec3_nm IS NULL
                  THEN t1060742.ec3_id
                ELSE
                  CASE
                    WHEN NOT t1060742.ec2_nm IS NULL
                    THEN t1060742.ec2_id
                  ELSE
                    CASE
                      WHEN NOT t1060742.ec1_nm IS NULL
                      THEN t1060742.ec1_id
                    ELSE
                      CASE
                        WHEN NOT t1060742.ec_nm IS NULL
                        THEN t1060742.ec_id
                      ELSE
                        CASE
                          WHEN NOT t1060742.ceo_nm IS NULL
                          THEN t1060742.ceo_id
                        ELSE NULL
                        END
                      END
                    END
                  END
                END
              END
            END
          END
        END
      END
    END
  END
  AS c121,
  CASE
    WHEN NOT t1060742.ec10_nm IS NULL
    THEN t1060742.ec10_nm
  ELSE
    CASE
      WHEN NOT t1060742.ec9_nm IS NULL
      THEN t1060742.ec9_nm
    ELSE
      CASE
        WHEN NOT t1060742.ec8_nm IS NULL
        THEN t1060742.ec8_nm
      ELSE
        CASE
          WHEN NOT t1060742.ec7_nm IS NULL
          THEN t1060742.ec7_nm
        ELSE
          CASE
            WHEN NOT t1060742.ec6_nm IS NULL
            THEN t1060742.ec6_nm
          ELSE
            CASE
              WHEN NOT t1060742.ec5_nm IS NULL
              THEN t1060742.ec5_nm
            ELSE
              CASE
                WHEN NOT t1060742.ec4_nm IS NULL
                THEN t1060742.ec4_nm
              ELSE
                CASE
                  WHEN NOT t1060742.ec3_nm IS NULL
                  THEN t1060742.ec3_nm
                ELSE
                  CASE
                    WHEN NOT t1060742.ec2_nm IS NULL
                    THEN t1060742.ec2_nm
                  ELSE
                    CASE
                      WHEN NOT t1060742.ec1_nm IS NULL
                      THEN t1060742.ec1_nm
                    ELSE
                      CASE
                        WHEN NOT t1060742.ec_nm IS NULL
                        THEN t1060742.ec_nm
                      ELSE
                        CASE
                          WHEN NOT t1060742.ceo_nm IS NULL
                          THEN t1060742.ceo_nm
                        ELSE NULL
                        END
                      END
                    END
                  END
                END
              END
            END
          END
        END
      END
    END
  END
  AS c122,
  CASE
    WHEN NOT
        t1060742.ec10_nm IS NULL
    THEN t1060742.ec10_work_email_adr_txt
  ELSE
    CASE
      WHEN NOT
          t1060742.ec9_nm IS NULL
      THEN t1060742.ec9_work_email_adr_txt
    ELSE
      CASE
        WHEN NOT
            t1060742.ec8_nm IS NULL
        THEN t1060742.ec8_work_email_adr_txt
      ELSE
        CASE
          WHEN NOT
              t1060742.ec7_nm IS NULL
          THEN t1060742.ec7_work_email_adr_txt
        ELSE
          CASE
            WHEN NOT
                t1060742.ec6_nm IS NULL
            THEN t1060742.ec6_work_email_adr_txt
          ELSE
            CASE
              WHEN NOT
                  t1060742.ec5_nm IS NULL
              THEN t1060742.ec5_work_email_adr_txt
            ELSE
              CASE
                WHEN NOT
                    t1060742.ec4_nm IS NULL
                THEN t1060742.ec4_work_email_adr_txt
              ELSE
                CASE
                  WHEN NOT
                      t1060742.ec3_nm IS NULL
                  THEN t1060742.ec3_work_email_adr_txt
                ELSE
                  CASE
                    WHEN NOT
                      t1060742.ec2_nm IS NULL
                    THEN t1060742.ec2_work_email_adr_txt
                  ELSE
                    CASE
                      WHEN NOT
                          t1060742.ec1_nm IS NULL
                      THEN t1060742.ec1_work_email_adr_txt
                    ELSE
                      CASE
                        WHEN NOT
                            t1060742.ec_nm IS NULL
                        THEN t1060742.ec_work_email_adr_txt
                      ELSE
                        CASE
                          WHEN NOT
                              t1060742.ceo_nm IS NULL
                          THEN t1060742.ceo_work_email_adr_txt
                        ELSE NULL
                        END
                      END
                    END
                  END
                END
              END
            END
          END
        END
      END
    END
  END
  AS c123,
  t1060742.ec_nm AS c107,
  t1060742.ec1_nm AS c108,
  t1060742.ec2_nm AS c109,
  t1060742.ec3_nm AS c110,
  t1060742.ec4_nm AS c111,
  t1060742.ec5_nm AS c112,
  t1060742.ec6_nm AS c113,
  t1060742.ec7_nm AS c114,
  t1060742.ec8_nm AS c115,
  t1060742.ec9_nm AS c116,
  t1060752.finc_lvl_1_desc AS c4,
  t1060752.finc_lvl_2_desc AS c11,
  t1060752.finc_lvl_3_desc AS c12,
  t1060752.finc_lvl_4_desc AS c13,
  t1060752.finc_lvl_5_desc AS c14,
  t1060752.finc_lvl_6_desc AS c15,
  t1060752.finc_lvl_7_desc AS c16,
  t1060752.finc_lvl_8_desc AS c17,
  t1060752.finc_lvl_9_desc AS c18,
  t1060752.finc_lvl_10_desc AS c5,
  t1060752.finc_lvl_11_desc AS c6,
  t1060752.finc_lvl_12_desc AS c7,
  t1060752.finc_lvl_13_desc AS c8,
  t1060752.finc_lvl_14_desc AS c9,
  t1060752.finc_lvl_15_desc AS c10,
  t1060752.dept_id AS c2,
  t1060752.dept_nm AS c3,
  t1060758.full_dt AS c1,
  t1060763.loc_cd AS c99,
  t1060724.loc_nm AS c68,
  t1060740.internal_zip_id AS c45,
  t1060763.WORK_CITY_NM as c101,
  t1060763.WORK_ST_CD as c103,
  t1060763.WORK_ZIP_CD as c104,
  t1060763.WORK_CNTRY_NM as c102,
  t1060740.ppl_mgr_ind AS c48,
  t1060740.head_cnt_ind AS c44,
  t1060740.extrnl_hire_ind AS c41,
  t1060740.trfr_ind AS c88,
  t1060740.vol_atrtn_ind AS c89,
  t1060740.invol_nonrif_atrtn_ind AS c46,
  t1060740.invol_rif_atrtn_ind AS c47,
  t1060740.promo_ind AS c105,
  t1060728.brth_mmdd_dt AS c20,
  t1060746.flsa_stat_desc AS c61,
  t1060746.job_lvl_cd AS c64,
  t1060746.job_lvl_desc AS c65,
  t1060746.job_cd AS c62,
  t1060746.job_desc AS c66,
  t1060746.job_fmly_desc AS c63,
  t1060722.ec_nm AS c51,
  t1060722.ec1_nm AS c52,
  t1060722.ec2_nm AS c53,
  t1060722.ec3_nm AS c54,
  t1060722.ec4_nm AS c55,
  t1060722.ec5_nm AS c56,
  t1060722.ec6_nm AS c57,
  t1060722.ec7_nm AS c58,
  t1060722.ec8_nm AS c59,
  t1060722.ec9_nm AS c60,
  t1060719.finc_lvl_1_desc AS c69,
  t1060719.finc_lvl_2_desc AS c76,
  t1060719.finc_lvl_3_desc AS c77,
  t1060719.finc_lvl_4_desc AS c78,
  t1060719.finc_lvl_5_desc AS c79,
  t1060719.finc_lvl_6_desc AS c80,
  t1060719.finc_lvl_7_desc AS c81,
  t1060719.finc_lvl_8_desc AS c82,
  t1060719.finc_lvl_9_desc AS c83,
  t1060719.finc_lvl_10_desc AS c70,
  t1060719.finc_lvl_11_desc AS c71,
  t1060719.finc_lvl_12_desc AS c72,
  t1060719.finc_lvl_13_desc AS c73,
  t1060719.finc_lvl_14_desc AS c74,
  t1060719.finc_lvl_15_desc AS c75,
  t1060719.dept_id AS c49,
  t1060719.dept_nm AS c50,
  t1060724.loc_cd AS c67,
  t1060763.LOC_NM as c100,
  t1060724.work_city_nm AS c84,
  t1060724.work_st_cd AS c86,
  t1060724.work_zip_cd AS c87,
  t1060724.work_cntry_nm AS c85
FROM
  phrdw_tb.dept_dim t1060719 /* Dim_DEPT_DIM_Previous */,
  phrdw_tb.job_dim t1060723 /* Dim_JOB_DIM */,
  phrdw_tb.dt_dim t1060745 /* Dim_DT_DIM_Service */,
  phrdw_tb.dt_dim t1060758 /* Dim_DT_DIM_Department_Entry */,
  phrdw_tb.rpts_to_dim t1060742 /* Dim_RPTS_TO_DIM */,
  phrdw_tb.dt_dim t1060732 /* Dim_DT_DIM_Job_Entry */,
  phrdw_tb.rpts_to_dim t1060722 /* Dim_RPTS_TO_DIM_Previous */,
  phrdw_tb.dt_dim t1060729 /* Dim_DT_DIM_Filter */,
  phrdw_tb.loc_dim t1060724 /* Dim_LOC_DIM_Previous */,
  phrdw_tb.job_dim t1060746 /* Dim_JOB_DIM_Previous */,
  phrdw_tb.loc_dim t1060763 /* Dim_LOC_DIM */,
  phrdw_tb.dt_dim t1060738 /* Dim_DT_DIM_Termination */,
  phrdw_tb.dt_dim t1060744 /* Dim_DT_DIM_Original_Hire */,
  phrdw_tb.dept_dim t1060752 /* Dim_DEPT_DIM */,
  phrdw_tb.dt_dim t1060727 /* Dim_DT_DIM_Last_Hire */,
  phrdw_tb.dt_dim t1060769 /* Dim_DT_DIM_Expected_Return */,
  phrdw_tb.emp_dim t1060728 /* Dim_EMP_DIM */,
  phrdw_tb.emp_eom_fact t1060740 /* Fact_EMP_EOM_FACT */
WHERE
  t1060719.dept_dim_id = t1060740.prev_dept_dim_id AND
  t1060723.job_dim_id = t1060740.job_dim_id AND
  t1060740.rpts_to_dim_id = t1060742.rpts_to_dim_id AND
  t1060732.dt_dim_id = nvl(t1060740.job_entry_dt_dim_id, 0) AND
  t1060722.rpts_to_dim_id = t1060740.prev_rpts_to_dim_id AND
  t1060729.dt_dim_id = t1060740.dt_dim_id AND
  t1060724.loc_dim_id = t1060740.prev_loc_dim_id AND
  t1060740.prev_job_dim_id = t1060746.job_dim_id AND
  t1060740.loc_dim_id = t1060763.loc_dim_id AND
  t1060738.dt_dim_id = t1060740.term_dt_dim_id AND
  t1060740.orig_hire_dt_dim_id = t1060744.dt_dim_id AND
  t1060740.dept_dim_id = t1060752.dept_dim_id AND
  t1060727.dt_dim_id = t1060740.last_hire_dt_dim_id AND
  t1060740.expectd_return_dt_dim_id = t1060769.dt_dim_id AND
  t1060728.emp_dim_id = t1060740.emp_dim_id AND
  t1060740.service_dt_dim_id = t1060745.dt_dim_id AND
  t1060758.dt_dim_id = nvl(t1060740.dept_entry_dt_dim_id, 0) AND
  t1060729.yymm_num = $1`;

  diversity = "select distinct T1060758.FULL_DT as c1, T1060752.DEPT_ID as c2, T1060752.DEPT_NM as c3, T1060752.FINC_LVL_1_DESC as c4, T1060752.FINC_LVL_10_DESC as c5, T1060752.FINC_LVL_11_DESC as c6, T1060752.FINC_LVL_12_DESC as c7, T1060752.FINC_LVL_13_DESC as c8, T1060752.FINC_LVL_14_DESC as c9, T1060752.FINC_LVL_15_DESC as c10, T1060752.FINC_LVL_2_DESC as c11, T1060752.FINC_LVL_3_DESC as c12, T1060752.FINC_LVL_4_DESC as c13, T1060752.FINC_LVL_5_DESC as c14, T1060752.FINC_LVL_6_DESC as c15, T1060752.FINC_LVL_7_DESC as c16, T1060752.FINC_LVL_8_DESC as c17, T1060752.FINC_LVL_9_DESC as c18, T1060728.ALT_EMP_ID as c19, T1060728.BRTH_MMDD_DT as c20, T1060728.EMP_ID as c21, T1060728.ENT_USER_ID as c22, T1060728.FRST_NM as c23, T1060728.FULL_NM as c24, T1060728.LAST_NM as c25, T1060728.MID_NM as c26, T1060728.PRFX_NM as c27, T1060728.WORK_EMAIL_ADR_TXT as c28, T1060740.ACQN_CMPY_NM as c29, T1060740.ACQN_IND as c30, T1060740.ACQN_LEGAL_DAY_1_DT as c31, --case when(instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'NON_HR') > 1 or instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'CANADIAN_HRC') >= 1) and T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources') then NULL else T1060740.ANUL_SAL_AMT end as c32, T1060740.ASSOC_TYPE_DESC as c33, T1060740.BUS_UNIT_CD as c34, T1060740.BUS_UNIT_NM as c35, T1060740.CMPY_CD as c36, T1060740.CMPY_NM as c37, T1060740.EMP_CLASS_DESC as c38, T1060740.EMP_STATUS_CD as c39, T1060740.EMP_STATUS_DESC as c40, T1060740.EMP_TYPE_DESC as c41, T1060740.EXTRNL_HIRE_IND as c42, T1060740.FTE_NUM as c43, T1060740.FULL_PART_TM_CD as c44, T1060740.HEAD_CNT_IND as c45, T1060740.INTERNAL_ZIP_ID as c46, T1060740.INVOL_NONRIF_ATRTN_IND as c47, T1060740.INVOL_RIF_ATRTN_IND as c48, T1060740.PPL_MGR_IND as c49, T1060719.DEPT_ID as c50, T1060719.DEPT_NM as c51, T1060722.EC_NM as c52, T1060722.EC1_NM as c53, T1060722.EC2_NM as c54, T1060722.EC3_NM as c55, T1060722.EC4_NM as c56, T1060722.EC5_NM as c57, T1060722.EC6_NM as c58, T1060722.EC7_NM as c59, T1060722.EC8_NM as c60, T1060722.EC9_NM as c61, T1060746.FLSA_STAT_DESC as c62, T1060746.JOB_CD as c63, T1060746.JOB_FMLY_DESC as c64, T1060746.JOB_LVL_CD as c65, T1060746.JOB_LVL_DESC as c66, T1060746.JOB_DESC as c67, T1060724.LOC_CD as c68, T1060724.LOC_NM as c69, T1060719.FINC_LVL_1_DESC as c70, T1060719.FINC_LVL_10_DESC as c71, T1060719.FINC_LVL_11_DESC as c72, T1060719.FINC_LVL_12_DESC as c73, T1060719.FINC_LVL_13_DESC as c74, T1060719.FINC_LVL_14_DESC as c75, T1060719.FINC_LVL_15_DESC as c76, T1060719.FINC_LVL_2_DESC as c77, T1060719.FINC_LVL_3_DESC as c78, T1060719.FINC_LVL_4_DESC as c79, T1060719.FINC_LVL_5_DESC as c80, T1060719.FINC_LVL_6_DESC as c81, T1060719.FINC_LVL_7_DESC as c82, T1060719.FINC_LVL_8_DESC as c83, T1060719.FINC_LVL_9_DESC as c84, T1060724.WORK_CITY_NM as c85, T1060724.WORK_CNTRY_NM as c86, T1060724.WORK_ST_CD as c87, T1060724.WORK_ZIP_CD as c88, T1060740.SAL_GRADE_ID as c89, T1060740.TRFR_IND as c90, T1060740.VOL_ATRTN_IND as c91, T1060769.FULL_DT as c92, T1060732.FULL_DT as c93, T1060723.FLSA_STAT_DESC as c94, T1060723.JOB_CD as c95, T1060723.JOB_FMLY_DESC as c96, T1060723.JOB_LVL_CD as c97, T1060723.JOB_LVL_DESC as c98, T1060723.JOB_DESC as c99, T1060727.FULL_DT as c100, T1060763.LOC_CD as c101, T1060763.LOC_NM as c102, T1060763.WORK_CITY_NM as c103, T1060763.WORK_CNTRY_NM as c104, T1060763.WORK_ST_CD as c105, T1060763.WORK_ZIP_CD as c106, T1060740.PROMO_IND as c107, T1060744.FULL_DT as c108, T1060742.EC_NM as c109, T1060742.EC1_NM as c110, T1060742.EC2_NM as c111, T1060742.EC3_NM as c112, T1060742.EC4_NM as c113, T1060742.EC5_NM as c114, T1060742.EC6_NM as c115, T1060742.EC7_NM as c116, T1060742.EC8_NM as c117, T1060742.EC9_NM as c118, T1060745.FULL_DT as c119, T1060738.FULL_DT as c120, case when T1060740.ACTUAL_LAST_DAY_OF_LEAVE is null then NULL else T1060740.ACTUAL_LAST_DAY_OF_LEAVE end as c121, case when T1060740.LAST_DAY_OF_WORK is null then NULL else T1060740.LAST_DAY_OF_WORK end as c122, case when not T1060742.EC10_NM is null then T1060742.EC10_ID else case when not T1060742.EC9_NM is null then T1060742.EC9_ID else case when not T1060742.EC8_NM is null then T1060742.EC8_ID else case when not T1060742.EC7_NM is null then T1060742.EC7_ID else case when not T1060742.EC6_NM is null then T1060742.EC6_ID else case when not T1060742.EC5_NM is null then T1060742.EC5_ID else case when not T1060742.EC4_NM is null then T1060742.EC4_ID else case when not T1060742.EC3_NM is null then T1060742.EC3_ID else case when not T1060742.EC2_NM is null then T1060742.EC2_ID else case when not T1060742.EC1_NM is null then T1060742.EC1_ID else case when not T1060742.EC_NM is null then T1060742.EC_ID else case when not T1060742.CEO_NM is null then T1060742.CEO_ID else NULL end end end end end end end end end end end end as c123, case when not T1060742.EC10_NM is null then T1060742.EC10_NM else case when not T1060742.EC9_NM is null then T1060742.EC9_NM else case when not T1060742.EC8_NM is null then T1060742.EC8_NM else case when not T1060742.EC7_NM is null then T1060742.EC7_NM else case when not T1060742.EC6_NM is null then T1060742.EC6_NM else case when not T1060742.EC5_NM is null then T1060742.EC5_NM else case when not T1060742.EC4_NM is null then T1060742.EC4_NM else case when not T1060742.EC3_NM is null then T1060742.EC3_NM else case when not T1060742.EC2_NM is null then T1060742.EC2_NM else case when not T1060742.EC1_NM is null then T1060742.EC1_NM else case when not T1060742.EC_NM is null then T1060742.EC_NM else case when not T1060742.CEO_NM is null then T1060742.CEO_NM else NULL end end end end end end end end end end end end as c124, case when not T1060742.EC10_NM is null then T1060742.EC10_WORK_EMAIL_ADR_TXT else case when not T1060742.EC9_NM is null then T1060742.EC9_WORK_EMAIL_ADR_TXT else case when not T1060742.EC8_NM is null then T1060742.EC8_WORK_EMAIL_ADR_TXT else case when not T1060742.EC7_NM is null then T1060742.EC7_WORK_EMAIL_ADR_TXT else case when not T1060742.EC6_NM is null then T1060742.EC6_WORK_EMAIL_ADR_TXT else case when not T1060742.EC5_NM is null then T1060742.EC5_WORK_EMAIL_ADR_TXT else case when not T1060742.EC4_NM is null then T1060742.EC4_WORK_EMAIL_ADR_TXT else case when not T1060742.EC3_NM is null then T1060742.EC3_WORK_EMAIL_ADR_TXT else case when not T1060742.EC2_NM is null then T1060742.EC2_WORK_EMAIL_ADR_TXT else case when not T1060742.EC1_NM is null then T1060742.EC1_WORK_EMAIL_ADR_TXT else case when not T1060742.EC_NM is null then T1060742.EC_WORK_EMAIL_ADR_TXT else case when not T1060742.CEO_NM is null then T1060742.CEO_WORK_EMAIL_ADR_TXT else NULL end end end end end end end end end end end end as c125 from phrdw.DEPT_DIM T1060719 /* Dim_DEPT_DIM_Previous */ , phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ , phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ , phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ , phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ , phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ , phrdw.RPTS_TO_DIM T1060722 /* Dim_RPTS_TO_DIM_Previous */ , phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ , phrdw.LOC_DIM T1060724 /* Dim_LOC_DIM_Previous */ , phrdw.JOB_DIM T1060746 /* Dim_JOB_DIM_Previous */ , phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ , phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ , phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ , phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ , phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ , phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ , phrdw.EMP_DIM T1060728 /* Dim_EMP_DIM */ , phrdw.EMP_EOM_FACT T1060740 /* Fact_EMP_EOM_FACT */ where ( T1060719.DEPT_DIM_ID = T1060740.PREV_DEPT_DIM_ID and T1060723.JOB_DIM_ID = T1060740.JOB_DIM_ID and T1060740.RPTS_TO_DIM_ID = T1060742.RPTS_TO_DIM_ID and T1060732.DT_DIM_ID = nvl(T1060740.JOB_ENTRY_DT_DIM_ID , 0) and T1060722.RPTS_TO_DIM_ID = T1060740.PREV_RPTS_TO_DIM_ID and T1060729.DT_DIM_ID = T1060740.DT_DIM_ID and T1060724.LOC_DIM_ID = T1060740.PREV_LOC_DIM_ID and T1060740.PREV_JOB_DIM_ID = T1060746.JOB_DIM_ID and T1060740.LOC_DIM_ID = T1060763.LOC_DIM_ID and T1060738.DT_DIM_ID = T1060740.TERM_DT_DIM_ID and T1060740.ORIG_HIRE_DT_DIM_ID = T1060744.DT_DIM_ID and T1060740.DEPT_DIM_ID = T1060752.DEPT_DIM_ID and T1060727.DT_DIM_ID = T1060740.LAST_HIRE_DT_DIM_ID and T1060740.EXPECTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and T1060728.EMP_DIM_ID = T1060740.EMP_DIM_ID and T1060740.SERVICE_DT_DIM_ID = T1060745.DT_DIM_ID and T1060729.YYMM_NUM = $1";

  compensation = "select distinct T1060758.FULL_DT as c1, T1060752.DEPT_ID as c2, T1060752.DEPT_NM as c3, T1060752.FINC_LVL_1_DESC as c4, T1060752.FINC_LVL_10_DESC as c5, T1060752.FINC_LVL_11_DESC as c6, T1060752.FINC_LVL_12_DESC as c7, T1060752.FINC_LVL_13_DESC as c8, T1060752.FINC_LVL_14_DESC as c9, T1060752.FINC_LVL_15_DESC as c10, T1060752.FINC_LVL_2_DESC as c11, T1060752.FINC_LVL_3_DESC as c12, T1060752.FINC_LVL_4_DESC as c13, T1060752.FINC_LVL_5_DESC as c14, T1060752.FINC_LVL_6_DESC as c15, T1060752.FINC_LVL_7_DESC as c16, T1060752.FINC_LVL_8_DESC as c17, T1060752.FINC_LVL_9_DESC as c18, case when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end < 25 then 'Under 25' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 25 and 34 then '25 to 34' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 35 and 44 then '35 to 44' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 45 and 54 then '45 to 54' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end > 55 then '55 and over' else 'Unspecified' end as c19, T1060728.ALT_EMP_ID as c20, T1060728.BRTH_DT as c21, T1060728.BRTH_MMDD_DT as c22, T1060728.EMP_ID as c23, T1060728.ENT_USER_ID as c24, T1060728.FRST_NM as c25, T1060728.FULL_NM as c26, T1060728.HOME_ADR_LINE_1_TXT as c27, T1060728.HOME_ADR_LINE_2_TXT as c28, T1060728.HOME_ADR_LINE_3_TXT as c29, T1060728.HOME_ADR_LINE_4_TXT as c30, T1060728.HOME_CITY_NM as c31, T1060728.HOME_CNTRY_NM as c32, T1060728.HOME_ST_CD as c33, T1060728.HOME_ZIP_CD as c34, T1060728.LAST_NM as c35, T1060728.MID_NM as c36, T1060728.PRFX_NM as c37, T1060728.WORK_EMAIL_ADR_TXT as c38, T1060740.ACQN_CMPY_NM as c39, T1060740.ACQN_IND as c40, T1060740.ACQN_LEGAL_DAY_1_DT as c41, T1060740.ASSOC_TYPE_DESC as c42, T1060740.BUS_UNIT_CD as c43, T1060740.BUS_UNIT_NM as c44, T1060740.CMPY_CD as c45, T1060740.CMPY_NM as c46, T1060740.EMP_CLASS_DESC as c47, T1060740.EMP_STATUS_CD as c48, T1060740.EMP_STATUS_DESC as c49, T1060740.EMP_TYPE_DESC as c50, T1060740.EXTRNL_HIRE_IND as c51, T1060740.FTE_NUM as c52, T1060740.FULL_PART_TM_CD as c53, T1060740.HEAD_CNT_IND as c54, T1060740.INTERNAL_ZIP_ID as c55, T1060740.INVOL_NONRIF_ATRTN_IND as c56, T1060740.INVOL_RIF_ATRTN_IND as c57, T1060740.PPL_MGR_IND as c58, T1060719.DEPT_ID as c59, T1060719.DEPT_NM as c60, T1060722.EC_NM as c61, T1060722.EC1_NM as c62, T1060722.EC2_NM as c63, T1060722.EC3_NM as c64, T1060722.EC4_NM as c65, T1060722.EC5_NM as c66, T1060722.EC6_NM as c67, T1060722.EC7_NM as c68, T1060722.EC8_NM as c69, T1060722.EC9_NM as c70, T1060746.FLSA_STAT_DESC as c71, T1060746.JOB_CD as c72, T1060746.JOB_FMLY_DESC as c73, T1060746.JOB_LVL_CD as c74, T1060746.JOB_LVL_DESC as c75, T1060746.JOB_DESC as c76, T1060724.LOC_CD as c77, T1060724.LOC_NM as c78, T1060719.FINC_LVL_1_DESC as c79, T1060719.FINC_LVL_10_DESC as c80, T1060719.FINC_LVL_11_DESC as c81, T1060719.FINC_LVL_12_DESC as c82, T1060719.FINC_LVL_13_DESC as c83, T1060719.FINC_LVL_14_DESC as c84, T1060719.FINC_LVL_15_DESC as c85, T1060719.FINC_LVL_2_DESC as c86, T1060719.FINC_LVL_3_DESC as c87, T1060719.FINC_LVL_4_DESC as c88, T1060719.FINC_LVL_5_DESC as c89, T1060719.FINC_LVL_6_DESC as c90, T1060719.FINC_LVL_7_DESC as c91, T1060719.FINC_LVL_8_DESC as c92, T1060719.FINC_LVL_9_DESC as c93, T1060724.WORK_CITY_NM as c94, T1060724.WORK_CNTRY_NM as c95, T1060724.WORK_ST_CD as c96, T1060724.WORK_ZIP_CD as c97, T1060740.TRFR_IND as c98, T1060740.VOL_ATRTN_IND as c99, T1060769.FULL_DT as c100, T1060732.FULL_DT as c101, T1060723.FLSA_STAT_DESC as c102, T1060723.JOB_CD as c103, T1060723.JOB_FMLY_DESC as c104, T1060723.JOB_LVL_CD as c105, T1060723.JOB_LVL_DESC as c106, T1060723.JOB_DESC as c107, T1060727.FULL_DT as c108, T1060763.LOC_CD as c109, T1060763.LOC_NM as c110, T1060763.WORK_CITY_NM as c111, T1060763.WORK_CNTRY_NM as c112, T1060763.WORK_ST_CD as c113, T1060763.WORK_ZIP_CD as c114, T1060740.PROMO_IND as c115, T1060744.FULL_DT as c116, T1060742.EC_NM as c117, T1060742.EC1_NM as c118, T1060742.EC2_NM as c119, T1060742.EC3_NM as c120, T1060742.EC4_NM as c121, T1060742.EC5_NM as c122, T1060742.EC6_NM as c123, T1060742.EC7_NM as c124, T1060742.EC8_NM as c125, T1060742.EC9_NM as c126, T1060745.FULL_DT as c127, T1060738.FULL_DT as c128, case when T1060740.ACTUAL_LAST_DAY_OF_LEAVE is null then NULL else T1060740.ACTUAL_LAST_DAY_OF_LEAVE end as c129, case when T1060740.LAST_DAY_OF_WORK is null then NULL else T1060740.LAST_DAY_OF_WORK end as c130, case when not T1060742.EC10_NM is null then T1060742.EC10_ID else case when not T1060742.EC9_NM is null then T1060742.EC9_ID else case when not T1060742.EC8_NM is null then T1060742.EC8_ID else case when not T1060742.EC7_NM is null then T1060742.EC7_ID else case when not T1060742.EC6_NM is null then T1060742.EC6_ID else case when not T1060742.EC5_NM is null then T1060742.EC5_ID else case when not T1060742.EC4_NM is null then T1060742.EC4_ID else case when not T1060742.EC3_NM is null then T1060742.EC3_ID else case when not T1060742.EC2_NM is null then T1060742.EC2_ID else case when not T1060742.EC1_NM is null then T1060742.EC1_ID else case when not T1060742.EC_NM is null then T1060742.EC_ID else case when not T1060742.CEO_NM is null then T1060742.CEO_ID else NULL end end end end end end end end end end end end as c131, case when not T1060742.EC10_NM is null then T1060742.EC10_NM else case when not T1060742.EC9_NM is null then T1060742.EC9_NM else case when not T1060742.EC8_NM is null then T1060742.EC8_NM else case when not T1060742.EC7_NM is null then T1060742.EC7_NM else case when not T1060742.EC6_NM is null then T1060742.EC6_NM else case when not T1060742.EC5_NM is null then T1060742.EC5_NM else case when not T1060742.EC4_NM is null then T1060742.EC4_NM else case when not T1060742.EC3_NM is null then T1060742.EC3_NM else case when not T1060742.EC2_NM is null then T1060742.EC2_NM else case when not T1060742.EC1_NM is null then T1060742.EC1_NM else case when not T1060742.EC_NM is null then T1060742.EC_NM else case when not T1060742.CEO_NM is null then T1060742.CEO_NM else NULL end end end end end end end end end end end end as c132, case when not T1060742.EC10_NM is null then T1060742.EC10_WORK_EMAIL_ADR_TXT else case when not T1060742.EC9_NM is null then T1060742.EC9_WORK_EMAIL_ADR_TXT else case when not T1060742.EC8_NM is null then T1060742.EC8_WORK_EMAIL_ADR_TXT else case when not T1060742.EC7_NM is null then T1060742.EC7_WORK_EMAIL_ADR_TXT else case when not T1060742.EC6_NM is null then T1060742.EC6_WORK_EMAIL_ADR_TXT else case when not T1060742.EC5_NM is null then T1060742.EC5_WORK_EMAIL_ADR_TXT else case when not T1060742.EC4_NM is null then T1060742.EC4_WORK_EMAIL_ADR_TXT else case when not T1060742.EC3_NM is null then T1060742.EC3_WORK_EMAIL_ADR_TXT else case when not T1060742.EC2_NM is null then T1060742.EC2_WORK_EMAIL_ADR_TXT else case when not T1060742.EC1_NM is null then T1060742.EC1_WORK_EMAIL_ADR_TXT else case when not T1060742.EC_NM is null then T1060742.EC_WORK_EMAIL_ADR_TXT else case when not T1060742.CEO_NM is null then T1060742.CEO_WORK_EMAIL_ADR_TXT else NULL end end end end end end end end end end end end as c133 from phrdw.DEPT_DIM T1060719 /* Dim_DEPT_DIM_Previous */ , phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ , phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ , phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ , phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ , phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ , phrdw.RPTS_TO_DIM T1060722 /* Dim_RPTS_TO_DIM_Previous */ , phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ , phrdw.LOC_DIM T1060724 /* Dim_LOC_DIM_Previous */ , phrdw.JOB_DIM T1060746 /* Dim_JOB_DIM_Previous */ , phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ , phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ , phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ , phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ , phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ , phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ , phrdw.EMP_DIM T1060728 /* Dim_EMP_DIM */ , phrdw.EMP_EOM_FACT T1060740 /* Fact_EMP_EOM_FACT */ where( T1060719.DEPT_DIM_ID = T1060740.PREV_DEPT_DIM_ID and T1060723.JOB_DIM_ID = T1060740.JOB_DIM_ID and T1060740.RPTS_TO_DIM_ID = T1060742.RPTS_TO_DIM_ID and T1060732.DT_DIM_ID = nvl(T1060740.JOB_ENTRY_DT_DIM_ID , 0) and T1060722.RPTS_TO_DIM_ID = T1060740.PREV_RPTS_TO_DIM_ID and T1060729.DT_DIM_ID = T1060740.DT_DIM_ID and T1060724.LOC_DIM_ID = T1060740.PREV_LOC_DIM_ID and T1060740.PREV_JOB_DIM_ID = T1060746.JOB_DIM_ID and T1060740.LOC_DIM_ID = T1060763.LOC_DIM_ID and T1060738.DT_DIM_ID = T1060740.TERM_DT_DIM_ID and T1060740.ORIG_HIRE_DT_DIM_ID = T1060744.DT_DIM_ID and T1060740.DEPT_DIM_ID = T1060752.DEPT_DIM_ID and T1060727.DT_DIM_ID = T1060740.LAST_HIRE_DT_DIM_ID and T1060740.EXPECTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and T1060728.EMP_DIM_ID = T1060740.EMP_DIM_ID and T1060740.SERVICE_DT_DIM_ID = T1060745.DT_DIM_ID and T1060729.YYMM_NUM = $1";

  personal = "select distinct T1060758.FULL_DT as c1, T1060752.DEPT_ID as c2, T1060752.DEPT_NM as c3, T1060752.FINC_LVL_1_DESC as c4, T1060752.FINC_LVL_10_DESC as c5, T1060752.FINC_LVL_11_DESC as c6, T1060752.FINC_LVL_12_DESC as c7, T1060752.FINC_LVL_13_DESC as c8, T1060752.FINC_LVL_14_DESC as c9, T1060752.FINC_LVL_15_DESC as c10, T1060752.FINC_LVL_2_DESC as c11, T1060752.FINC_LVL_3_DESC as c12, T1060752.FINC_LVL_4_DESC as c13, T1060752.FINC_LVL_5_DESC as c14, T1060752.FINC_LVL_6_DESC as c15, T1060752.FINC_LVL_7_DESC as c16, T1060752.FINC_LVL_8_DESC as c17, T1060752.FINC_LVL_9_DESC as c18, case when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end < 25 then 'Under 25' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 25 and 34 then '25 to 34' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 35 and 44 then '35 to 44' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 45 and 54 then '45 to 54' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:44:04' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end > 55 then '55 and over' else 'Unspecified' end as c19, T1060728.ALT_EMP_ID as c20, T1060728.BRTH_DT as c21, T1060728.BRTH_MMDD_DT as c22, T1060728.EMP_ID as c23, T1060728.ENT_USER_ID as c24, T1060728.FRST_NM as c25, T1060728.FULL_NM as c26, T1060728.HOME_ADR_LINE_1_TXT as c27, T1060728.HOME_ADR_LINE_2_TXT as c28, T1060728.HOME_ADR_LINE_3_TXT as c29, T1060728.HOME_ADR_LINE_4_TXT as c30, T1060728.HOME_CITY_NM as c31, T1060728.HOME_CNTRY_NM as c32, T1060728.HOME_ST_CD as c33, T1060728.HOME_ZIP_CD as c34, T1060728.LAST_NM as c35, T1060728.MID_NM as c36, T1060728.PRFX_NM as c37, T1060728.WORK_EMAIL_ADR_TXT as c38, T1060740.ACQN_CMPY_NM as c39, T1060740.ACQN_IND as c40, T1060740.ACQN_LEGAL_DAY_1_DT as c41, T1060740.ASSOC_TYPE_DESC as c42, T1060740.BUS_UNIT_CD as c43, T1060740.BUS_UNIT_NM as c44, T1060740.CMPY_CD as c45, T1060740.CMPY_NM as c46, T1060740.EMP_CLASS_DESC as c47, T1060740.EMP_STATUS_CD as c48, T1060740.EMP_STATUS_DESC as c49, T1060740.EMP_TYPE_DESC as c50, T1060740.EXTRNL_HIRE_IND as c51, T1060740.FTE_NUM as c52, T1060740.FULL_PART_TM_CD as c53, T1060740.HEAD_CNT_IND as c54, T1060740.INTERNAL_ZIP_ID as c55, T1060740.INVOL_NONRIF_ATRTN_IND as c56, T1060740.INVOL_RIF_ATRTN_IND as c57, T1060740.PPL_MGR_IND as c58, T1060719.DEPT_ID as c59, T1060719.DEPT_NM as c60, T1060722.EC_NM as c61, T1060722.EC1_NM as c62, T1060722.EC2_NM as c63, T1060722.EC3_NM as c64, T1060722.EC4_NM as c65, T1060722.EC5_NM as c66, T1060722.EC6_NM as c67, T1060722.EC7_NM as c68, T1060722.EC8_NM as c69, T1060722.EC9_NM as c70, T1060746.FLSA_STAT_DESC as c71, T1060746.JOB_CD as c72, T1060746.JOB_FMLY_DESC as c73, T1060746.JOB_LVL_CD as c74, T1060746.JOB_LVL_DESC as c75, T1060746.JOB_DESC as c76, T1060724.LOC_CD as c77, T1060724.LOC_NM as c78, T1060719.FINC_LVL_1_DESC as c79, T1060719.FINC_LVL_10_DESC as c80, T1060719.FINC_LVL_11_DESC as c81, T1060719.FINC_LVL_12_DESC as c82, T1060719.FINC_LVL_13_DESC as c83, T1060719.FINC_LVL_14_DESC as c84, T1060719.FINC_LVL_15_DESC as c85, T1060719.FINC_LVL_2_DESC as c86, T1060719.FINC_LVL_3_DESC as c87, T1060719.FINC_LVL_4_DESC as c88, T1060719.FINC_LVL_5_DESC as c89, T1060719.FINC_LVL_6_DESC as c90, T1060719.FINC_LVL_7_DESC as c91, T1060719.FINC_LVL_8_DESC as c92, T1060719.FINC_LVL_9_DESC as c93, T1060724.WORK_CITY_NM as c94, T1060724.WORK_CNTRY_NM as c95, T1060724.WORK_ST_CD as c96, T1060724.WORK_ZIP_CD as c97, T1060740.TRFR_IND as c98, T1060740.VOL_ATRTN_IND as c99, T1060769.FULL_DT as c100, T1060732.FULL_DT as c101, T1060723.FLSA_STAT_DESC as c102, T1060723.JOB_CD as c103, T1060723.JOB_FMLY_DESC as c104, T1060723.JOB_LVL_CD as c105, T1060723.JOB_LVL_DESC as c106, T1060723.JOB_DESC as c107, T1060727.FULL_DT as c108, T1060763.LOC_CD as c109, T1060763.LOC_NM as c110, T1060763.WORK_CITY_NM as c111, T1060763.WORK_CNTRY_NM as c112, T1060763.WORK_ST_CD as c113, T1060763.WORK_ZIP_CD as c114, T1060740.PROMO_IND as c115, T1060744.FULL_DT as c116, T1060742.EC_NM as c117, T1060742.EC1_NM as c118, T1060742.EC2_NM as c119, T1060742.EC3_NM as c120, T1060742.EC4_NM as c121, T1060742.EC5_NM as c122, T1060742.EC6_NM as c123, T1060742.EC7_NM as c124, T1060742.EC8_NM as c125, T1060742.EC9_NM as c126, T1060745.FULL_DT as c127, T1060738.FULL_DT as c128, case when T1060740.ACTUAL_LAST_DAY_OF_LEAVE is null then NULL else T1060740.ACTUAL_LAST_DAY_OF_LEAVE end as c129, case when T1060740.LAST_DAY_OF_WORK is null then NULL else T1060740.LAST_DAY_OF_WORK end as c130, case when not T1060742.EC10_NM is null then T1060742.EC10_ID else case when not T1060742.EC9_NM is null then T1060742.EC9_ID else case when not T1060742.EC8_NM is null then T1060742.EC8_ID else case when not T1060742.EC7_NM is null then T1060742.EC7_ID else case when not T1060742.EC6_NM is null then T1060742.EC6_ID else case when not T1060742.EC5_NM is null then T1060742.EC5_ID else case when not T1060742.EC4_NM is null then T1060742.EC4_ID else case when not T1060742.EC3_NM is null then T1060742.EC3_ID else case when not T1060742.EC2_NM is null then T1060742.EC2_ID else case when not T1060742.EC1_NM is null then T1060742.EC1_ID else case when not T1060742.EC_NM is null then T1060742.EC_ID else case when not T1060742.CEO_NM is null then T1060742.CEO_ID else NULL end end end end end end end end end end end end as c131, case when not T1060742.EC10_NM is null then T1060742.EC10_NM else case when not T1060742.EC9_NM is null then T1060742.EC9_NM else case when not T1060742.EC8_NM is null then T1060742.EC8_NM else case when not T1060742.EC7_NM is null then T1060742.EC7_NM else case when not T1060742.EC6_NM is null then T1060742.EC6_NM else case when not T1060742.EC5_NM is null then T1060742.EC5_NM else case when not T1060742.EC4_NM is null then T1060742.EC4_NM else case when not T1060742.EC3_NM is null then T1060742.EC3_NM else case when not T1060742.EC2_NM is null then T1060742.EC2_NM else case when not T1060742.EC1_NM is null then T1060742.EC1_NM else case when not T1060742.EC_NM is null then T1060742.EC_NM else case when not T1060742.CEO_NM is null then T1060742.CEO_NM else NULL end end end end end end end end end end end end as c132, case when not T1060742.EC10_NM is null then T1060742.EC10_WORK_EMAIL_ADR_TXT else case when not T1060742.EC9_NM is null then T1060742.EC9_WORK_EMAIL_ADR_TXT else case when not T1060742.EC8_NM is null then T1060742.EC8_WORK_EMAIL_ADR_TXT else case when not T1060742.EC7_NM is null then T1060742.EC7_WORK_EMAIL_ADR_TXT else case when not T1060742.EC6_NM is null then T1060742.EC6_WORK_EMAIL_ADR_TXT else case when not T1060742.EC5_NM is null then T1060742.EC5_WORK_EMAIL_ADR_TXT else case when not T1060742.EC4_NM is null then T1060742.EC4_WORK_EMAIL_ADR_TXT else case when not T1060742.EC3_NM is null then T1060742.EC3_WORK_EMAIL_ADR_TXT else case when not T1060742.EC2_NM is null then T1060742.EC2_WORK_EMAIL_ADR_TXT else case when not T1060742.EC1_NM is null then T1060742.EC1_WORK_EMAIL_ADR_TXT else case when not T1060742.EC_NM is null then T1060742.EC_WORK_EMAIL_ADR_TXT else case when not T1060742.CEO_NM is null then T1060742.CEO_WORK_EMAIL_ADR_TXT else NULL end end end end end end end end end end end end as c133 from phrdw.DEPT_DIM T1060719 /* Dim_DEPT_DIM_Previous */ , phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ , phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ , phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ , phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ , phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ , phrdw.RPTS_TO_DIM T1060722 /* Dim_RPTS_TO_DIM_Previous */ , phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ , phrdw.LOC_DIM T1060724 /* Dim_LOC_DIM_Previous */ , phrdw.JOB_DIM T1060746 /* Dim_JOB_DIM_Previous */ , phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ , phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ , phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ , phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ , phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ , phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ , phrdw.EMP_DIM T1060728 /* Dim_EMP_DIM */ , phrdw.EMP_EOM_FACT T1060740 /* Fact_EMP_EOM_FACT */ where( T1060719.DEPT_DIM_ID = T1060740.PREV_DEPT_DIM_ID and T1060723.JOB_DIM_ID = T1060740.JOB_DIM_ID and T1060740.RPTS_TO_DIM_ID = T1060742.RPTS_TO_DIM_ID and T1060732.DT_DIM_ID = nvl(T1060740.JOB_ENTRY_DT_DIM_ID , 0) and T1060722.RPTS_TO_DIM_ID = T1060740.PREV_RPTS_TO_DIM_ID and T1060729.DT_DIM_ID = T1060740.DT_DIM_ID and T1060724.LOC_DIM_ID = T1060740.PREV_LOC_DIM_ID and T1060740.PREV_JOB_DIM_ID = T1060746.JOB_DIM_ID and T1060740.LOC_DIM_ID = T1060763.LOC_DIM_ID and T1060738.DT_DIM_ID = T1060740.TERM_DT_DIM_ID and T1060740.ORIG_HIRE_DT_DIM_ID = T1060744.DT_DIM_ID and T1060740.DEPT_DIM_ID = T1060752.DEPT_DIM_ID and T1060727.DT_DIM_ID = T1060740.LAST_HIRE_DT_DIM_ID and T1060740.EXPECTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and T1060728.EMP_DIM_ID = T1060740.EMP_DIM_ID and T1060740.SERVICE_DT_DIM_ID = T1060745.DT_DIM_ID and T1060729.YYMM_NUM = $1";

  perf = "select distinct T1060758.FULL_DT as c1, T1060752.DEPT_ID as c2, T1060752.DEPT_NM as c3, T1060752.FINC_LVL_1_DESC as c4, T1060752.FINC_LVL_10_DESC as c5, T1060752.FINC_LVL_11_DESC as c6, T1060752.FINC_LVL_12_DESC as c7, T1060752.FINC_LVL_13_DESC as c8, T1060752.FINC_LVL_14_DESC as c9, T1060752.FINC_LVL_15_DESC as c10, T1060752.FINC_LVL_2_DESC as c11, T1060752.FINC_LVL_3_DESC as c12, T1060752.FINC_LVL_4_DESC as c13, T1060752.FINC_LVL_5_DESC as c14, T1060752.FINC_LVL_6_DESC as c15, T1060752.FINC_LVL_7_DESC as c16, T1060752.FINC_LVL_8_DESC as c17, T1060752.FINC_LVL_9_DESC as c18, T1060728.ALT_EMP_ID as c19, T1060728.BRTH_MMDD_DT as c20, T1060728.EMP_ID as c21, T1060728.ENT_USER_ID as c22, T1060728.FRST_NM as c23, T1060728.FULL_NM as c24, T1060728.LAST_NM as c25, T1060728.MID_NM as c26, T1060728.PRFX_NM as c27, T1060728.WORK_EMAIL_ADR_TXT as c28, T1060740.ACQN_CMPY_NM as c29, T1060740.ACQN_IND as c30, T1060740.ACQN_LEGAL_DAY_1_DT as c31, T1060740.BUS_UNIT_CD as c32, T1060740.BUS_UNIT_NM as c33, T1060740.CMPY_CD as c34, T1060740.CMPY_NM as c35, T1060740.EMP_CLASS_DESC as c36, T1060740.EMP_STATUS_CD as c37, T1060740.EMP_STATUS_DESC as c38, T1060740.EMP_TYPE_DESC as c39, T1060740.EXTRNL_HIRE_IND as c40, T1060740.FTE_NUM as c41, T1060740.FULL_PART_TM_CD as c42, T1060740.HEAD_CNT_IND as c43, --case when(instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'NON_HR') > 1 or instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'CANADIAN_HRC') >= 1) and T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources') then NULL else T1060740.HIGH_PERFR_IND end as c44, T1060740.INTERNAL_ZIP_ID as c45, T1060740.INVOL_NONRIF_ATRTN_IND as c46, T1060740.INVOL_RIF_ATRTN_IND as c47, --case when (instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'NON_HR') > 1 or instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'CANADIAN_HRC') >= 1) and T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources') or TO_DATE('2017-12-04' , 'YYYY-MM-DD') between TO_DATE('2014-12-01' , 'YYYY-MM-DD') and TO_DATE('2015-02-11' , 'YYYY-MM-DD') then NULL else T1060740.LAST_APRSL_RATG_DESC end as c48, T1060740.PPL_MGR_IND as c49, --case when (instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'NON_HR') > 1 or instr('BIConsumer;BIAuthor;BIAdministrator;OBI_WFDB_HELP_PAGE_ROLE;AuthenticatedUser' , 'CANADIAN_HRC') >= 1) and T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources') then NULL else T1060740.PRIOR_APRSL_RATG_DESC end as c50, T1060719.DEPT_ID as c51, T1060719.DEPT_NM as c52, T1060722.EC_NM as c53, T1060722.EC1_NM as c54, T1060722.EC2_NM as c55, T1060722.EC3_NM as c56, T1060722.EC4_NM as c57, T1060722.EC5_NM as c58, T1060722.EC6_NM as c59, T1060722.EC7_NM as c60, T1060722.EC8_NM as c61, T1060722.EC9_NM as c62, T1060746.FLSA_STAT_DESC as c63, T1060746.JOB_CD as c64, T1060746.JOB_FMLY_DESC as c65, T1060746.JOB_LVL_CD as c66, T1060746.JOB_LVL_DESC as c67, T1060746.JOB_DESC as c68, T1060724.LOC_CD as c69, T1060724.LOC_NM as c70, T1060719.FINC_LVL_1_DESC as c71, T1060719.FINC_LVL_10_DESC as c72, T1060719.FINC_LVL_11_DESC as c73, T1060719.FINC_LVL_12_DESC as c74, T1060719.FINC_LVL_13_DESC as c75, T1060719.FINC_LVL_14_DESC as c76, T1060719.FINC_LVL_15_DESC as c77, T1060719.FINC_LVL_2_DESC as c78, T1060719.FINC_LVL_3_DESC as c79, T1060719.FINC_LVL_4_DESC as c80, T1060719.FINC_LVL_5_DESC as c81, T1060719.FINC_LVL_6_DESC as c82, T1060719.FINC_LVL_7_DESC as c83, T1060719.FINC_LVL_8_DESC as c84, T1060719.FINC_LVL_9_DESC as c85, T1060724.WORK_CITY_NM as c86, T1060724.WORK_CNTRY_NM as c87, T1060724.WORK_ST_CD as c88, T1060724.WORK_ZIP_CD as c89, T1060740.TRFR_IND as c90, T1060740.VOL_ATRTN_IND as c91, T1060769.FULL_DT as c92, T1060732.FULL_DT as c93, T1060723.FLSA_STAT_DESC as c94, T1060723.JOB_CD as c95, T1060723.JOB_FMLY_DESC as c96, T1060723.JOB_LVL_CD as c97, T1060723.JOB_LVL_DESC as c98, T1060723.JOB_DESC as c99, T1060755.FULL_DT as c100, T1060727.FULL_DT as c101, T1060763.LOC_CD as c102, T1060763.LOC_NM as c103, T1060763.WORK_CITY_NM as c104, T1060763.WORK_CNTRY_NM as c105, T1060763.WORK_ST_CD as c106, T1060763.WORK_ZIP_CD as c107, T1060740.ASSOC_TYPE_DESC as c108, T1060740.PROMO_IND as c109, T1060744.FULL_DT as c110, T1060760.FULL_DT as c111, T1060742.EC_NM as c112, T1060742.EC1_NM as c113, T1060742.EC2_NM as c114, T1060742.EC3_NM as c115, T1060742.EC4_NM as c116, T1060742.EC5_NM as c117, T1060742.EC6_NM as c118, T1060742.EC7_NM as c119, T1060742.EC8_NM as c120, T1060742.EC9_NM as c121, T1060745.FULL_DT as c122, T1060738.FULL_DT as c123, case when T1060740.ACTUAL_LAST_DAY_OF_LEAVE is null then NULL else T1060740.ACTUAL_LAST_DAY_OF_LEAVE end as c124, case when T1060740.LAST_DAY_OF_WORK is null then NULL else T1060740.LAST_DAY_OF_WORK end as c125, case when not T1060742.EC10_NM is null then T1060742.EC10_ID else case when not T1060742.EC9_NM is null then T1060742.EC9_ID else case when not T1060742.EC8_NM is null then T1060742.EC8_ID else case when not T1060742.EC7_NM is null then T1060742.EC7_ID else case when not T1060742.EC6_NM is null then T1060742.EC6_ID else case when not T1060742.EC5_NM is null then T1060742.EC5_ID else case when not T1060742.EC4_NM is null then T1060742.EC4_ID else case when not T1060742.EC3_NM is null then T1060742.EC3_ID else case when not T1060742.EC2_NM is null then T1060742.EC2_ID else case when not T1060742.EC1_NM is null then T1060742.EC1_ID else case when not T1060742.EC_NM is null then T1060742.EC_ID else case when not T1060742.CEO_NM is null then T1060742.CEO_ID else NULL end end end end end end end end end end end end as c126, case when not T1060742.EC10_NM is null then T1060742.EC10_NM else case when not T1060742.EC9_NM is null then T1060742.EC9_NM else case when not T1060742.EC8_NM is null then T1060742.EC8_NM else case when not T1060742.EC7_NM is null then T1060742.EC7_NM else case when not T1060742.EC6_NM is null then T1060742.EC6_NM else case when not T1060742.EC5_NM is null then T1060742.EC5_NM else case when not T1060742.EC4_NM is null then T1060742.EC4_NM else case when not T1060742.EC3_NM is null then T1060742.EC3_NM else case when not T1060742.EC2_NM is null then T1060742.EC2_NM else case when not T1060742.EC1_NM is null then T1060742.EC1_NM else case when not T1060742.EC_NM is null then T1060742.EC_NM else case when not T1060742.CEO_NM is null then T1060742.CEO_NM else NULL end end end end end end end end end end end end as c127, case when not T1060742.EC10_NM is null then T1060742.EC10_WORK_EMAIL_ADR_TXT else case when not T1060742.EC9_NM is null then T1060742.EC9_WORK_EMAIL_ADR_TXT else case when not T1060742.EC8_NM is null then T1060742.EC8_WORK_EMAIL_ADR_TXT else case when not T1060742.EC7_NM is null then T1060742.EC7_WORK_EMAIL_ADR_TXT else case when not T1060742.EC6_NM is null then T1060742.EC6_WORK_EMAIL_ADR_TXT else case when not T1060742.EC5_NM is null then T1060742.EC5_WORK_EMAIL_ADR_TXT else case when not T1060742.EC4_NM is null then T1060742.EC4_WORK_EMAIL_ADR_TXT else case when not T1060742.EC3_NM is null then T1060742.EC3_WORK_EMAIL_ADR_TXT else case when not T1060742.EC2_NM is null then T1060742.EC2_WORK_EMAIL_ADR_TXT else case when not T1060742.EC1_NM is null then T1060742.EC1_WORK_EMAIL_ADR_TXT else case when not T1060742.EC_NM is null then T1060742.EC_WORK_EMAIL_ADR_TXT else case when not T1060742.CEO_NM is null then T1060742.CEO_WORK_EMAIL_ADR_TXT else NULL end end end end end end end end end end end end as c128 from phrdw.DEPT_DIM T1060719 /* Dim_DEPT_DIM_Previous */ , phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ , phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ , phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ , phrdw.DT_DIM T1060760 /* Dim_DT_DIM_Prior_Appraisal */ , phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ , phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ , phrdw.RPTS_TO_DIM T1060722 /* Dim_RPTS_TO_DIM_Previous */ , phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ , phrdw.LOC_DIM T1060724 /* Dim_LOC_DIM_Previous */ , phrdw.JOB_DIM T1060746 /* Dim_JOB_DIM_Previous */ , phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ , phrdw.DT_DIM T1060755 /* Dim_DT_DIM_Last_Appraisal */ , phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ , phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ , phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ , phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ , phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ , phrdw.EMP_DIM T1060728 /* Dim_EMP_DIM */ , phrdw.EMP_EOM_FACT T1060740 /* Fact_EMP_EOM_FACT */ where ( T1060719.DEPT_DIM_ID = T1060740.PREV_DEPT_DIM_ID and T1060723.JOB_DIM_ID = T1060740.JOB_DIM_ID and T1060740.PRIOR_APRSL_DT_DIM_ID = T1060760.DT_DIM_ID and T1060740.RPTS_TO_DIM_ID = T1060742.RPTS_TO_DIM_ID and T1060732.DT_DIM_ID = nvl(T1060740.JOB_ENTRY_DT_DIM_ID , 0) and T1060722.RPTS_TO_DIM_ID = T1060740.PREV_RPTS_TO_DIM_ID and T1060729.DT_DIM_ID = T1060740.DT_DIM_ID and T1060724.LOC_DIM_ID = T1060740.PREV_LOC_DIM_ID and T1060740.PREV_JOB_DIM_ID = T1060746.JOB_DIM_ID and T1060740.LOC_DIM_ID = T1060763.LOC_DIM_ID and T1060740.LAST_APRSL_DT_DIM_ID = T1060755.DT_DIM_ID and T1060738.DT_DIM_ID = T1060740.TERM_DT_DIM_ID and T1060740.ORIG_HIRE_DT_DIM_ID = T1060744.DT_DIM_ID and T1060740.DEPT_DIM_ID = T1060752.DEPT_DIM_ID and T1060727.DT_DIM_ID = T1060740.LAST_HIRE_DT_DIM_ID and T1060740.EXPECTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and T1060728.EMP_DIM_ID = T1060740.EMP_DIM_ID and T1060740.SERVICE_DT_DIM_ID = T1060745.DT_DIM_ID and T1060729.YYMM_NUM = $1";

  all = "select distinct T1060758.FULL_DT as c1, T1060752.DEPT_ID as c2, T1060752.DEPT_NM as c3, T1060752.FINC_LVL_1_DESC as c4, T1060752.FINC_LVL_10_DESC as c5, T1060752.FINC_LVL_11_DESC as c6, T1060752.FINC_LVL_12_DESC as c7, T1060752.FINC_LVL_13_DESC as c8, T1060752.FINC_LVL_14_DESC as c9, T1060752.FINC_LVL_15_DESC as c10, T1060752.FINC_LVL_2_DESC as c11, T1060752.FINC_LVL_3_DESC as c12, T1060752.FINC_LVL_4_DESC as c13, T1060752.FINC_LVL_5_DESC as c14, T1060752.FINC_LVL_6_DESC as c15, T1060752.FINC_LVL_7_DESC as c16, T1060752.FINC_LVL_8_DESC as c17, T1060752.FINC_LVL_9_DESC as c18, case when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end < 25 then 'Under 25' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 25 and 34 then '25 to 34' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 35 and 44 then '35 to 44' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end between 45 and 54 then '45 to 54' when case when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99') and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99') then TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1 else TO_NUMBER(TO_CHAR(TO_DATE('2017-12-04 10:46:33' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') end > 55 then '55 and over' else 'Unspecified' end as c19, T1060728.ALT_EMP_ID as c20, T1060728.BRTH_DT as c21, T1060728.BRTH_MMDD_DT as c22, T1060728.CNDA_ABORIG_IND as c23, T1060728.CNDA_VSBL_MNORT_IND as c24, T1060728.DSABLD_IND as c25, T1060728.EMP_ID as c26, T1060728.ETHNIC_GRP_DESC as c27, T1060728.ENT_USER_ID as c28, T1060728.FRST_NM as c29, T1060728.FULL_NM as c30, T1060728.GNDR_DESC as c31, T1060728.LAST_NM as c32, T1060728.MID_NM as c33, T1060728.MIL_DSCHRG_DT as c34, T1060728.MIL_STAT_DESC as c35, T1060728.PERS_OF_COLOR_IND as c36, T1060728.PRFX_NM as c37, T1060728.UK_ETHNIC_GRP_DESC as c38, T1060728.WORK_EMAIL_ADR_TXT as c39, T1060740.ACQN_CMPY_NM as c40, T1060740.ACQN_IND as c41, T1060740.ACQN_LEGAL_DAY_1_DT as c42, T1060740.ASSOC_TYPE_DESC as c43, T1060740.BUS_UNIT_CD as c44, T1060740.BUS_UNIT_NM as c45, T1060740.CMPY_CD as c46, T1060740.CMPY_NM as c47, T1060740.EMP_CLASS_DESC as c48, T1060740.EMP_STATUS_CD as c49, T1060740.EMP_STATUS_DESC as c50, T1060740.EMP_TYPE_DESC as c51, T1060740.EXTRNL_HIRE_IND as c52, T1060740.FTE_NUM as c53, T1060740.FULL_PART_TM_CD as c54, T1060740.HEAD_CNT_IND as c55, T1060740.INTERNAL_ZIP_ID as c56, T1060740.INVOL_NONRIF_ATRTN_IND as c57, T1060740.INVOL_RIF_ATRTN_IND as c58, T1060740.PPL_MGR_IND as c59, T1060719.DEPT_ID as c60, T1060719.DEPT_NM as c61, T1060722.EC_NM as c62, T1060722.EC1_NM as c63, T1060722.EC2_NM as c64, T1060722.EC3_NM as c65, T1060722.EC4_NM as c66, T1060722.EC5_NM as c67, T1060722.EC6_NM as c68, T1060722.EC7_NM as c69, T1060722.EC8_NM as c70, T1060722.EC9_NM as c71, T1060746.FLSA_STAT_DESC as c72, T1060746.JOB_CD as c73, T1060746.JOB_FMLY_DESC as c74, T1060746.JOB_LVL_CD as c75, T1060746.JOB_LVL_DESC as c76, T1060746.JOB_DESC as c77, T1060724.LOC_CD as c78, T1060724.LOC_NM as c79, T1060719.FINC_LVL_1_DESC as c80, T1060719.FINC_LVL_10_DESC as c81, T1060719.FINC_LVL_11_DESC as c82, T1060719.FINC_LVL_12_DESC as c83, T1060719.FINC_LVL_13_DESC as c84, T1060719.FINC_LVL_14_DESC as c85, T1060719.FINC_LVL_15_DESC as c86, T1060719.FINC_LVL_2_DESC as c87, T1060719.FINC_LVL_3_DESC as c88, T1060719.FINC_LVL_4_DESC as c89, T1060719.FINC_LVL_5_DESC as c90, T1060719.FINC_LVL_6_DESC as c91, T1060719.FINC_LVL_7_DESC as c92, T1060719.FINC_LVL_8_DESC as c93, T1060719.FINC_LVL_9_DESC as c94, T1060724.WORK_CITY_NM as c95, T1060724.WORK_CNTRY_NM as c96, T1060724.WORK_ST_CD as c97, T1060724.WORK_ZIP_CD as c98, T1060740.TRFR_IND as c99, T1060740.VOL_ATRTN_IND as c100, T1060769.FULL_DT as c101, T1060732.FULL_DT as c102, T1060723.FLSA_STAT_DESC as c103, T1060723.JOB_CD as c104, T1060723.JOB_FMLY_DESC as c105, T1060723.JOB_LVL_CD as c106, T1060723.JOB_LVL_DESC as c107, T1060723.JOB_DESC as c108, T1060727.FULL_DT as c109, T1060763.LOC_CD as c110, T1060763.LOC_NM as c111, T1060763.WORK_CITY_NM as c112, T1060763.WORK_CNTRY_NM as c113, T1060763.WORK_ST_CD as c114, T1060763.WORK_ZIP_CD as c115, T1060740.PROMO_IND as c116, T1060744.FULL_DT as c117, T1060742.EC_NM as c118, T1060742.EC1_NM as c119, T1060742.EC2_NM as c120, T1060742.EC3_NM as c121, T1060742.EC4_NM as c122, T1060742.EC5_NM as c123, T1060742.EC6_NM as c124, T1060742.EC7_NM as c125, T1060742.EC8_NM as c126, T1060742.EC9_NM as c127, T1060745.FULL_DT as c128, T1060738.FULL_DT as c129, case when T1060740.ACTUAL_LAST_DAY_OF_LEAVE is null then NULL else T1060740.ACTUAL_LAST_DAY_OF_LEAVE end as c130, case when T1060740.LAST_DAY_OF_WORK is null then NULL else T1060740.LAST_DAY_OF_WORK end as c131, case when not T1060742.EC10_NM is null then T1060742.EC10_ID else case when not T1060742.EC9_NM is null then T1060742.EC9_ID else case when not T1060742.EC8_NM is null then T1060742.EC8_ID else case when not T1060742.EC7_NM is null then T1060742.EC7_ID else case when not T1060742.EC6_NM is null then T1060742.EC6_ID else case when not T1060742.EC5_NM is null then T1060742.EC5_ID else case when not T1060742.EC4_NM is null then T1060742.EC4_ID else case when not T1060742.EC3_NM is null then T1060742.EC3_ID else case when not T1060742.EC2_NM is null then T1060742.EC2_ID else case when not T1060742.EC1_NM is null then T1060742.EC1_ID else case when not T1060742.EC_NM is null then T1060742.EC_ID else case when not T1060742.CEO_NM is null then T1060742.CEO_ID else NULL end end end end end end end end end end end end as c132, case when not T1060742.EC10_NM is null then T1060742.EC10_NM else case when not T1060742.EC9_NM is null then T1060742.EC9_NM else case when not T1060742.EC8_NM is null then T1060742.EC8_NM else case when not T1060742.EC7_NM is null then T1060742.EC7_NM else case when not T1060742.EC6_NM is null then T1060742.EC6_NM else case when not T1060742.EC5_NM is null then T1060742.EC5_NM else case when not T1060742.EC4_NM is null then T1060742.EC4_NM else case when not T1060742.EC3_NM is null then T1060742.EC3_NM else case when not T1060742.EC2_NM is null then T1060742.EC2_NM else case when not T1060742.EC1_NM is null then T1060742.EC1_NM else case when not T1060742.EC_NM is null then T1060742.EC_NM else case when not T1060742.CEO_NM is null then T1060742.CEO_NM else NULL end end end end end end end end end end end end as c133, case when not T1060742.EC10_NM is null then T1060742.EC10_WORK_EMAIL_ADR_TXT else case when not T1060742.EC9_NM is null then T1060742.EC9_WORK_EMAIL_ADR_TXT else case when not T1060742.EC8_NM is null then T1060742.EC8_WORK_EMAIL_ADR_TXT else case when not T1060742.EC7_NM is null then T1060742.EC7_WORK_EMAIL_ADR_TXT else case when not T1060742.EC6_NM is null then T1060742.EC6_WORK_EMAIL_ADR_TXT else case when not T1060742.EC5_NM is null then T1060742.EC5_WORK_EMAIL_ADR_TXT else case when not T1060742.EC4_NM is null then T1060742.EC4_WORK_EMAIL_ADR_TXT else case when not T1060742.EC3_NM is null then T1060742.EC3_WORK_EMAIL_ADR_TXT else case when not T1060742.EC2_NM is null then T1060742.EC2_WORK_EMAIL_ADR_TXT else case when not T1060742.EC1_NM is null then T1060742.EC1_WORK_EMAIL_ADR_TXT else case when not T1060742.EC_NM is null then T1060742.EC_WORK_EMAIL_ADR_TXT else case when not T1060742.CEO_NM is null then T1060742.CEO_WORK_EMAIL_ADR_TXT else NULL end end end end end end end end end end end end as c134 from phrdw.DEPT_DIM T1060719 /* Dim_DEPT_DIM_Previous */ , phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ , phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ , phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ , phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ , phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ , phrdw.RPTS_TO_DIM T1060722 /* Dim_RPTS_TO_DIM_Previous */ , phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ , phrdw.LOC_DIM T1060724 /* Dim_LOC_DIM_Previous */ , phrdw.JOB_DIM T1060746 /* Dim_JOB_DIM_Previous */ , phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ , phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ , phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ , phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ , phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ , phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ , phrdw.EMP_DIM T1060728 /* Dim_EMP_DIM */ , phrdw.EMP_EOM_FACT T1060740 /* Fact_EMP_EOM_FACT */ where( T1060719.DEPT_DIM_ID = T1060740.PREV_DEPT_DIM_ID and T1060723.JOB_DIM_ID = T1060740.JOB_DIM_ID and T1060740.RPTS_TO_DIM_ID = T1060742.RPTS_TO_DIM_ID and T1060732.DT_DIM_ID = nvl(T1060740.JOB_ENTRY_DT_DIM_ID , 0) and T1060722.RPTS_TO_DIM_ID = T1060740.PREV_RPTS_TO_DIM_ID and T1060729.DT_DIM_ID = T1060740.DT_DIM_ID and T1060724.LOC_DIM_ID = T1060740.PREV_LOC_DIM_ID and T1060740.PREV_JOB_DIM_ID = T1060746.JOB_DIM_ID and T1060740.LOC_DIM_ID = T1060763.LOC_DIM_ID and T1060738.DT_DIM_ID = T1060740.TERM_DT_DIM_ID and T1060740.ORIG_HIRE_DT_DIM_ID = T1060744.DT_DIM_ID and T1060740.DEPT_DIM_ID = T1060752.DEPT_DIM_ID and T1060727.DT_DIM_ID = T1060740.LAST_HIRE_DT_DIM_ID and T1060740.EXPECTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and T1060728.EMP_DIM_ID = T1060740.EMP_DIM_ID and T1060740.SERVICE_DT_DIM_ID = T1060745.DT_DIM_ID and T1060729.YYMM_NUM = $1";

  if (req.body.view) {
    switch(req.body.view) {
      case 'performance':
        console.log('Performance View');
        head = perf;
        break;
      case 'personal':
        console.log('Personal View');
        head = personal;
        break;
      case 'compensation':
        console.log('Compensation View');
        head = compensation;
        break;
      case 'diversity':
        console.log('Diversity View');
        head = diversity;
        break;
      case 'all':
        console.log('All View');
        head = all;
        break;
      default:
        break;
    }
  }

  let varCounter = 1;
  let base = '';

  let parms = [ req.body.date ];

  // Row Level Security: Select Based on EC Members
  if (req.body.rows && req.body.rows.length > 0) {
    base += ' AND t1060742.ec_id in (' + req.body.rows.map(jl => `'${jl}'`).join(',') + ')';
  }

  if (req.body.asctype !== "All") {
    base += ' AND t1060740.assoc_type_desc = $' + (++varCounter).toString();
    parms.push(req.body.asctype);
  }

  if (req.body.flsa && req.body.flsa !== "All") {
    base += ' AND t1060723.flsa_stat_cd = $' + (++varCounter).toString();
    parms.push(req.body.flsa);
  }

  if (req.body.job_level && req.body.job_level.length > 0) {
    base += ' AND t1060723.job_lvl_cd in (' + req.body.job_level.map(jl => `'${jl}'`).join(',') + ')';
  }

  if (req.body.emp_status && req.body.emp_status !== "All") {
    base += ' AND t1060740.emp_status_cd = $' + (++varCounter).toString();
    parms.push(req.body.emp_status);
  }

  if (req.body.country !== undefined && req.body.country.length > 0) {
    base += ' AND t1060763.work_cntry_nm in (' + req.body.country.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.state !== undefined && req.body.state.length > 0) {
    base += ' AND t1060763.work_st_cd in (' + req.body.state.map(st => `'${st}'`).join(',') + ')';
  }

  if (req.body.city !== undefined && req.body.city.length > 0) {
    base += ' AND t1060763.work_city_nm in (' + req.body.city.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.building !== undefined && req.body.building.length > 0) {
    base += ' AND t1060763.loc_cd in (' + req.body.building.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.dept !== undefined && req.body.dept.length > 0) {
    base += ' AND t1060752.dept_id in (' + req.body.dept.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.fname && req.body.fname !== "") {
    base += ' AND LOWER(t1060728.frst_nm) = $' + (++varCounter).toString();
    parms.push(req.body.fname.toLowerCase());
  }

  if (req.body.lname && req.body.lname !== "") {
    base += ' AND LOWER(t1060728.last_nm) = $' + (++varCounter).toString();
    parms.push(req.body.lname.toLowerCase());
  }

  if (req.body.empid && req.body.empid !== "") {
    base += ' AND t1060728.emp_id = $' + (++varCounter).toString();
    parms.push(req.body.empid);
  }

  if (req.body.reports_to1 && req.body.reports_to1.length > 0) {
    base += ' AND t1060742.ec_nm in (' + req.body.reports_to1.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.reports_to2 && req.body.reports_to2.length > 0) {
    base += ' AND t1060742.ec1_nm in (' + req.body.reports_to2.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.reports_to3 && req.body.reports_to3.length > 0) {
    base += ' AND t1060742.ec2_nm in (' + req.body.reports_to3.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.reports_to4 && req.body.reports_to4.length > 0) {
    base += ' AND t1060742.ec3_nm in (' + req.body.reports_to4.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.org_level1 && req.body.org_level1.length > 0) {
    base += ' AND t1060752.finc_lvl_1_desc in (' + req.body.org_level1.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level2 && req.body.org_level2.length > 0) {
    base += ' AND t1060752.finc_lvl_2_desc in (' + req.body.org_level2.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level3 && req.body.org_level3.length > 0) {
    base += ' AND t1060752.finc_lvl_3_desc in (' + req.body.org_level3.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level4 && req.body.org_level4.length > 0) {
    base += ' AND t1060752.finc_lvl_4_desc in (' + req.body.org_level4.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level5 && req.body.org_level5.length > 0) {
    base += ' AND t1060752.finc_lvl_5_desc in (' + req.body.org_level5.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level6 && req.body.org_level6.length > 0) {
    base += ' AND t1060752.finc_lvl_6_desc in (' + req.body.org_level6.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level7 && req.body.org_level7.length > 0) {
    base += ' AND t1060752.finc_lvl_7_desc in (' + req.body.org_level7.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level8 && req.body.org_level8.length > 0) {
    base += ' AND t1060752.finc_lvl_8_desc in (' + req.body.org_level8.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level9 && req.body.org_level9.length > 0) {
    base += ' AND t1060752.finc_lvl_9_desc in (' + req.body.org_level9.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level10 && req.body.org_level10.length > 0) {
    base += ' AND t1060752.finc_lvl_10_desc in (' + req.body.org_level10.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level11 && req.body.org_level11.length > 0) {
    base += ' AND t1060752.finc_lvl_11_desc in (' + req.body.org_level11.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level12 && req.body.org_level12.length > 0) {
    base += ' AND t1060752.finc_lvl_12_desc in (' + req.body.org_level12.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.query['format'] === 'csv') {
    //base += '';
  } else {
    base += ' LIMIT 25';
  }
  console.log(base);
  const eom_query = {
    name: 'eom-report',
    text: head + base,
    values: parms
  };

  db.query(eom_query, (err, data) => {
    if (err) {
      console.log(err);
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch departments']
      });
    }
    console.log('Results Count: ' + data.rows.length);
    res.send(data.rows);
  });
});

module.exports = router;
