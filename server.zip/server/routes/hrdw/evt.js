const express = require('express');
const router = express.Router();
const db = require('../../db/hrdw');

router.post('/results', (req, res) => {
  head = `SELECT DISTINCT
  t1060728.emp_id AS c50,
  t1060728.ent_user_id AS c51,
  t1060728.alt_emp_id AS c48,
  t1060728.prfx_nm AS c56,
  t1060728.frst_nm AS c52,
  t1060728.mid_nm AS c55,
  t1060728.last_nm AS c54,
  t1060728.full_nm AS c53,
  t1060728.work_email_adr_txt AS c57,
  t1060764.assoc_type_desc AS c29,
  t1060723.flsa_stat_desc AS c60,
  t1060764.emp_type_desc AS c37,
  t1060764.emp_class_desc AS c34,
  t1060764.emp_status_cd AS c35,
  CASE
  WHEN t1060764.emp_status_desc
  IN ( 'Leave','Leave With Pay','Leave of Absence' )
  THEN 'Leave of Absence'
  ELSE t1060764.emp_status_desc
  END AS c36,
  CASE
    WHEN t1060764.last_day_of_work IS NULL
    THEN NULL
    ELSE to_char(t1060764.last_day_of_work, 'MM/DD/YYYY')
  END AS c88,
  to_char(t1060769.full_dt, 'MM/DD/YYYY') AS c58,
  CASE
  WHEN
  t1060764.actual_last_day_of_leave IS NULL
  THEN NULL
  ELSE to_char(t1060764.actual_last_day_of_leave, 'MM/DD/YYYY')
  END AS c87,
  to_char(t1060745.full_dt, 'MM/DD/YYYY') AS c85,
  to_char(t1060744.full_dt, 'MM/DD/YYYY') AS c73,
  to_char(t1060727.full_dt, 'MM/DD/YYYY') AS c66,
  to_char(t1060738.full_dt, 'MM/DD/YYYY') AS c86,
  to_char(t1060757.full_dt, 'MM/DD/YYYY') AS c1,
  to_char(t1060762.full_dt, 'MM/DD/YYYY') AS c20,
  t1060764.seq_num AS c45,
  CASE
    WHEN t1060720.actn_catg_desc
        IN( 'Contract Contingent Worker','Hire','Hire Employee')
    THEN 'Hire'
    WHEN t1060720.actn_catg_desc IN ( 'Change Job','Job/Grade Change' )
    THEN 'Job/Grade Change'
    WHEN t1060720.actn_catg_desc IN ( 'Leave','Leave of Absence' )
    THEN 'Leave of Absence'
    WHEN t1060720.actn_catg_desc
        IN ( 'One-Time Payment','Pay Rate Change','Request Compensation Change' )
    THEN 'Pay Rate Change'
    WHEN t1060720.actn_catg_desc
        IN ( 'Add Retiree Status','End Contingent Worker Contract',
             'Terminate Employee','Termination' )
    THEN 'Termination'
    WHEN t1060720.actn_catg_desc
        IN ( 'Change Organization Assignments for Worker',
             'End International Assignment','Transfer',
             'Transfer Contingent Worker' )
    THEN 'Transfer'
    WHEN t1060720.actn_catg_desc
        IN ( 'Close Position or Headcount','Create Position',
             'Edit Position','End Additional Employee Job',
             'Freeze Position,Headcount,or Job Group' ,
             'Move to New Manager','Profile Change','Remove Retiree Status',
             'Start International Assignment',
             'Statutory Compensation Statement' )
    THEN 'Profile Change'
    ELSE t1060720.actn_catg_desc
  END AS c24,
  t1060720.actn_cd AS c25,
  t1060720.actn_desc AS c28,
  t1060720.actn_reas_cd AS c26,
  t1060720.actn_reas_desc AS c27,
  t1060764.full_part_tm_cd AS c40,
  t1060764.fte_num AS c39,
  t1060764.cmpy_cd AS c32,
  t1060764.cmpy_nm AS c33,
  t1060764.bus_unit_cd AS c30,
  t1060764.bus_unit_nm AS c31,
  t1060764.acqn_ind AS c22,
  t1060764.acqn_cmpy_nm AS c21,
  to_char(t1060764.acqn_legal_day_1_dt, 'MM/DD/YYYY') AS c23,
  t1060723.job_lvl_cd AS c63,
  t1060723.job_lvl_desc AS c64,
  t1060723.job_cd AS c61,
  t1060723.job_desc AS c65,
  t1060723.job_fmly_desc AS c62,
  to_char(t1060732.full_dt, 'MM/DD/YYYY') AS c59,
  to_char(t1215969.full_dt, 'MM/DD/YYYY') AS c74,
  CASE
    WHEN NOT t1060742.ec10_nm IS NULL
    THEN t1060742.ec10_id
    ELSE
      CASE
        WHEN NOT t1060742.ec9_nm IS NULL
        THEN t1060742.ec9_id
        ELSE
          CASE
            WHEN NOT t1060742.ec8_nm IS NULL
            THEN t1060742.ec8_id
            ELSE
              CASE
                WHEN NOT t1060742.ec7_nm IS NULL
                THEN t1060742.ec7_id
                ELSE
                  CASE
                    WHEN NOT t1060742.ec6_nm IS NULL
                    THEN t1060742.ec6_id
                    ELSE
                      CASE
                        WHEN NOT t1060742.ec5_nm IS NULL
                        THEN t1060742.ec5_id
                        ELSE
                          CASE
                            WHEN NOT t1060742.ec4_nm IS NULL
                            THEN t1060742.ec4_id
                            ELSE
                              CASE
                                WHEN NOT t1060742.ec3_nm IS NULL
                                THEN t1060742.ec3_id
                                ELSE
                                  CASE
                                    WHEN NOT t1060742.ec2_nm IS NULL
                                    THEN t1060742.ec2_id
                                    ELSE
                                      CASE
                                        WHEN NOT t1060742.ec1_nm IS NULL
                                        THEN t1060742.ec1_id
                                        ELSE
                                          CASE
                                            WHEN NOT t1060742.ec_nm IS NULL
                                            THEN t1060742.ec_id
                                            ELSE
                                              CASE
                                                WHEN NOT t1060742.ceo_nm IS NULL
                                                THEN t1060742.ceo_id
                                                ELSE NULL
                                              END
                                          END
                                      END
                                  END
                              END
                          END
                      END
                  END
              END
          END
      END
  END AS c89,
  CASE
    WHEN
      NOT t1060742.ec10_nm IS NULL
    THEN
      t1060742.ec10_nm
    ELSE
      CASE
        WHEN
          NOT t1060742.ec9_nm IS NULL
        THEN
          t1060742.ec9_nm
        ELSE
          CASE
            WHEN NOT t1060742.ec8_nm IS NULL
            THEN t1060742.ec8_nm
            ELSE
              CASE
                WHEN NOT t1060742.ec7_nm IS NULL
                THEN t1060742.ec7_nm
                ELSE
                  CASE
                    WHEN NOT t1060742.ec6_nm IS NULL
                    THEN t1060742.ec6_nm
                    ELSE
                      CASE
                        WHEN NOT t1060742.ec5_nm IS NULL
                        THEN t1060742.ec5_nm
                        ELSE
                          CASE
                            WHEN NOT t1060742.ec4_nm IS NULL
                            THEN t1060742.ec4_nm
                            ELSE
                              CASE
                                WHEN NOT t1060742.ec3_nm IS NULL
                                THEN t1060742.ec3_nm
                                ELSE
                                  CASE
                                    WHEN NOT t1060742.ec2_nm IS NULL
                                    THEN t1060742.ec2_nm
                                    ELSE
                                      CASE
                                        WHEN NOT t1060742.ec1_nm IS NULL
                                        THEN t1060742.ec1_nm
                                        ELSE
                                          CASE
                                            WHEN NOT t1060742.ec_nm IS NULL THEN t1060742.ec_nm
                                            ELSE
                                              CASE
                                                WHEN NOT t1060742.ceo_nm IS NULL
                                                THEN t1060742.ceo_nm
                                                ELSE NULL
                                              END
                                          END
                                      END
                                  END
                              END
                          END
                      END
                  END
              END
          END
      END
  END AS c90,
  CASE WHEN NOT t1060742.ec10_nm IS NULL THEN t1060742.ec10_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec9_nm IS NULL THEN t1060742.ec9_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec8_nm IS NULL THEN t1060742.ec8_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec7_nm IS NULL THEN t1060742.ec7_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec6_nm IS NULL THEN t1060742.ec6_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec5_nm IS NULL THEN t1060742.ec5_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec4_nm IS NULL THEN t1060742.ec4_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec3_nm IS NULL THEN t1060742.ec3_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec2_nm IS NULL THEN t1060742.ec2_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec1_nm IS NULL THEN t1060742.ec1_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ec_nm IS NULL THEN t1060742.ec_work_email_adr_txt ELSE CASE WHEN NOT t1060742.ceo_nm IS NULL THEN t1060742.ceo_work_email_adr_txt ELSE NULL
           END END END END END END END END END END END END AS c91,
  t1060742.ec_nm AS c75,
  t1060742.ec1_nm AS c76,
  t1060742.ec2_nm AS c77,
  t1060742.ec3_nm AS c78,
  t1060742.ec4_nm AS c79,
  t1060742.ec5_nm AS c80,
  t1060742.ec6_nm AS c81,
  t1060742.ec7_nm AS c82,
  t1060742.ec8_nm AS c83,
  t1060742.ec9_nm AS c84,
  t1060752.finc_lvl_1_desc AS c5,
  t1060752.finc_lvl_2_desc AS c12,
  t1060752.finc_lvl_3_desc AS c13,
  t1060752.finc_lvl_4_desc AS c14,
  t1060752.finc_lvl_5_desc AS c15,
  t1060752.finc_lvl_6_desc AS c16,
  t1060752.finc_lvl_7_desc AS c17,
  t1060752.finc_lvl_8_desc AS c18,
  t1060752.finc_lvl_9_desc AS c19,
  t1060752.finc_lvl_10_desc AS c6,
  t1060752.finc_lvl_11_desc AS c7,
  t1060752.finc_lvl_12_desc AS c8,
  t1060752.finc_lvl_13_desc AS c9,
  t1060752.finc_lvl_14_desc AS c10,
  t1060752.finc_lvl_15_desc AS c11,
  t1060752.dept_id AS c3,
  t1060752.dept_nm AS c4,
  t1060758.full_dt AS c2,
  t1060763.loc_cd AS c67,
  t1060763.loc_nm AS c68,
  t1060764.internal_zip_id AS c41,
  t1060763.work_city_nm AS c69,
  t1060763.work_st_cd AS c71,
  t1060763.work_zip_cd AS c72,
  t1060763.work_cntry_nm AS c70,
  t1060764.remote_worker_ind AS c44,
  t1060764.extrnl_hire_ind AS c38,
  t1060764.trfr_ind AS c46,
  t1060764.vol_atrtn_ind AS c47,
  t1060764.invol_atrtn_ind AS c42,
  t1060764.promo_ind AS c43,
  t1060728.brth_mmdd_dt AS c49
  FROM
    phrdw_tb.dt_dim t1215969 /* Dim_DT_DIM_Position_Entry */,
    phrdw_tb.actn_dim t1060720 /* Dim_ACTN_DIM */,
    phrdw_tb.job_dim t1060723 /* Dim_JOB_DIM */,
    phrdw_tb.dt_dim t1060745 /* Dim_DT_DIM_Service */,
    phrdw_tb.dt_dim t1060758 /* Dim_DT_DIM_Department_Entry */,
    phrdw_tb.rpts_to_dim t1060742 /* Dim_RPTS_TO_DIM */,
    phrdw_tb.dt_dim t1060732 /* Dim_DT_DIM_Job_Entry */,
    phrdw_tb.dt_dim t1060729 /* Dim_DT_DIM_Filter */,
    phrdw_tb.loc_dim t1060763 /* Dim_LOC_DIM */,
    phrdw_tb.emp_dim t1060728 /* Dim_EMP_DIM */,
    phrdw_tb.dt_dim t1060738 /* Dim_DT_DIM_Termination */,
    phrdw_tb.dt_dim t1060744 /* Dim_DT_DIM_Original_Hire */,
    phrdw_tb.dept_dim t1060752 /* Dim_DEPT_DIM */,
    phrdw_tb.dt_dim t1060727 /* Dim_DT_DIM_Last_Hire */,
    phrdw_tb.dt_dim t1060757 /* Dim_DT_DIM_Action */,
    phrdw_tb.dt_dim t1060762 /* Dim_DT_DIM_Effective_Date */,
    phrdw_tb.dt_dim t1060769 /* Dim_DT_DIM_Expected_Return */,
    phrdw_tb.emp_evt_fact t1060764 /* Fact_EMP_EVT_FACT */
  WHERE (
    t1060720.actn_dim_id = t1060764.actn_dim_id AND
    t1060723.job_dim_id = t1060764.job_dim_id AND
    t1060742.rpts_to_dim_id = t1060764.rpts_to_dim_id AND
    t1060732.dt_dim_id = nvl( t1060764.job_entry_dt_dim_id, 0 ) AND
    t1060729.dt_dim_id = t1060764.filter_dt_dim_id AND
    t1060745.dt_dim_id = t1060764.service_dt_dim_id AND
    t1060728.emp_dim_id = t1060764.emp_dim_id AND
    t1060738.dt_dim_id = t1060764.term_dt_dim_id AND
    t1060744.dt_dim_id = t1060764.orig_hire_dt_dim_id AND
    t1060752.dept_dim_id = t1060764.dept_dim_id AND
    t1060727.dt_dim_id = t1060764.last_hire_dt_dim_id AND
    t1060757.dt_dim_id = t1060764.actn_dt_dim_id AND
    t1060758.dt_dim_id = nvl( t1060764.dept_entry_dt_dim_id, 0 ) AND
    t1060762.dt_dim_id = t1060764.eff_dt_dim_id AND
    t1060763.loc_dim_id = t1060764.loc_dim_id AND
    t1060764.expctd_return_dt_dim_id = t1060769.dt_dim_id AND
    t1060764.pos_entry_dt_dim_id = t1215969.dt_dim_id AND `;

  perf = `SELECT DISTINCT
    t1060757.full_dt AS c1,
    t1060758.full_dt AS c2,
    t1060752.dept_id AS c3,
    t1060752.dept_nm AS c4,
    t1060752.finc_lvl_1_desc AS c5,
    t1060752.finc_lvl_10_desc AS c6,
    t1060752.finc_lvl_11_desc AS c7,
    t1060752.finc_lvl_12_desc AS c8,
    t1060752.finc_lvl_13_desc AS c9,
    t1060752.finc_lvl_14_desc AS c10,
    t1060752.finc_lvl_15_desc AS c11,
    t1060752.finc_lvl_2_desc AS c12,
    t1060752.finc_lvl_3_desc AS c13,
    t1060752.finc_lvl_4_desc AS c14,
    t1060752.finc_lvl_5_desc AS c15,
    t1060752.finc_lvl_6_desc AS c16,
    t1060752.finc_lvl_7_desc AS c17,
    t1060752.finc_lvl_8_desc AS c18,
    t1060752.finc_lvl_9_desc AS c19,
    t1060762.full_dt AS c20,
    t1060764.acqn_cmpy_nm AS c21,
    t1060764.acqn_ind AS c22,
    t1060764.acqn_legal_day_1_dt AS c23,
    CASE
      WHEN t1060720.actn_catg_desc IN (
          'Contract Contingent Worker','Hire','Hire Employee'
      ) THEN 'Hire'
      WHEN t1060720.actn_catg_desc IN (
          'Change Job','Job/Grade Change'
      ) THEN 'Job/Grade Change'
      WHEN t1060720.actn_catg_desc IN (
          'Leave','Leave of Absence'
      ) THEN 'Leave of Absence'
      WHEN t1060720.actn_catg_desc IN (
          'One-Time Payment','Pay Rate Change','Request Compensation Change'
      ) THEN 'Pay Rate Change'
      WHEN t1060720.actn_catg_desc IN (
          'Add Retiree Status','End Contingent Worker Contract',
          'Terminate Employee','Termination'
      ) THEN 'Termination'
      WHEN t1060720.actn_catg_desc IN (
          'Change Organization Assignments for Worker',
          'End International Assignment','Transfer','Transfer Contingent Worker'
      ) THEN 'Transfer'
      WHEN t1060720.actn_catg_desc IN (
          'Close Position or Headcount','Create Position','Edit Position',
          'End Additional Employee Job','Freeze Position,Headcount,or Job Group',
          'Move to New Manager','Profile Change','Remove Retiree Status',
          'Start International Assignment','Statutory Compensation Statement'
      ) THEN 'Profile Change'
      ELSE t1060720.actn_catg_desc
    END AS c24,
    t1060720.actn_cd AS c25,
    t1060720.actn_reas_cd AS c26,
    t1060720.actn_reas_desc AS c27,
    t1060720.actn_desc AS c28,
    t1060764.assoc_type_desc AS c29,
    t1060764.bus_unit_cd AS c30,
    t1060764.bus_unit_nm AS c31,
    t1060764.cmpy_cd AS c32,
    t1060764.cmpy_nm AS c33,
    t1060764.emp_class_desc AS c34,
    t1060764.emp_status_cd AS c35,
        CASE
            WHEN t1060764.emp_status_desc IN (
                'Leave','Leave With Pay','Leave of Absence'
            ) THEN 'Leave of Absence'
            ELSE t1060764.emp_status_desc
        END
    AS c36,
    t1060764.emp_type_desc AS c37,
    t1060764.extrnl_hire_ind AS c38,
    t1060764.fte_num AS c39,
    t1060764.full_part_tm_cd AS c40,
    CASE
      WHEN
        t1060752.finc_lvl_1_desc IN (
            'HR','HR & CRE','Human Resources'
        )
      THEN NULL
      ELSE t1060764.high_perfr_ind
    END AS c41,
    t1060764.internal_zip_id AS c42,
    t1060764.invol_atrtn_ind AS c43,
    CASE
      WHEN
        t1060752.finc_lvl_1_desc IN (
          'HR','HR & CRE','Human Resources'
        )
      OR
        TO_DATE('2017-10-23','YYYY-MM-DD') BETWEEN
          TO_DATE('2014-12-01','YYYY-MM-DD')
          AND
          TO_DATE('2015-02-11','YYYY-MM-DD')
      THEN NULL
      ELSE t1060764.last_aprsl_ratg_desc
    END
    AS c44,
    t1060764.promo_ind AS c45,
    t1060764.remote_worker_ind AS c46,
    t1060764.seq_num AS c47,
    t1060764.trfr_ind AS c48,
    t1060764.vol_atrtn_ind AS c49,
    t1060728.alt_emp_id AS c50,
    t1060728.brth_mmdd_dt AS c51,
    t1060728.emp_id AS c52,
    t1060728.ent_user_id AS c53,
    t1060728.frst_nm AS c54,
    t1060728.full_nm AS c55,
    t1060728.last_nm AS c56,
    t1060728.mid_nm AS c57,
    t1060728.prfx_nm AS c58,
    t1060728.work_email_adr_txt AS c59,
    t1060769.full_dt AS c60,
    t1060732.full_dt AS c61,
    t1060723.flsa_stat_desc AS c62,
    t1060723.job_cd AS c63,
    t1060723.job_fmly_desc AS c64,
    t1060723.job_lvl_cd AS c65,
    t1060723.job_lvl_desc AS c66,
    t1060723.job_desc AS c67,
    t1060755.full_dt AS c68,
    t1060727.full_dt AS c69,
    t1060763.loc_cd AS c70,
    t1060763.loc_nm AS c71,
    t1060763.work_city_nm AS c72,
    t1060763.work_cntry_nm AS c73,
    t1060763.work_st_cd AS c74,
    t1060763.work_zip_cd AS c75,
    t1060744.full_dt AS c76,
    t1215969.full_dt AS c77,
    t1060742.ec_nm AS c78,
    t1060742.ec1_nm AS c79,
    t1060742.ec2_nm AS c80,
    t1060742.ec3_nm AS c81,
    t1060742.ec4_nm AS c82,
    t1060742.ec5_nm AS c83,
    t1060742.ec6_nm AS c84,
    t1060742.ec7_nm AS c85,
    t1060742.ec8_nm AS c86,
    t1060742.ec9_nm AS c87,
    t1060745.full_dt AS c88,
    t1060738.full_dt AS c89,
    CASE
        WHEN t1060764.actual_last_day_of_leave IS NULL THEN NULL
        ELSE t1060764.actual_last_day_of_leave
    END AS c90,
    CASE
        WHEN t1060764.last_day_of_work IS NULL THEN NULL
        ELSE t1060764.last_day_of_work
    END AS c91,
    CASE
      WHEN NOT t1060742.ec10_nm IS NULL THEN t1060742.ec10_id
      ELSE
      CASE
        WHEN NOT t1060742.ec9_nm IS NULL THEN t1060742.ec9_id
        ELSE
          CASE
            WHEN NOT t1060742.ec8_nm IS NULL THEN t1060742.ec8_id
            ELSE
              CASE
                WHEN NOT t1060742.ec7_nm IS NULL THEN t1060742.ec7_id
                ELSE
                  CASE
                    WHEN NOT t1060742.ec6_nm IS NULL THEN t1060742.ec6_id
                    ELSE
                      CASE
                        WHEN NOT t1060742.ec5_nm IS NULL THEN t1060742.ec5_id
                        ELSE
                          CASE
                            WHEN NOT  t1060742.ec4_nm IS NULL THEN t1060742.ec4_id
                            ELSE
                              CASE
                                WHEN NOT t1060742.ec3_nm IS NULL THEN t1060742.ec3_id
                                ELSE
                                  CASE
                                    WHEN NOT t1060742.ec2_nm IS NULL THEN t1060742.ec2_id
                                    ELSE
                                      CASE
                                        WHEN NOT t1060742.ec1_nm IS NULL THEN t1060742.ec1_id
                                        ELSE
                                          CASE
                                            WHEN NOT t1060742.ec_nm IS NULL THEN t1060742.ec_id
                                            ELSE
                                              CASE
                                                WHEN NOT t1060742.ceo_nm IS NULL THEN t1060742.ceo_id
                                                ELSE NULL
                                              END
                                          END
                                      END
                                  END
                              END
                          END
                      END
                  END
              END
          END
      END
    END
    AS c92,
    CASE
        WHEN NOT
            t1060742.ec10_nm IS NULL
        THEN t1060742.ec10_nm
        ELSE
        CASE
            WHEN NOT
                t1060742.ec9_nm IS NULL
            THEN t1060742.ec9_nm
            ELSE
            CASE
                WHEN NOT
                    t1060742.ec8_nm IS NULL
                THEN t1060742.ec8_nm
                ELSE
                CASE
                    WHEN NOT
                        t1060742.ec7_nm IS NULL
                    THEN t1060742.ec7_nm
                    ELSE
                    CASE
                        WHEN NOT
                            t1060742.ec6_nm IS NULL
                        THEN t1060742.ec6_nm
                        ELSE
                        CASE
                            WHEN NOT
                                t1060742.ec5_nm IS NULL
                            THEN t1060742.ec5_nm
                            ELSE
                            CASE
                                WHEN NOT
                                    t1060742.ec4_nm IS NULL
                                THEN t1060742.ec4_nm
                                ELSE
                                CASE
                                    WHEN NOT
                                        t1060742.ec3_nm IS NULL
                                    THEN t1060742.ec3_nm
                                    ELSE
                                    CASE
                                        WHEN NOT
                                            t1060742.ec2_nm IS NULL
                                        THEN t1060742.ec2_nm
                                        ELSE
                                        CASE
                                            WHEN NOT
                                                t1060742.ec1_nm IS NULL
                                            THEN t1060742.ec1_nm
                                            ELSE
                                            CASE
                                                WHEN NOT
                                                    t1060742.ec_nm IS NULL
                                                THEN t1060742.ec_nm
                                                ELSE
                                                CASE
                                                    WHEN NOT
                                                        t1060742.ceo_nm IS NULL
                                                    THEN t1060742.ceo_nm
                                                    ELSE NULL
                                                END
                                            END
                                        END
                                    END
                                END
                            END
                        END
                    END
                END
            END
        END
    END
    AS c93,
    CASE
        WHEN NOT
            t1060742.ec10_nm IS NULL
        THEN t1060742.ec10_work_email_adr_txt
        ELSE
        CASE
            WHEN NOT
                t1060742.ec9_nm IS NULL
            THEN t1060742.ec9_work_email_adr_txt
            ELSE
            CASE
                WHEN NOT
                    t1060742.ec8_nm IS NULL
                THEN t1060742.ec8_work_email_adr_txt
                ELSE
                CASE
                    WHEN NOT
                        t1060742.ec7_nm IS NULL
                    THEN t1060742.ec7_work_email_adr_txt
                    ELSE
                    CASE
                        WHEN NOT
                            t1060742.ec6_nm IS NULL
                        THEN t1060742.ec6_work_email_adr_txt
                        ELSE
                        CASE
                            WHEN NOT
                                t1060742.ec5_nm IS NULL
                            THEN t1060742.ec5_work_email_adr_txt
                            ELSE
                            CASE
                                WHEN NOT
                                    t1060742.ec4_nm IS NULL
                                THEN t1060742.ec4_work_email_adr_txt
                                ELSE
                                CASE
                                    WHEN NOT
                                        t1060742.ec3_nm IS NULL
                                    THEN t1060742.ec3_work_email_adr_txt
                                    ELSE
                                    CASE
                                        WHEN NOT
                                            t1060742.ec2_nm IS NULL
                                        THEN t1060742.ec2_work_email_adr_txt
                                        ELSE
                                        CASE
                                            WHEN NOT
                                                t1060742.ec1_nm IS NULL
                                            THEN t1060742.ec1_work_email_adr_txt
                                            ELSE
                                            CASE
                                                WHEN NOT
                                                    t1060742.ec_nm IS NULL
                                                THEN t1060742.ec_work_email_adr_txt
                                                ELSE
                                                CASE
                                                    WHEN NOT
                                                        t1060742.ceo_nm IS NULL
                                                    THEN t1060742.ceo_work_email_adr_txt
                                                    ELSE NULL
                                                END
                                            END
                                        END
                                    END
                                END
                            END
                        END
                    END
                END
            END
        END
    END
    AS c94
FROM
    phrdw.dt_dim t1215969 /* Dim_DT_DIM_Position_Entry */,
    phrdw.actn_dim t1060720 /* Dim_ACTN_DIM */,
    phrdw.job_dim t1060723 /* Dim_JOB_DIM */,
    phrdw.dt_dim t1060745 /* Dim_DT_DIM_Service */,
    phrdw.dt_dim t1060758 /* Dim_DT_DIM_Department_Entry */,
    phrdw.rpts_to_dim t1060742 /* Dim_RPTS_TO_DIM */,
    phrdw.dt_dim t1060732 /* Dim_DT_DIM_Job_Entry */,
    phrdw.dt_dim t1060729 /* Dim_DT_DIM_Filter */,
    phrdw.loc_dim t1060763 /* Dim_LOC_DIM */,
    phrdw.dt_dim t1060755 /* Dim_DT_DIM_Last_Appraisal */,
    phrdw_secured.emp_dim t1060728 /* Dim_EMP_DIM */,
    phrdw.dt_dim t1060738 /* Dim_DT_DIM_Termination */,
    phrdw.dt_dim t1060744 /* Dim_DT_DIM_Original_Hire */,
    phrdw.dept_dim t1060752 /* Dim_DEPT_DIM */,
    phrdw.dt_dim t1060727 /* Dim_DT_DIM_Last_Hire */,
    phrdw.dt_dim t1060757 /* Dim_DT_DIM_Action */,
    phrdw.dt_dim t1060762 /* Dim_DT_DIM_Effective_Date */,
    phrdw.dt_dim t1060769 /* Dim_DT_DIM_Expected_Return */,
    phrdw_secured.emp_evt_fact t1060764 /* Fact_EMP_EVT_FACT */
WHERE
    (
            t1060720.actn_dim_id = t1060764.actn_dim_id
        AND
            t1060723.job_dim_id = t1060764.job_dim_id
        AND
            t1060742.rpts_to_dim_id = t1060764.rpts_to_dim_id
        AND
            t1060732.dt_dim_id = nvl(
                t1060764.job_entry_dt_dim_id,
                0
            )
        AND
            t1060729.dt_dim_id = t1060764.filter_dt_dim_id
        AND
            t1060745.dt_dim_id = t1060764.service_dt_dim_id
        AND
            t1060755.dt_dim_id = t1060764.last_aprsl_dt_dim_id
        AND
            t1060728.emp_dim_id = t1060764.emp_dim_id
        AND
            t1060738.dt_dim_id = t1060764.term_dt_dim_id
        AND
            t1060744.dt_dim_id = t1060764.orig_hire_dt_dim_id
        AND
            t1060752.dept_dim_id = t1060764.dept_dim_id
        AND
            t1060727.dt_dim_id = t1060764.last_hire_dt_dim_id
        AND
            t1060757.dt_dim_id = t1060764.actn_dt_dim_id
        AND
            t1060758.dt_dim_id = nvl(
                t1060764.dept_entry_dt_dim_id,
                0
            )
        AND
            t1060762.dt_dim_id = t1060764.eff_dt_dim_id
        AND
            t1060763.loc_dim_id = t1060764.loc_dim_id
        AND
            t1060764.expctd_return_dt_dim_id = t1060769.dt_dim_id
        AND
            t1060764.pos_entry_dt_dim_id = t1215969.dt_dim_id AND `;

  personal = `select distinct
   T1060757.FULL_DT as c1,
   T1060758.FULL_DT as c2,
   T1060752.DEPT_ID as c3,
   T1060752.DEPT_NM as c4,
   T1060752.FINC_LVL_1_DESC as c5,
   T1060752.FINC_LVL_10_DESC as c6,
   T1060752.FINC_LVL_11_DESC as c7,
   T1060752.FINC_LVL_12_DESC as c8,
   T1060752.FINC_LVL_13_DESC as c9,
   T1060752.FINC_LVL_14_DESC as c10,
   T1060752.FINC_LVL_15_DESC as c11,
   T1060752.FINC_LVL_2_DESC as c12,
   T1060752.FINC_LVL_3_DESC as c13,
   T1060752.FINC_LVL_4_DESC as c14,
   T1060752.FINC_LVL_5_DESC as c15,
   T1060752.FINC_LVL_6_DESC as c16,
   T1060752.FINC_LVL_7_DESC as c17,
   T1060752.FINC_LVL_8_DESC as c18,
   T1060752.FINC_LVL_9_DESC as c19,
   T1060762.FULL_DT as c20,
   T1060764.ACQN_CMPY_NM as c21,
   T1060764.ACQN_IND as c22,
   T1060764.ACQN_LEGAL_DAY_1_DT as c23,
   case
    when T1060720.ACTN_CATG_DESC in ('Contract Contingent Worker',
        'Hire', 'Hire Employee')
    then 'Hire'
    when T1060720.ACTN_CATG_DESC in ('Change Job', 'Job/Grade Change')
    then 'Job/Grade Change'
    when T1060720.ACTN_CATG_DESC in ('Leave', 'Leave of Absence')
    then 'Leave of Absence'
    when T1060720.ACTN_CATG_DESC in ('One-Time Payment', 'Pay Rate Change',
        'Request Compensation Change')
    then 'Pay Rate Change'
    when T1060720.ACTN_CATG_DESC in ('Add Retiree Status',
        'End Contingent Worker Contract', 'Terminate Employee', 'Termination')
    then 'Termination'
    when T1060720.ACTN_CATG_DESC in ('Change Organization Assignments for Worker',
        'End International Assignment', 'Transfer', 'Transfer Contingent Worker')
    then 'Transfer'
    when T1060720.ACTN_CATG_DESC in ('Close Position or Headcount',
        'Create Position', 'Edit Position', 'End Additional Employee Job',
        'Freeze Position, Headcount, or Job Group', 'Move to New Manager',
        'Profile Change', 'Remove Retiree Status',
        'Start International Assignment', 'Statutory Compensation Statement')
    then 'Profile Change'
    else T1060720.ACTN_CATG_DESC
   end  as c24,
   T1060720.ACTN_CD as c25,
   T1060720.ACTN_REAS_CD as c26,
   T1060720.ACTN_REAS_DESC as c27,
   T1060720.ACTN_DESC as c28,
   T1060764.ASSOC_TYPE_DESC as c29,
   T1060764.BUS_UNIT_CD as c30,
   T1060764.BUS_UNIT_NM as c31,
   T1060764.CMPY_CD as c32,
   T1060764.CMPY_NM as c33,
   T1060764.EMP_CLASS_DESC as c34,
   T1060764.EMP_STATUS_CD as c35,
   case
    when T1060764.EMP_STATUS_DESC in ('Leave', 'Leave With Pay',
        'Leave of Absence')
    then 'Leave of Absence'
    else T1060764.EMP_STATUS_DESC
   end  as c36,
   T1060764.EMP_TYPE_DESC as c37,
   T1060764.EXTRNL_HIRE_IND as c38,
   T1060764.FTE_NUM as c39,
   T1060764.FULL_PART_TM_CD as c40,
   T1060764.INTERNAL_ZIP_ID as c41,
   T1060764.INVOL_ATRTN_IND as c42,
   T1060764.PROMO_IND as c43,
   T1060764.REMOTE_WORKER_IND as c44,
   T1060764.SEQ_NUM as c45,
   T1060764.TRFR_IND as c46,
   T1060764.VOL_ATRTN_IND as c47,
   case
    when
    case
      when
        TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99')
        > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
        or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
        and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
    end  < 25
    then 'Under 25'
    when
    case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99')
        > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
        or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
        and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
    end  between 25 and 34
    then '25 to 34'
    when
    case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99')
      > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
    end  between 35 and 44
    then '35 to 44'
    when
    case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99')
      > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
    end  between 45 and 54
    then '45 to 54'
    when
    case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99')
      > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:10:58' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
    end  > 55
    then '55 and over'
   else 'Unspecified' end  as c48,
   T1060728.ALT_EMP_ID as c49,
   T1060728.BRTH_DT as c50,
   T1060728.BRTH_MMDD_DT as c51,
   T1060728.EMP_ID as c52,
   T1060728.ENT_USER_ID as c53,
   T1060728.FRST_NM as c54,
   T1060728.FULL_NM as c55,
   T1060728.HOME_ADR_LINE_1_TXT as c56,
   T1060728.HOME_ADR_LINE_2_TXT as c57,
   T1060728.HOME_ADR_LINE_3_TXT as c58,
   T1060728.HOME_ADR_LINE_4_TXT as c59,
   T1060728.HOME_CITY_NM as c60,
   T1060728.HOME_CNTRY_NM as c61,
   T1060728.HOME_ST_CD as c62,
   T1060728.HOME_ZIP_CD as c63,
   T1060728.LAST_NM as c64,
   T1060728.MID_NM as c65,
   T1060728.PRFX_NM as c66,
   T1060728.WORK_EMAIL_ADR_TXT as c67,
   T1060769.FULL_DT as c68,
   T1060732.FULL_DT as c69,
   T1060723.FLSA_STAT_DESC as c70,
   T1060723.JOB_CD as c71,
   T1060723.JOB_FMLY_DESC as c72,
   T1060723.JOB_LVL_CD as c73,
   T1060723.JOB_LVL_DESC as c74,
   T1060723.JOB_DESC as c75,
   T1060727.FULL_DT as c76,
   T1060763.LOC_CD as c77,
   T1060763.LOC_NM as c78,
   T1060763.WORK_CITY_NM as c79,
   T1060763.WORK_CNTRY_NM as c80,
   T1060763.WORK_ST_CD as c81,
   T1060763.WORK_ZIP_CD as c82,
   T1060744.FULL_DT as c83,
   T1215969.FULL_DT as c84,
   T1060742.EC_NM as c85,
   T1060742.EC1_NM as c86,
   T1060742.EC2_NM as c87,
   T1060742.EC3_NM as c88,
   T1060742.EC4_NM as c89,
   T1060742.EC5_NM as c90,
   T1060742.EC6_NM as c91,
   T1060742.EC7_NM as c92,
   T1060742.EC8_NM as c93,
   T1060742.EC9_NM as c94,
   T1060745.FULL_DT as c95,
   T1060738.FULL_DT as c96,
   case
    when T1060764.ACTUAL_LAST_DAY_OF_LEAVE is null
    then NULL
    else T1060764.ACTUAL_LAST_DAY_OF_LEAVE
   end  as c97,
   case
    when T1060764.LAST_DAY_OF_WORK is null
    then NULL else T1060764.LAST_DAY_OF_WORK
   end  as c98,
   case
    when not T1060742.EC10_NM is null
    then T1060742.EC10_ID
    else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_ID
      else case
        when not T1060742.EC8_NM is null
        then T1060742.EC8_ID
        else case
          when not T1060742.EC7_NM is null
          then T1060742.EC7_ID
          else case
            when not T1060742.EC6_NM is null
            then T1060742.EC6_ID
            else case
              when not T1060742.EC5_NM is null
              then T1060742.EC5_ID
              else case
                when not T1060742.EC4_NM is null
                then T1060742.EC4_ID
                else case
                  when not T1060742.EC3_NM is null
                  then T1060742.EC3_ID
                  else case
                    when not T1060742.EC2_NM is null
                    then T1060742.EC2_ID
                    else case
                      when not T1060742.EC1_NM is null
                      then T1060742.EC1_ID
                      else case
                        when not T1060742.EC_NM is null
                        then T1060742.EC_ID
                        else case
                          when not T1060742.CEO_NM is null
                          then T1060742.CEO_ID
                          else NULL
                        end
                      end
                    end  end  end  end  end  end  end  end  end  end  as c99,
   case
   when not T1060742.EC10_NM is null
   then T1060742.EC10_NM
   else case
    when not T1060742.EC9_NM is null
    then T1060742.EC9_NM
    else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_NM
        else case
        when not T1060742.EC7_NM is null
        then T1060742.EC7_NM
        else case
          when not T1060742.EC6_NM is null
          then T1060742.EC6_NM
          else case
            when not T1060742.EC5_NM is null
            then T1060742.EC5_NM
            else case
              when not T1060742.EC4_NM is null
              then T1060742.EC4_NM
              else case
                when not T1060742.EC3_NM is null
                then T1060742.EC3_NM
                else case
                  when not T1060742.EC2_NM is null
                  then T1060742.EC2_NM
                  else case
                    when not T1060742.EC1_NM is null
                    then T1060742.EC1_NM
                    else case
                      when not T1060742.EC_NM is null
                      then T1060742.EC_NM
                      else case
                        when not T1060742.CEO_NM is null
                        then T1060742.CEO_NM
                        else NULL
                      end
                    end
                  end
                end  end  end  end  end  end  end  end  end  as c100,
   case
    when not T1060742.EC10_NM is null
    then T1060742.EC10_WORK_EMAIL_ADR_TXT
    else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_WORK_EMAIL_ADR_TXT
      else case
        when not T1060742.EC8_NM is null
        then T1060742.EC8_WORK_EMAIL_ADR_TXT
        else case
          when not T1060742.EC7_NM is null
          then T1060742.EC7_WORK_EMAIL_ADR_TXT
          else case
            when not T1060742.EC6_NM is null
            then T1060742.EC6_WORK_EMAIL_ADR_TXT
            else case
              when not T1060742.EC5_NM is null
              then T1060742.EC5_WORK_EMAIL_ADR_TXT
              else case
                when not T1060742.EC4_NM is null
                then T1060742.EC4_WORK_EMAIL_ADR_TXT
                else case
                  when not T1060742.EC3_NM is null
                  then T1060742.EC3_WORK_EMAIL_ADR_TXT
                  else case
                    when not T1060742.EC2_NM is null
                    then T1060742.EC2_WORK_EMAIL_ADR_TXT
                    else case
                      when not T1060742.EC1_NM is null
                      then T1060742.EC1_WORK_EMAIL_ADR_TXT
                      else case
                        when not T1060742.EC_NM is null
                        then T1060742.EC_WORK_EMAIL_ADR_TXT
                        else case
                          when not T1060742.CEO_NM is null
                          then T1060742.CEO_WORK_EMAIL_ADR_TXT
                          else NULL
                        end
                      end
                    end  end  end  end  end  end  end  end  end  end  as c101
from
     phrdw.DT_DIM T1215969 /* Dim_DT_DIM_Position_Entry */ ,
     phrdw.ACTN_DIM T1060720 /* Dim_ACTN_DIM */ ,
     phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ ,
     phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ ,
     phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ ,
     phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ ,
     phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ ,
     phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ ,
     phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ ,
     phrdw_secured.EMP_DIM T1060728 /* Dim_EMP_DIM */ ,
     phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ ,
     phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ ,
     phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ ,
     phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ ,
     phrdw.DT_DIM T1060757 /* Dim_DT_DIM_Action */ ,
     phrdw.DT_DIM T1060762 /* Dim_DT_DIM_Effective_Date */ ,
     phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ ,
     phrdw_secured.EMP_EVT_FACT T1060764 /* Fact_EMP_EVT_FACT */
where  (
  T1060720.ACTN_DIM_ID = T1060764.ACTN_DIM_ID and
  T1060723.JOB_DIM_ID = T1060764.JOB_DIM_ID and
  T1060742.RPTS_TO_DIM_ID = T1060764.RPTS_TO_DIM_ID and
  T1060732.DT_DIM_ID = nvl(T1060764.JOB_ENTRY_DT_DIM_ID , 0) and
  T1060729.DT_DIM_ID = T1060764.FILTER_DT_DIM_ID and
  T1060745.DT_DIM_ID = T1060764.SERVICE_DT_DIM_ID and
  T1060728.EMP_DIM_ID = T1060764.EMP_DIM_ID and
  T1060738.DT_DIM_ID = T1060764.TERM_DT_DIM_ID and
  T1060744.DT_DIM_ID = T1060764.ORIG_HIRE_DT_DIM_ID and
  T1060752.DEPT_DIM_ID = T1060764.DEPT_DIM_ID and
  T1060727.DT_DIM_ID = T1060764.LAST_HIRE_DT_DIM_ID and
  T1060757.DT_DIM_ID = T1060764.ACTN_DT_DIM_ID and
  T1060758.DT_DIM_ID = nvl(T1060764.DEPT_ENTRY_DT_DIM_ID , 0) and
  T1060762.DT_DIM_ID = T1060764.EFF_DT_DIM_ID and
  T1060763.LOC_DIM_ID = T1060764.LOC_DIM_ID and
  T1060764.EXPCTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and
  T1060764.POS_ENTRY_DT_DIM_ID = T1215969.DT_DIM_ID and `;

  compensation = `select distinct T1060757.FULL_DT as c1,
     T1060758.FULL_DT as c2,
     T1060752.DEPT_ID as c3,
     T1060752.DEPT_NM as c4,
     T1060752.FINC_LVL_1_DESC as c5,
     T1060752.FINC_LVL_10_DESC as c6,
     T1060752.FINC_LVL_11_DESC as c7,
     T1060752.FINC_LVL_12_DESC as c8,
     T1060752.FINC_LVL_13_DESC as c9,
     T1060752.FINC_LVL_14_DESC as c10,
     T1060752.FINC_LVL_15_DESC as c11,
     T1060752.FINC_LVL_2_DESC as c12,
     T1060752.FINC_LVL_3_DESC as c13,
     T1060752.FINC_LVL_4_DESC as c14,
     T1060752.FINC_LVL_5_DESC as c15,
     T1060752.FINC_LVL_6_DESC as c16,
     T1060752.FINC_LVL_7_DESC as c17,
     T1060752.FINC_LVL_8_DESC as c18,
     T1060752.FINC_LVL_9_DESC as c19,
     T1060762.FULL_DT as c20,
     T1060764.ACQN_CMPY_NM as c21,
     T1060764.ACQN_IND as c22,
     T1060764.ACQN_LEGAL_DAY_1_DT as c23,
     case  when T1060720.ACTN_CATG_DESC in ('Contract Contingent Worker', 'Hire', 'Hire Employee')
     then 'Hire' when T1060720.ACTN_CATG_DESC in ('Change Job', 'Job/Grade Change')
     then 'Job/Grade Change' when T1060720.ACTN_CATG_DESC in ('Leave', 'Leave of Absence')
     then 'Leave of Absence' when T1060720.ACTN_CATG_DESC in ('One-Time Payment', 'Pay Rate Change', 'Request Compensation Change')
     then 'Pay Rate Change' when T1060720.ACTN_CATG_DESC in ('Add Retiree Status', 'End Contingent Worker Contract', 'Terminate Employee', 'Termination')
     then 'Termination' when T1060720.ACTN_CATG_DESC in ('Change Organization Assignments for Worker', 'End International Assignment', 'Transfer', 'Transfer Contingent Worker')
     then 'Transfer' when T1060720.ACTN_CATG_DESC in ('Close Position or Headcount', 'Create Position', 'Edit Position', 'End Additional Employee Job',
     'Freeze Position, Headcount, or Job Group', 'Move to New Manager', 'Profile Change', 'Remove Retiree Status', 'Start International Assignment',
     'Statutory Compensation Statement') then 'Profile Change' else T1060720.ACTN_CATG_DESC end  as c24,
     T1060720.ACTN_CD as c25,
     T1060720.ACTN_REAS_CD as c26,
     T1060720.ACTN_REAS_DESC as c27,
     T1060720.ACTN_DESC as c28,
     case
     when T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources')
     then NULL else T1060764.ANUL_SAL_AMT end  as c29,
     T1060764.ASSOC_TYPE_DESC as c30,
     T1060764.BUS_UNIT_CD as c31,
     T1060764.BUS_UNIT_NM as c32,
     T1060764.CMPY_CD as c33,
     T1060764.CMPY_NM as c34,
     T1060764.EMP_CLASS_DESC as c35,
     T1060764.EMP_STATUS_CD as c36,
     case
     when T1060764.EMP_STATUS_DESC in ('Leave', 'Leave With Pay', 'Leave of Absence')
     then 'Leave of Absence' else T1060764.EMP_STATUS_DESC
     end  as c37,
     T1060764.EMP_TYPE_DESC as c38,
     T1060764.EXTRNL_HIRE_IND as c39,
     T1060764.FTE_NUM as c40,
     T1060764.FULL_PART_TM_CD as c41,
     T1060764.INTERNAL_ZIP_ID as c42,
     T1060764.INVOL_ATRTN_IND as c43,
     T1060764.PROMO_IND as c44,
     T1060764.REMOTE_WORKER_IND as c45,
     T1060764.SAL_GRADE_ID as c46,
     T1060764.SEQ_NUM as c47,
     T1060764.TRFR_IND as c48,
     T1060764.VOL_ATRTN_IND as c49,
     T1060728.ALT_EMP_ID as c50,
     T1060728.BRTH_MMDD_DT as c51,
     T1060728.EMP_ID as c52,
     T1060728.ENT_USER_ID as c53,
     T1060728.FRST_NM as c54,
     T1060728.FULL_NM as c55,
     T1060728.LAST_NM as c56,
     T1060728.MID_NM as c57,
     T1060728.PRFX_NM as c58,
     T1060728.WORK_EMAIL_ADR_TXT as c59,
     T1060769.FULL_DT as c60,
     T1060732.FULL_DT as c61,
     T1060723.FLSA_STAT_DESC as c62,
     T1060723.JOB_CD as c63,
     T1060723.JOB_FMLY_DESC as c64,
     T1060723.JOB_LVL_CD as c65,
     T1060723.JOB_LVL_DESC as c66,
     T1060723.JOB_DESC as c67,
     T1060727.FULL_DT as c68,
     T1060763.LOC_CD as c69,
     T1060763.LOC_NM as c70,
     T1060763.WORK_CITY_NM as c71,
     T1060763.WORK_CNTRY_NM as c72,
     T1060763.WORK_ST_CD as c73,
     T1060763.WORK_ZIP_CD as c74,
     T1060744.FULL_DT as c75,
     T1215969.FULL_DT as c76,
     T1060742.EC_NM as c77,
     T1060742.EC1_NM as c78,
     T1060742.EC2_NM as c79,
     T1060742.EC3_NM as c80,
     T1060742.EC4_NM as c81,
     T1060742.EC5_NM as c82,
     T1060742.EC6_NM as c83,
     T1060742.EC7_NM as c84,
     T1060742.EC8_NM as c85,
     T1060742.EC9_NM as c86,
     T1060745.FULL_DT as c87,
     T1060738.FULL_DT as c88,
     case  when T1060764.ACTUAL_LAST_DAY_OF_LEAVE is null then NULL else T1060764.ACTUAL_LAST_DAY_OF_LEAVE end  as c89,
     case  when T1060764.LAST_DAY_OF_WORK is null then NULL else T1060764.LAST_DAY_OF_WORK end  as c90,
     case
       when not T1060742.EC10_NM is null
       then T1060742.EC10_ID else case
       when not T1060742.EC9_NM is null
       then T1060742.EC9_ID else case
       when not T1060742.EC8_NM is null
       then T1060742.EC8_ID else case
       when not T1060742.EC7_NM is null
       then T1060742.EC7_ID else case
       when not T1060742.EC6_NM is null
       then T1060742.EC6_ID else case
       when not T1060742.EC5_NM is null
       then T1060742.EC5_ID else case
       when not T1060742.EC4_NM is null
       then T1060742.EC4_ID else case
       when not T1060742.EC3_NM is null
       then T1060742.EC3_ID else case
       when not T1060742.EC2_NM is null
       then T1060742.EC2_ID else case
       when not T1060742.EC1_NM is null
       then T1060742.EC1_ID else case
       when not T1060742.EC_NM is null
       then T1060742.EC_ID else case
       when not T1060742.CEO_NM is null
       then T1060742.CEO_ID
       else NULL
       end  end  end  end  end  end  end  end  end  end  end  end  as c91,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_NM else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_NM else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_NM else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_NM else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_NM else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_NM else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_NM else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_NM else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_NM else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_NM else case
      when not T1060742.EC_NM is null
      then T1060742.EC_NM else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_NM
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c92,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC_NM is null
      then T1060742.EC_WORK_EMAIL_ADR_TXT else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_WORK_EMAIL_ADR_TXT
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c93
from
     phrdw.DT_DIM T1215969 /* Dim_DT_DIM_Position_Entry */ ,
     phrdw.ACTN_DIM T1060720 /* Dim_ACTN_DIM */ ,
     phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ ,
     phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ ,
     phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ ,
     phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ ,
     phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ ,
     phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ ,
     phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ ,
     phrdw_secured.EMP_DIM T1060728 /* Dim_EMP_DIM */ ,
     phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ ,
     phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ ,
     phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ ,
     phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ ,
     phrdw.DT_DIM T1060757 /* Dim_DT_DIM_Action */ ,
     phrdw.DT_DIM T1060762 /* Dim_DT_DIM_Effective_Date */ ,
     phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ ,
     phrdw_secured.EMP_EVT_FACT T1060764 /* Fact_EMP_EVT_FACT */
where  ( T1060720.ACTN_DIM_ID = T1060764.ACTN_DIM_ID and
  T1060723.JOB_DIM_ID = T1060764.JOB_DIM_ID and
  T1060742.RPTS_TO_DIM_ID = T1060764.RPTS_TO_DIM_ID and
  T1060732.DT_DIM_ID = nvl(T1060764.JOB_ENTRY_DT_DIM_ID , 0) and
  T1060729.DT_DIM_ID = T1060764.FILTER_DT_DIM_ID and
  T1060745.DT_DIM_ID = T1060764.SERVICE_DT_DIM_ID and
  T1060728.EMP_DIM_ID = T1060764.EMP_DIM_ID and
  T1060738.DT_DIM_ID = T1060764.TERM_DT_DIM_ID and
  T1060744.DT_DIM_ID = T1060764.ORIG_HIRE_DT_DIM_ID and
  T1060752.DEPT_DIM_ID = T1060764.DEPT_DIM_ID and
  T1060727.DT_DIM_ID = T1060764.LAST_HIRE_DT_DIM_ID and
  T1060757.DT_DIM_ID = T1060764.ACTN_DT_DIM_ID and
  T1060758.DT_DIM_ID = nvl(T1060764.DEPT_ENTRY_DT_DIM_ID , 0) and
  T1060762.DT_DIM_ID = T1060764.EFF_DT_DIM_ID and
  T1060764.EXPCTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and
  T1060764.POS_ENTRY_DT_DIM_ID = T1215969.DT_DIM_ID and `;

  diversity = `select distinct T1060757.FULL_DT as c1,
     T1060758.FULL_DT as c2,
     T1060752.DEPT_ID as c3,
     T1060752.DEPT_NM as c4,
     T1060752.FINC_LVL_1_DESC as c5,
     T1060752.FINC_LVL_10_DESC as c6,
     T1060752.FINC_LVL_11_DESC as c7,
     T1060752.FINC_LVL_12_DESC as c8,
     T1060752.FINC_LVL_13_DESC as c9,
     T1060752.FINC_LVL_14_DESC as c10,
     T1060752.FINC_LVL_15_DESC as c11,
     T1060752.FINC_LVL_2_DESC as c12,
     T1060752.FINC_LVL_3_DESC as c13,
     T1060752.FINC_LVL_4_DESC as c14,
     T1060752.FINC_LVL_5_DESC as c15,
     T1060752.FINC_LVL_6_DESC as c16,
     T1060752.FINC_LVL_7_DESC as c17,
     T1060752.FINC_LVL_8_DESC as c18,
     T1060752.FINC_LVL_9_DESC as c19,
     T1060762.FULL_DT as c20,
     T1060764.ACQN_CMPY_NM as c21,
     T1060764.ACQN_IND as c22,
     T1060764.ACQN_LEGAL_DAY_1_DT as c23,
     case
      when T1060720.ACTN_CATG_DESC in ('Contract Contingent Worker', 'Hire', 'Hire Employee')
      then 'Hire'
      when T1060720.ACTN_CATG_DESC in ('Change Job', 'Job/Grade Change')
      then 'Job/Grade Change'
      when T1060720.ACTN_CATG_DESC in ('Leave', 'Leave of Absence')
      then 'Leave of Absence'
      when T1060720.ACTN_CATG_DESC in ('One-Time Payment', 'Pay Rate Change', 'Request Compensation Change')
      then 'Pay Rate Change'
      when T1060720.ACTN_CATG_DESC in ('Add Retiree Status', 'End Contingent Worker Contract', 'Terminate Employee', 'Termination')
      then 'Termination'
      when T1060720.ACTN_CATG_DESC in ('Change Organization Assignments for Worker', 'End International Assignment', 'Transfer', 'Transfer Contingent Worker')
      then 'Transfer'
      when T1060720.ACTN_CATG_DESC in ('Close Position or Headcount', 'Create Position', 'Edit Position', 'End Additional Employee Job',
      'Freeze Position, Headcount, or Job Group', 'Move to New Manager', 'Profile Change', 'Remove Retiree Status',
      'Start International Assignment', 'Statutory Compensation Statement')
      then 'Profile Change'
      else T1060720.ACTN_CATG_DESC
      end  as c24,
     T1060720.ACTN_CD as c25,
     T1060720.ACTN_REAS_CD as c26,
     T1060720.ACTN_REAS_DESC as c27,
     T1060720.ACTN_DESC as c28,
     T1060764.ASSOC_TYPE_DESC as c29,
     T1060764.BUS_UNIT_CD as c30,
     T1060764.BUS_UNIT_NM as c31,
     T1060764.CMPY_CD as c32,
     T1060764.CMPY_NM as c33,
     T1060764.EMP_CLASS_DESC as c34,
     T1060764.EMP_STATUS_CD as c35,
     case
     when T1060764.EMP_STATUS_DESC in ('Leave', 'Leave With Pay', 'Leave of Absence')
     then 'Leave of Absence'
     else T1060764.EMP_STATUS_DESC end  as c36,
     T1060764.EMP_TYPE_DESC as c37,
     T1060764.EXTRNL_HIRE_IND as c38,
     T1060764.FTE_NUM as c39,
     T1060764.FULL_PART_TM_CD as c40,
     T1060764.INTERNAL_ZIP_ID as c41,
     T1060764.INVOL_ATRTN_IND as c42,
     T1060764.PROMO_IND as c43,
     T1060764.REMOTE_WORKER_IND as c44,
     T1060764.SEQ_NUM as c45,
     T1060764.TRFR_IND as c46,
     T1060764.VOL_ATRTN_IND as c47,
     case
     when case
     when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
     then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
     else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
     end  < 25
     then 'Under 25'
     when case  when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
     then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
     else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
     end  between 25 and 34
     then '25 to 34'
     when case
     when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
     then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
     else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
     end  between 35 and 44
     then '35 to 44'
     when case
     when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
     then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
     else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
     end  between 45 and 54 then '45 to 54'
     when case  when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
     and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
     then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
     else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:54:26' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
     end  > 55 then '55 and over'
     else 'Unspecified' end  as c48,
     T1060728.ALT_EMP_ID as c49,
     T1060728.BRTH_DT as c50,
     T1060728.BRTH_MMDD_DT as c51,
     T1060728.CNDA_ABORIG_IND as c52,
     T1060728.CNDA_VSBL_MNORT_IND as c53,
     T1060728.DSABLD_IND as c54,
     T1060728.EMP_ID as c55,
     T1060728.ETHNIC_GRP_DESC as c56,
     T1060728.ENT_USER_ID as c57,
     T1060728.FRST_NM as c58,
     T1060728.FULL_NM as c59,
     T1060728.GNDR_DESC as c60,
     T1060728.LAST_NM as c61,
     T1060728.MID_NM as c62,
     T1060728.MIL_DSCHRG_DT as c63,
     T1060728.MIL_STAT_DESC as c64,
     T1060728.PERS_OF_COLOR_IND as c65,
     T1060728.PRFX_NM as c66,
     T1060728.UK_ETHNIC_GRP_DESC as c67,
     T1060728.WORK_EMAIL_ADR_TXT as c68,
     T1060769.FULL_DT as c69,
     T1060732.FULL_DT as c70,
     T1060723.FLSA_STAT_DESC as c71,
     T1060723.JOB_CD as c72,
     T1060723.JOB_FMLY_DESC as c73,
     T1060723.JOB_LVL_CD as c74,
     T1060723.JOB_LVL_DESC as c75,
     T1060723.JOB_DESC as c76,
     T1060727.FULL_DT as c77,
     T1060763.LOC_CD as c78,
     T1060763.LOC_NM as c79,
     T1060763.WORK_CITY_NM as c80,
     T1060763.WORK_CNTRY_NM as c81,
     T1060763.WORK_ST_CD as c82,
     T1060763.WORK_ZIP_CD as c83,
     T1060744.FULL_DT as c84,
     T1215969.FULL_DT as c85,
     T1060742.EC_NM as c86,
     T1060742.EC1_NM as c87,
     T1060742.EC2_NM as c88,
     T1060742.EC3_NM as c89,
     T1060742.EC4_NM as c90,
     T1060742.EC5_NM as c91,
     T1060742.EC6_NM as c92,
     T1060742.EC7_NM as c93,
     T1060742.EC8_NM as c94,
     T1060742.EC9_NM as c95,
     T1060745.FULL_DT as c96,
     T1060738.FULL_DT as c97,
     case
      when T1060764.ACTUAL_LAST_DAY_OF_LEAVE is null
      then NULL
      else T1060764.ACTUAL_LAST_DAY_OF_LEAVE
     end  as c98,
     case
      when T1060764.LAST_DAY_OF_WORK is null
      then NULL else T1060764.LAST_DAY_OF_WORK
     end  as c99,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_ID else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_ID else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_ID else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_ID else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_ID else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_ID else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_ID else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_ID else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_ID else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_ID else case
      when not T1060742.EC_NM is null
      then T1060742.EC_ID else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_ID
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c100,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_NM else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_NM else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_NM else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_NM else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_NM else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_NM else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_NM else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_NM else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_NM else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_NM else case
      when not T1060742.EC_NM is null
      then T1060742.EC_NM else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_NM
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c101,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC_NM is null
      then T1060742.EC_WORK_EMAIL_ADR_TXT else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_WORK_EMAIL_ADR_TXT
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c102
from
     phrdw.DT_DIM T1215969 /* Dim_DT_DIM_Position_Entry */ ,
     phrdw.ACTN_DIM T1060720 /* Dim_ACTN_DIM */ ,
     phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ ,
     phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ ,
     phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ ,
     phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ ,
     phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ ,
     phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ ,
     phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ ,
     phrdw_secured.EMP_DIM T1060728 /* Dim_EMP_DIM */ ,
     phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ ,
     phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ ,
     phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ ,
     phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ ,
     phrdw.DT_DIM T1060757 /* Dim_DT_DIM_Action */ ,
     phrdw.DT_DIM T1060762 /* Dim_DT_DIM_Effective_Date */ ,
     phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ ,
     phrdw_secured.EMP_EVT_FACT T1060764 /* Fact_EMP_EVT_FACT */
where  ( T1060720.ACTN_DIM_ID = T1060764.ACTN_DIM_ID and
  T1060723.JOB_DIM_ID = T1060764.JOB_DIM_ID and
  T1060742.RPTS_TO_DIM_ID = T1060764.RPTS_TO_DIM_ID and
  T1060732.DT_DIM_ID = nvl(T1060764.JOB_ENTRY_DT_DIM_ID , 0) and
  T1060729.DT_DIM_ID = T1060764.FILTER_DT_DIM_ID and
  T1060745.DT_DIM_ID = T1060764.SERVICE_DT_DIM_ID and
  T1060728.EMP_DIM_ID = T1060764.EMP_DIM_ID and
  T1060738.DT_DIM_ID = T1060764.TERM_DT_DIM_ID and
  T1060744.DT_DIM_ID = T1060764.ORIG_HIRE_DT_DIM_ID and
  T1060752.DEPT_DIM_ID = T1060764.DEPT_DIM_ID and
  T1060727.DT_DIM_ID = T1060764.LAST_HIRE_DT_DIM_ID and
  T1060757.DT_DIM_ID = T1060764.ACTN_DT_DIM_ID and
  T1060758.DT_DIM_ID = nvl(T1060764.DEPT_ENTRY_DT_DIM_ID , 0) and
  T1060762.DT_DIM_ID = T1060764.EFF_DT_DIM_ID and
  T1060763.LOC_DIM_ID = T1060764.LOC_DIM_ID and
  T1060764.EXPCTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and
  T1060764.POS_ENTRY_DT_DIM_ID = T1215969.DT_DIM_ID and `;

  all = `select distinct T1060757.FULL_DT as c1,
     T1060758.FULL_DT as c2,
     T1060752.DEPT_ID as c3,
     T1060752.DEPT_NM as c4,
     T1060752.FINC_LVL_1_DESC as c5,
     T1060752.FINC_LVL_10_DESC as c6,
     T1060752.FINC_LVL_11_DESC as c7,
     T1060752.FINC_LVL_12_DESC as c8,
     T1060752.FINC_LVL_13_DESC as c9,
     T1060752.FINC_LVL_14_DESC as c10,
     T1060752.FINC_LVL_15_DESC as c11,
     T1060752.FINC_LVL_2_DESC as c12,
     T1060752.FINC_LVL_3_DESC as c13,
     T1060752.FINC_LVL_4_DESC as c14,
     T1060752.FINC_LVL_5_DESC as c15,
     T1060752.FINC_LVL_6_DESC as c16,
     T1060752.FINC_LVL_7_DESC as c17,
     T1060752.FINC_LVL_8_DESC as c18,
     T1060752.FINC_LVL_9_DESC as c19,
     T1060762.FULL_DT as c20,
     T1060764.ACQN_CMPY_NM as c21,
     T1060764.ACQN_IND as c22,
     T1060764.ACQN_LEGAL_DAY_1_DT as c23,
     case
      when T1060720.ACTN_CATG_DESC in ('Contract Contingent Worker', 'Hire', 'Hire Employee')
      then 'Hire'
      when T1060720.ACTN_CATG_DESC in ('Change Job', 'Job/Grade Change')
      then 'Job/Grade Change'
      when T1060720.ACTN_CATG_DESC in ('Leave', 'Leave of Absence')
      then 'Leave of Absence'
      when T1060720.ACTN_CATG_DESC in ('One-Time Payment', 'Pay Rate Change', 'Request Compensation Change')
      then 'Pay Rate Change'
      when T1060720.ACTN_CATG_DESC in ('Add Retiree Status', 'End Contingent Worker Contract', 'Terminate Employee', 'Termination')
      then 'Termination'
      when T1060720.ACTN_CATG_DESC in ('Change Organization Assignments for Worker', 'End International Assignment', 'Transfer', 'Transfer Contingent Worker')
      then 'Transfer'
      when T1060720.ACTN_CATG_DESC in ('Close Position or Headcount', 'Create Position', 'Edit Position', 'End Additional Employee Job', 'Freeze Position, Headcount, or Job Group', 'Move to New Manager', 'Profile Change', 'Remove Retiree Status', 'Start International Assignment', 'Statutory Compensation Statement')
      then 'Profile Change'
      else T1060720.ACTN_CATG_DESC
     end  as c24,
     T1060720.ACTN_CD as c25,
     T1060720.ACTN_REAS_CD as c26,
     T1060720.ACTN_REAS_DESC as c27,
     T1060720.ACTN_DESC as c28,
     case
      when T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources')
      then NULL
      else T1060764.ANUL_SAL_AMT
      end  as c29,
     T1060764.ASSOC_TYPE_DESC as c30,
     T1060764.BUS_UNIT_CD as c31,
     T1060764.BUS_UNIT_NM as c32,
     T1060764.CMPY_CD as c33,
     T1060764.CMPY_NM as c34,
     T1060764.EMP_CLASS_DESC as c35,
     T1060764.EMP_STATUS_CD as c36,
     case
      when T1060764.EMP_STATUS_DESC in ('Leave', 'Leave With Pay', 'Leave of Absence')
      then 'Leave of Absence'
      else T1060764.EMP_STATUS_DESC
     end  as c37,
     T1060764.EMP_TYPE_DESC as c38,
     T1060764.EXTRNL_HIRE_IND as c39,
     T1060764.FTE_NUM as c40,
     T1060764.FULL_PART_TM_CD as c41,
     case
      when T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources')
      then NULL
      else T1060764.HIGH_PERFR_IND
     end  as c42,
     T1060764.INTERNAL_ZIP_ID as c43,
     T1060764.INVOL_ATRTN_IND as c44,
     case
      when T1060752.FINC_LVL_1_DESC in ('HR', 'HR & CRE', 'Human Resources')
      or TO_DATE('2017-10-23' , 'YYYY-MM-DD') between TO_DATE('2014-12-01' , 'YYYY-MM-DD')
      and TO_DATE('2015-02-11' , 'YYYY-MM-DD') then NULL else T1060764.LAST_APRSL_RATG_DESC
     end  as c45,
     T1060764.PROMO_IND as c46,
     T1060764.REMOTE_WORKER_IND as c47,
     T1060764.SAL_GRADE_ID as c48,
     T1060764.SEQ_NUM as c49,
     T1060764.TRFR_IND as c50,
     T1060764.VOL_ATRTN_IND as c51,
     case
      when case  when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
      end  < 25 then 'Under 25'
      when case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
      end  between 25 and 34
      then '25 to 34'
      when case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
      end  between 35 and 44
      then '35 to 44'
      when case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
      end  between 45 and 54
      then '45 to 54'
      when case
      when TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      or TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'MM'), '99') = TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'MM'), '99')
      and TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'dd'), '99') > TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'dd'), '99')
      then TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999') - 1
      else TO_NUMBER(TO_CHAR(TO_DATE('2017-10-23 07:56:12' , 'YYYY-MM-DD HH24:MI:SS'), 'yyyy'), '9999') - TO_NUMBER(TO_CHAR(T1060728.BRTH_DT, 'yyyy'), '9999')
      end  > 55 then '55 and over'
      else 'Unspecified' end  as c52,
     T1060728.ALT_EMP_ID as c53,
     T1060728.BRTH_DT as c54,
     T1060728.BRTH_MMDD_DT as c55,
     T1060728.CNDA_ABORIG_IND as c56,
     T1060728.CNDA_VSBL_MNORT_IND as c57,
     T1060728.DSABLD_IND as c58,
     T1060728.EMP_ID as c59,
     T1060728.ETHNIC_GRP_DESC as c60,
     T1060728.ENT_USER_ID as c61,
     T1060728.FRST_NM as c62,
     T1060728.FULL_NM as c63,
     T1060728.GNDR_DESC as c64,
     T1060728.HOME_ADR_LINE_1_TXT as c65,
     T1060728.HOME_ADR_LINE_2_TXT as c66,
     T1060728.HOME_ADR_LINE_3_TXT as c67,
     T1060728.HOME_ADR_LINE_4_TXT as c68,
     T1060728.HOME_CITY_NM as c69,
     T1060728.HOME_CNTRY_NM as c70,
     T1060728.HOME_ST_CD as c71,
     T1060728.HOME_ZIP_CD as c72,
     T1060728.LAST_NM as c73,
     T1060728.MID_NM as c74,
     T1060728.MIL_DSCHRG_DT as c75,
     T1060728.MIL_STAT_DESC as c76,
     T1060728.PERS_OF_COLOR_IND as c77,
     T1060728.PRFX_NM as c78,
     T1060728.UK_ETHNIC_GRP_DESC as c79,
     T1060728.WORK_EMAIL_ADR_TXT as c80,
     T1060769.FULL_DT as c81,
     T1060732.FULL_DT as c82,
     T1060723.FLSA_STAT_DESC as c83,
     T1060723.JOB_CD as c84,
     T1060723.JOB_FMLY_DESC as c85,
     T1060723.JOB_LVL_CD as c86,
     T1060723.JOB_LVL_DESC as c87,
     T1060723.JOB_DESC as c88,
     T1060755.FULL_DT as c89,
     T1060727.FULL_DT as c90,
     T1060763.LOC_CD as c91,
     T1060763.LOC_NM as c92,
     T1060763.WORK_CITY_NM as c93,
     T1060763.WORK_CNTRY_NM as c94,
     T1060763.WORK_ST_CD as c95,
     T1060763.WORK_ZIP_CD as c96,
     T1060744.FULL_DT as c97,
     T1215969.FULL_DT as c98,
     T1060742.EC_NM as c99,
     T1060742.EC1_NM as c100,
     T1060742.EC2_NM as c101,
     T1060742.EC3_NM as c102,
     T1060742.EC4_NM as c103,
     T1060742.EC5_NM as c104,
     T1060742.EC6_NM as c105,
     T1060742.EC7_NM as c106,
     T1060742.EC8_NM as c107,
     T1060742.EC9_NM as c108,
     T1060745.FULL_DT as c109,
     T1060738.FULL_DT as c110,
     case
      when T1060764.ACTUAL_LAST_DAY_OF_LEAVE is null
      then NULL else T1060764.ACTUAL_LAST_DAY_OF_LEAVE
     end  as c111,
     case
      when T1060764.LAST_DAY_OF_WORK is null
      then NULL else T1060764.LAST_DAY_OF_WORK
     end  as c112,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_ID else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_ID else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_ID else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_ID else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_ID else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_ID else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_ID else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_ID else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_ID else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_ID else case
      when not T1060742.EC_NM is null
      then T1060742.EC_ID else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_ID
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c113,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_NM else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_NM else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_NM else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_NM else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_NM else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_NM else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_NM else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_NM else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_NM else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_NM else case
      when not T1060742.EC_NM is null
      then T1060742.EC_NM else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_NM
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c114,
     case
      when not T1060742.EC10_NM is null
      then T1060742.EC10_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC9_NM is null
      then T1060742.EC9_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC8_NM is null
      then T1060742.EC8_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC7_NM is null
      then T1060742.EC7_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC6_NM is null
      then T1060742.EC6_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC5_NM is null
      then T1060742.EC5_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC4_NM is null
      then T1060742.EC4_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC3_NM is null
      then T1060742.EC3_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC2_NM is null
      then T1060742.EC2_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC1_NM is null
      then T1060742.EC1_WORK_EMAIL_ADR_TXT else case
      when not T1060742.EC_NM is null
      then T1060742.EC_WORK_EMAIL_ADR_TXT else case
      when not T1060742.CEO_NM is null
      then T1060742.CEO_WORK_EMAIL_ADR_TXT
      else NULL
      end  end  end  end  end  end  end  end  end  end  end  end  as c115
from
     phrdw.DT_DIM T1215969 /* Dim_DT_DIM_Position_Entry */ ,
     phrdw.ACTN_DIM T1060720 /* Dim_ACTN_DIM */ ,
     phrdw.JOB_DIM T1060723 /* Dim_JOB_DIM */ ,
     phrdw.DT_DIM T1060745 /* Dim_DT_DIM_Service */ ,
     phrdw.DT_DIM T1060758 /* Dim_DT_DIM_Department_Entry */ ,
     phrdw.RPTS_TO_DIM T1060742 /* Dim_RPTS_TO_DIM */ ,
     phrdw.DT_DIM T1060732 /* Dim_DT_DIM_Job_Entry */ ,
     phrdw.DT_DIM T1060729 /* Dim_DT_DIM_Filter */ ,
     phrdw.LOC_DIM T1060763 /* Dim_LOC_DIM */ ,
     phrdw.DT_DIM T1060755 /* Dim_DT_DIM_Last_Appraisal */ ,
     phrdw_secured.EMP_DIM T1060728 /* Dim_EMP_DIM */ ,
     phrdw.DT_DIM T1060738 /* Dim_DT_DIM_Termination */ ,
     phrdw.DT_DIM T1060744 /* Dim_DT_DIM_Original_Hire */ ,
     phrdw.DEPT_DIM T1060752 /* Dim_DEPT_DIM */ ,
     phrdw.DT_DIM T1060727 /* Dim_DT_DIM_Last_Hire */ ,
     phrdw.DT_DIM T1060757 /* Dim_DT_DIM_Action */ ,
     phrdw.DT_DIM T1060762 /* Dim_DT_DIM_Effective_Date */ ,
     phrdw.DT_DIM T1060769 /* Dim_DT_DIM_Expected_Return */ ,
     phrdw_secured.EMP_EVT_FACT T1060764 /* Fact_EMP_EVT_FACT */
where  ( T1060720.ACTN_DIM_ID = T1060764.ACTN_DIM_ID and
  T1060723.JOB_DIM_ID = T1060764.JOB_DIM_ID and
  T1060742.RPTS_TO_DIM_ID = T1060764.RPTS_TO_DIM_ID and
  T1060732.DT_DIM_ID = nvl(T1060764.JOB_ENTRY_DT_DIM_ID , 0) and
  T1060729.DT_DIM_ID = T1060764.FILTER_DT_DIM_ID and
  T1060745.DT_DIM_ID = T1060764.SERVICE_DT_DIM_ID and
  T1060755.DT_DIM_ID = T1060764.LAST_APRSL_DT_DIM_ID and
  T1060728.EMP_DIM_ID = T1060764.EMP_DIM_ID and
  T1060738.DT_DIM_ID = T1060764.TERM_DT_DIM_ID and
  T1060744.DT_DIM_ID = T1060764.ORIG_HIRE_DT_DIM_ID and
  T1060752.DEPT_DIM_ID = T1060764.DEPT_DIM_ID and
  T1060727.DT_DIM_ID = T1060764.LAST_HIRE_DT_DIM_ID and
  T1060757.DT_DIM_ID = T1060764.ACTN_DT_DIM_ID and
  T1060758.DT_DIM_ID = nvl(T1060764.DEPT_ENTRY_DT_DIM_ID , 0) and
  T1060762.DT_DIM_ID = T1060764.EFF_DT_DIM_ID and
  T1060763.LOC_DIM_ID = T1060764.LOC_DIM_ID and
  T1060764.EXPCTD_RETURN_DT_DIM_ID = T1060769.DT_DIM_ID and
  T1060764.POS_ENTRY_DT_DIM_ID = T1215969.DT_DIM_ID and `;

  if (req.body.view) {
    switch(req.body.view) {
      case 'performance':
        console.log('Performance View');
        head = perf;
        break;
      case 'personal':
        console.log('Personal View');
        head = personal;
        break;
      case 'compensation':
        console.log('Compensation View');
        head = compensation;
        break;
      case 'diversity':
        console.log('Diversity View');
        head = diversity;
        break;
      case 'all':
        console.log('All View');
        head = all;
        break;
      default:
        break;
    }
  }

    date = `t1060729.full_dt BETWEEN DATE($1) AND DATE($2))`;
  let varCounter = 2;
  let base = '';

  let parms = [
    req.body.date,
    req.body.date2
  ];

  if (req.body.events.length && req.body.events.length > 0) {
    events = req.body.events.map(evt => `'${evt}'`).join(',');
    event = `( CASE
        WHEN t1060720.actn_catg_desc
          IN ( 'Contract Contingent Worker','Hire','Hire Employee' )
        THEN 'Hire'
        WHEN t1060720.actn_catg_desc IN ( 'Change Job','Job/Grade Change' )
        THEN 'Job/Grade Change'
        WHEN t1060720.actn_catg_desc IN ( 'Leave','Leave of Absence' )
        THEN 'Leave of Absence'
        WHEN t1060720.actn_catg_desc
          IN ( 'One-Time Payment','Pay Rate Change','Request Compensation Change' )
        THEN 'Pay Rate Change'
        WHEN t1060720.actn_catg_desc
          IN ( 'Add Retiree Status','End Contingent Worker Contract',
               'Terminate Employee','Termination' )
        THEN 'Termination'
        WHEN t1060720.actn_catg_desc
          IN ( 'Change Organization Assignments for Worker',
               'End International Assignment','Transfer',
               'Transfer Contingent Worker' )
        THEN 'Transfer'
        WHEN t1060720.actn_catg_desc
          IN ( 'Close Position or Headcount','Create Position','Edit Position',
               'End Additional Employee Job',
               'Freeze Position,Headcount,or Job Group' ,
               'Move to New Manager','Profile Change',
               'Remove Retiree Status','Start International Assignment',
               'Statutory Compensation Statement' )
        THEN 'Profile Change'
        ELSE t1060720.actn_catg_desc
      END IN (${events}) ) AND `;
    console.log("event:\n", event);
    head += event;
  }

  head += date;

  // Row Level Security: Select Based on EC Members
  if (req.body.rows && req.body.rows.length > 0) {
    base += ' AND t1060742.ec_id in (' + req.body.rows.map(jl => `'${jl}'`).join(',') + ')';
  }

  if (req.body.asctype !== "All") {
    base += ' AND t1060764.assoc_type_desc = $' + (++varCounter).toString();
    parms.push(req.body.asctype);
  }

  if (req.body.flsa && req.body.flsa !== "All") {
    base += ' AND t1060723.flsa_stat_cd = $' + (++varCounter).toString();
    parms.push(req.body.flsa);
  }

  if (req.body.job_level && req.body.job_level.length > 0) {
    base += ' AND t1060723.job_lvl_cd in (' + req.body.job_level.map(jl => `'${jl}'`).join(',') + ')';
  }

  if (req.body.emp_status && req.body.emp_status !== "All") {
    base += ' AND t1060764.active_emp_ind = $' + (++varCounter).toString();
    parms.push(req.body.emp_status);
  }

  if (req.body.country !== undefined && req.body.country.length > 0) {
    base += ' AND t1060763.work_cntry_nm in (' + req.body.country.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.state !== undefined && req.body.state.length > 0) {
    base += ' AND t1060763.work_st_cd in (' + req.body.state.map(st => `'${st}'`).join(',') + ')';
  }

  if (req.body.city !== undefined && req.body.city.length > 0) {
    base += ' AND t1060763.work_city_nm in (' + req.body.city.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.building !== undefined && req.body.building.length > 0) {
    base += ' AND t1060763.loc_cd in (' + req.body.building.map(ct => `'${ct}'`).join(',') + ')';
  }

  if (req.body.fname && req.body.fname !== "") {
    base += ' AND LOWER(t1060728.frst_nm) = $' + (++varCounter).toString();
    parms.push(req.body.fname.toLowerCase());
  }

  if (req.body.lname && req.body.lname !== "") {
    base += ' AND LOWER(t1060728.last_nm) = $' + (++varCounter).toString();
    parms.push(req.body.lname.toLowerCase());
  }

  if (req.body.empid && req.body.empid !== "") {
    base += ' AND t1060728.emp_id = $' + (++varCounter).toString();
    parms.push(req.body.empid);
  }

  if (req.body.reports_to1 && req.body.reports_to1.length > 0) {
    base += ' AND t1060742.ec_nm in (' + req.body.reports_to1.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.reports_to2 && req.body.reports_to2.length > 0) {
    base += ' AND t1060742.ec1_nm in (' + req.body.reports_to2.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.reports_to3 && req.body.reports_to3.length > 0) {
    base += ' AND t1060742.ec2_nm in (' + req.body.reports_to3.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.reports_to4 && req.body.reports_to4.length > 0) {
    base += ' AND t1060742.ec3_nm in (' + req.body.reports_to4.map(rt => `'${rt}'`).join(',') + ')';
  }

  if (req.body.org_level1 && req.body.org_level1.length > 0) {
    base += ' AND t1060752.finc_lvl_1_desc in (' + req.body.org_level1.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level2 && req.body.org_level2.length > 0) {
    base += ' AND t1060752.finc_lvl_2_desc in (' + req.body.org_level2.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level3 && req.body.org_level3.length > 0) {
    base += ' AND t1060752.finc_lvl_3_desc in (' + req.body.org_level3.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level4 && req.body.org_level4.length > 0) {
    base += ' AND t1060752.finc_lvl_4_desc in (' + req.body.org_level4.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level5 && req.body.org_level5.length > 0) {
    base += ' AND t1060752.finc_lvl_5_desc in (' + req.body.org_level5.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level6 && req.body.org_level6.length > 0) {
    base += ' AND t1060752.finc_lvl_6_desc in (' + req.body.org_level6.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level7 && req.body.org_level7.length > 0) {
    base += ' AND t1060752.finc_lvl_7_desc in (' + req.body.org_level7.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level8 && req.body.org_level8.length > 0) {
    base += ' AND t1060752.finc_lvl_8_desc in (' + req.body.org_level8.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level9 && req.body.org_level9.length > 0) {
    base += ' AND t1060752.finc_lvl_9_desc in (' + req.body.org_level9.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level10 && req.body.org_level10.length > 0) {
    base += ' AND t1060752.finc_lvl_10_desc in (' + req.body.org_level10.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level11 && req.body.org_level11.length > 0) {
    base += ' AND t1060752.finc_lvl_11_desc in (' + req.body.org_level11.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.body.org_level12 && req.body.org_level12.length > 0) {
    base += ' AND t1060752.finc_lvl_12_desc in (' + req.body.org_level12.map(org => `'${org}'`).join(',') + ')';
  }

  if (req.query['format'] === 'csv') {
    base += '';
  } else {
    base += ' LIMIT 25';
  }

  console.log("Base: \n", base);

  const events_query = {
    name: 'event-report',
    text: head + base,
    values: parms
  };

  console.log(events_query.text);

  db.query(events_query, (err, data) => {
    if (err) {
      console.log(err);
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch Employee Events report']
      });
    }
    console.log("Total Results: ", data.rows.length);
    res.send(data.rows);
  });
});

module.exports = router;
