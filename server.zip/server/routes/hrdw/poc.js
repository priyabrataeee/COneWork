const express = require('express');
const router = express.Router();
const db = require('../../db/pg');
const fs = require('fs');

router.get('/poc', (req, res) => {
  poc = {
    name: 'attachment-poc',
    text: 'select FILECONTENT from ATFILECONTENT where ATFILECONTENTNO = 114043'
  };
  db.query(poc, (err, data) => {
    if (err) {
      console.log('query err', err, 'result: ', data);
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch Employee Events report'],
        err: err
      });
    }
    if (data.rows.length > 0) {
      console.log("Rows Count ", data.rows.length);
      const filename = 'tmp.zip';
      fs.writeFile(filename, data.rows[0].filecontent, (err) => {
        if (err) {
          console.log(err);
          return res.json({
            errors: ['Failed to fetch Employee Events report'],
            err: err
          });
        } else {
          res.download(filename, 'attachment.zip', (err) => {
            if (err) {
              console.log('Download Error');
            } else {
              fs.unlink(filename);
            }
          });
        }
      });
    } else {
      return res.json({
        errors: ['Failed to fetch Employee Events report'],
        err: err
      });
    }
  });
});

module.exports = router;
