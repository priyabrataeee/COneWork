const express = require('express');
const router = express.Router();
const db = require('../../db/hrdw');
const pg = require('../../db/pg');

router.get('/rows', (req, res) => {
  if (req.query['eid'] !== undefined) {
    const rows = {
      name: 'get-rows',
      text: 'SELECT DISTINCT ec_id FROM comp_perms where eid = $1',
      values: [req.query.eid]
    };
    pg.query(rows, (err, data) => {
      if (err) {
        console.log(err)
        res.statusCode = 500;
        return res.json({
          errors: ['Failed to fetch EC Members']
        })
      }
      arr = [];
      for (ec of data.rows) {
        arr.push(ec.ec_id)
      }
      res.send(arr)
    });
  }
});

router.post('/dept', (req, res) => {
  // if (req.query['dept'] === undefined) {
    const dept = {
      name: 'get-depts',
      text: 'SELECT DISTINCT dept_id, dept_nm FROM phrdw_tb.dept_dim where ec_id in (' + req.body.map(row => `'${row}'`).join(',') + ') ORDER BY dept_id'
    }
    db.query(dept, (err, data) => {
      if (err) {
        res.statusCode = 500;
        return res.json({
          errors: ['Failed to fetch departments']
        })
      }
      res.send(data.rows)
    })
  // } else {
  //   const dep = {
  //     name: 'search-depts',
  //     text: 'SELECT DISTINCT dept_id, dept_nm FROM phrdw.dept_dim where dept_nm ILIKE $1 ORDER BY dept_nm LIMIT 100',
  //     values: [req.query.dept]
  //   }
  //   db.query(dep, (err, data) => {
  //     if (err) {
  //       res.statusCode = 500;
  //       return res.json({
  //         errors: ['Failed to fetch departments']
  //       })
  //     }
  //     res.send(data.rows)
  //   })
  // }
})

router.get('/dates', (req, res) => {
  const dates = {
    name: 'get-dates',
    text: 'select distinct yymm_num from phrdw_tb.dt_dim where full_dt <= current_date order by full_dt desc'
  }

  db.query(dates, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch dates']
      })
    }
    res.send(data.rows)
  })
})

router.get('/joblevels', (req, res) => {
  const joblevels = {
    name: 'get-joblevels',
    text: 'SELECT DISTINCT LPAD(job_lvl_cd, 2, 0) as job_lvl_cd, job_lvl_desc from phrdw_tb.job_dim ORDER BY job_lvl_cd::int desc'
  }
  db.query(joblevels, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch job levels']
      })
    }
    res.send(data.rows)
  })
})

router.get('/countries', (req, res) => {
  const countries = {
    name: 'get-countries',
    text: 'SELECT DISTINCT work_cntry_nm from phrdw_tb.loc_dim'
  }
  db.query(countries, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch countries']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.work_cntry_nm)
    }
    res.send(arr)
  })
})

router.get('/states', (req, res) => {
  const states = {
    name: 'get-states',
    text: 'SELECT DISTINCT work_st_cd from phrdw_tb.loc_dim'
  }
  db.query(states, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch states']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.work_st_cd)
    }
    res.send(arr)
  })
})

router.get('/cities', (req, res) => {
  const cities = {
    name: 'get-cities',
    text: 'SELECT DISTINCT work_city_nm from phrdw_tb.loc_dim'
  }
  db.query(cities, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch cities']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.work_city_nm)
    }
    res.send(arr)
  })
});

router.get('/rep1', (req, res) => {
  const rep1 = {
    name: 'get-rep1',
    text: 'SELECT DISTINCT ec_nm from phrdw_tb.rpts_to_dim'
  }
  db.query(rep1, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch Reports To 1']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.ec_nm)
    }
    res.send(arr)
  })
});

router.get('/rep2', (req, res) => {
  const rep2 = {
    name: 'get-rep2',
    text: 'SELECT DISTINCT ec1_nm from phrdw_tb.rpts_to_dim'
  }
  db.query(rep2, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch Reports To 2']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.ec1_nm)
    }
    res.send(arr)
  })
});

router.get('/rep3', (req, res) => {
  const rep3 = {
    name: 'get-rep3',
    text: 'SELECT DISTINCT ec2_nm from phrdw_tb.rpts_to_dim'
  }
  db.query(rep3, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch Reports To 3']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.ec2_nm)
    }
    res.send(arr)
  })
});

router.post('/rep4', (req, res) => {
  const rep4 = {
    name: 'get-rep4',
    text: 'SELECT DISTINCT ec3_nm from phrdw_tb.rpts_to_dim where ec_id in (' + req.body.map(row => `'${row}'`).join(',') + ')'
  }
  db.query(rep4, (err, data) => {
    if (err) {
      console.log(err)
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch Reports To 4']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.ec3_nm)
    }
    res.send(arr)
  })
});

router.get('/org1', (req, res) => {
  const org1 = {
    name: 'get-org1',
    text: 'SELECT DISTINCT finc_lvl_1_desc from phrdw_tb.dept_dim'
  }
  db.query(org1, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 1']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_1_desc)
    }
    res.send(arr)
  })
});

router.get('/org2', (req, res) => {
  const org2 = {
    name: 'get-org2',
    text: 'SELECT DISTINCT finc_lvl_2_desc from phrdw_tb.dept_dim'
  }
  db.query(org2, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 2']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_2_desc)
    }
    res.send(arr)
  })
});

router.get('/org3', (req, res) => {
  const org3 = {
    name: 'get-org3',
    text: 'SELECT DISTINCT finc_lvl_3_desc from phrdw_tb.dept_dim'
  }
  db.query(org3, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 3']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_3_desc)
    }
    res.send(arr)
  })
});

router.get('/org4', (req, res) => {
  const org4 = {
    name: 'get-org4',
    text: 'SELECT DISTINCT finc_lvl_4_desc from phrdw_tb.dept_dim'
  }
  db.query(org4, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 4']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_4_desc)
    }
    res.send(arr)
  })
});

router.get('/org5', (req, res) => {
  const org5 = {
    name: 'get-org5',
    text: 'SELECT DISTINCT finc_lvl_5_desc from phrdw_tb.dept_dim'
  }
  db.query(org5, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 5']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_5_desc)
    }
    res.send(arr)
  })
});

router.get('/org6', (req, res) => {
  const org6 = {
    name: 'get-org6',
    text: 'SELECT DISTINCT finc_lvl_6_desc from phrdw_tb.dept_dim'
  }
  db.query(org6, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 6']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_6_desc)
    }
    res.send(arr)
  })
});

router.get('/org7', (req, res) => {
  const org7 = {
    name: 'get-org7',
    text: 'SELECT DISTINCT finc_lvl_7_desc from phrdw_tb.dept_dim'
  }
  db.query(org7, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 7']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_7_desc)
    }
    res.send(arr)
  })
});

router.get('/org8', (req, res) => {
  const org8 = {
    name: 'get-org8',
    text: 'SELECT DISTINCT finc_lvl_8_desc from phrdw_tb.dept_dim'
  }
  db.query(org8, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 8']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_8_desc)
    }
    res.send(arr)
  })
});

router.get('/org9', (req, res) => {
  const org9 = {
    name: 'get-org9',
    text: 'SELECT DISTINCT finc_lvl_9_desc from phrdw_tb.dept_dim'
  }
  db.query(org9, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 9']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_9_desc)
    }
    res.send(arr)
  })
});

router.get('/org10', (req, res) => {
  const org10 = {
    name: 'get-org10',
    text: 'SELECT DISTINCT finc_lvl_10_desc from phrdw_tb.dept_dim'
  }
  db.query(org10, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 10']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_10_desc)
    }
    res.send(arr)
  })
});

router.get('/org11', (req, res) => {
  const org11 = {
    name: 'get-org11',
    text: 'SELECT DISTINCT finc_lvl_11_desc from phrdw_tb.dept_dim'
  }
  db.query(org11, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 11']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_11_desc)
    }
    res.send(arr)
  })
});

router.get('/org12', (req, res) => {
  const org12 = {
    name: 'get-org12',
    text: 'SELECT DISTINCT finc_lvl_12_desc from phrdw_tb.dept_dim'
  }
  db.query(org12, (err, data) => {
    if (err) {
      res.statusCode = 500;
      return res.json({
        errors: ['Failed to fetch org level 12']
      })
    }
    arr = [];
    for (row of data.rows) {
      arr.push(row.finc_lvl_12_desc)
    }
    res.send(arr)
  })
});

router.get('/building', (req, res) => {
  const building = {
    name: 'get-buildings',
    text: 'SELECT DISTINCT loc_cd,loc_nm FROM phrdw_tb.loc_dim ORDER by loc_cd'
  };
  db.query(building, (err, data) => {
    if (err) {
      console.log(err);
      res.statusCode = 500;
      return res.json({
        effors: ['Failed to fetch Buildings']
      });
    }
    res.send(data.rows);
  });
});

module.exports = router;
