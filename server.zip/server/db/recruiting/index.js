const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.RUSER,
  host: process.env.RHOST,
  database: process.env.RDATABASE,
  password: process.env.RPASSWORD,
  port: process.env.RPORT
  // ssl: true
});

module.exports = {
  query: (text, params, callback) => {
    return pool.query(text, params, callback);
  }
};
