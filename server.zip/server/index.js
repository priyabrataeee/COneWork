// Dependencies
const express = require('express');
const helmet = require('helmet');
const logger = require('morgan');
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');

// API routes

const user = require('./routes/admin/user');
const database = require('./routes/admin/database');
const page = require('./routes/admin/page');
const company = require('./routes/admin/company');
const permission = require('./routes/admin/permission');
const filter = require('./routes/hrdw/filter');
const eom = require('./routes/hrdw/eom');
const evt = require('./routes/hrdw/evt');
const poc = require('./routes/hrdw/poc');
const pagination = require('./routes/admin/pagination');


const app = express();

app.use(helmet());
app.use(logger('combined'));

// Parsers for POSD data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false}));

// Point to Front end
app.use(express.static(path.join(__dirname, '../dist')));

// API Routes
app.use('/api/user', user);
app.use('/api/company', company);
app.use('/api/database', database);
app.use('/api/page', page);
app.use('/api/permission', permission);
app.use('/api/filter', filter);
app.use('/api/eom', eom);
app.use('/api/evt', evt);
app.use('/api/poc', poc);
app.use('/api/pagination', pagination);


// Redirect other routes to Angular
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

// Port

const port = process.env.PORT || '3000';
app.set('port', port);

// Create Server
const server = http.createServer(app);

// Start Listening
server.listen(port, () => console.log(`API running on localhost:${port}`));
